# Modèle de secours (non appris de Jira)
Titre : [TYPE] Objet exact — résultat attendu
Description : Contexte / Objectif / Périmètre / Travaux détaillés / Hors périmètre / Critères d’acceptation / Dépendances / Références / Risques documentés.
RECETTE : prérequis, cas, résultat attendu et séparation du développeur. DOC : livrable précis et contributeurs éligibles. DEPENDANCE : équipe ou système si connu, livrable attendu, condition de résolution. ENABLER : résultat technique vérifiable.
