# Backlog — DEMO — fictif

Source : local:exemple-fictif · modèle : fallback

US : 3 · couverture structurelle : 1/1

## Questions ouvertes / Points d’attention

Aucune question enregistrée.

## Alertes

- Modèle de secours non appris de Jira

## DEV-001 · DEV · Exposer STATUT dans DEMO_V_CLIENT

État : ready

Exposer STATUT dans DEMO_V_CLIENT

Objets : DEMO_V_CLIENT, STATUT

Exigences : R-001

Dépendances : 

Critères :

- La valeur STATUT correspond à la source de démonstration.

## REC-001 · RECETTE · Vérifier STATUT dans DEMO_V_CLIENT

État : ready

Vérifier STATUT dans DEMO_V_CLIENT

Objets : DEMO_V_CLIENT, STATUT

Exigences : R-001

Dépendances : blocks:DEV-001

Critères :

- La valeur STATUT correspond à la source de démonstration.

## DOC-001 · DOC · Documenter STATUT dans DEMO_V_CLIENT

État : ready

Documenter STATUT dans DEMO_V_CLIENT

Objets : DEMO_V_CLIENT, STATUT

Exigences : R-001

Dépendances : blocks:DEV-001

Critères :

- La valeur STATUT correspond à la source de démonstration.
