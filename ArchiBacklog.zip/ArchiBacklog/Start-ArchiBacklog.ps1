﻿[CmdletBinding()]
param(
 [ValidateSet('Chat','Analyse','Revision','Valider','Approuver','Publier','Diagnostic')][string]$Mode='Chat',
 [string]$Source,
 [string]$Campagne,
 [string]$Instruction
)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$env:PYTHONIOENCODING='utf-8'
function Invoke-Python {
 param([string[]]$ArgList)
 if (Get-Command python -ErrorAction SilentlyContinue) { & python @ArgList }
 elseif (Get-Command py -ErrorAction SilentlyContinue) { & py -3 @ArgList }
 else { throw 'Python 3.10+ requis pour la validation et les exports.' }
 if ($LASTEXITCODE -ne 0) { throw "Validation Python en échec : $LASTEXITCODE" }
}
function Invoke-Gemini {
 param([string[]]$ArgList)
 if (Get-Command gemini.cmd -ErrorAction SilentlyContinue) { & gemini.cmd @ArgList }
 elseif (Get-Command gemini -ErrorAction SilentlyContinue) { & gemini @ArgList }
 elseif (Get-Command npx.cmd -ErrorAction SilentlyContinue) { & npx.cmd --no-install @google/gemini-cli @ArgList }
 else { throw 'Gemini CLI introuvable. Utiliser votre installation approuvée.' }
 if ($LASTEXITCODE -ne 0) { throw "Gemini en échec : $LASTEXITCODE" }
}
function Get-BacklogPath {
 if (-not $Campagne) { throw 'Indiquer -Campagne output/campagne-...' }
 $outputRoot=(Resolve-Path -LiteralPath 'output').Path + [IO.Path]::DirectorySeparatorChar
 $folder=(Resolve-Path -LiteralPath $Campagne).Path
 if (-not $folder.StartsWith($outputRoot,[StringComparison]::OrdinalIgnoreCase)) { throw 'La campagne doit être sous output/.' }
 $p=Join-Path $folder 'backlog.json'
 if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw 'backlog.json absent.' }
 return $p
}
Write-Host "ARCHIBACKLOG | $Mode | PowerShell" -ForegroundColor Cyan
switch ($Mode) {
 'Diagnostic' { Invoke-Gemini -ArgList @('--version'); Invoke-Gemini -ArgList @('mcp','list'); Invoke-Python -ArgList @('--version') }
 'Chat' { Invoke-Gemini -ArgList @('--approval-mode','default') }
 'Analyse' {
   if (-not $Source) { $Source=Read-Host 'URL Confluence ou chemin de conception locale' }
   if (-not $Source) { throw 'Source obligatoire.' }
   $id='campagne-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+([guid]::NewGuid().ToString('N').Substring(0,6))
   $dir="output/$id"; New-Item -ItemType Directory -Path $dir | Out-Null
   $prompt="Mode ANALYSE lecture seule distante. Lis GEMINI.md, l'agent archibacklog et les skills. Source: $Source. Dossier exact: $dir. Ecris backlog.json conforme a config/contract.md, sans estimation, points null. Si source inaccessible, ecris diagnostic.md sans faux backlog. Aucune mutation Jira/Confluence. Continue la revue dans ce terminal."
   Write-Host "Campagne : $dir" -ForegroundColor Yellow
   Invoke-Gemini -ArgList @('--approval-mode','default','-i',$prompt)
   if (Test-Path "$dir/backlog.json") { Invoke-Python -ArgList @('scripts/backlog.py','validate',"$dir/backlog.json") } else { Write-Warning "Aucun backlog produit. Voir $dir." }
 }
 'Revision' {
   $p=Get-BacklogPath; $folder=Split-Path -Parent $p
   $relative=Resolve-Path -Relative -LiteralPath $p
   if (-not $Instruction) { $Instruction=Read-Host 'Modification demandee' }
   Copy-Item -LiteralPath $p -Destination (Join-Path $folder ('backlog-before-'+(Get-Date -Format 'yyyyMMdd-HHmmssfff')+'.json'))
   if (Test-Path (Join-Path $folder 'approval.json')) { Remove-Item -LiteralPath (Join-Path $folder 'approval.json') }
   $prompt="Mode REVISION. Ne modifie aucun service distant. Lis GEMINI.md et le contrat. Modifie seulement le backlog local $relative selon cette demande : $Instruction. Preserve les references et verifie la couverture. Aucune estimation, points null."
   Invoke-Gemini -ArgList @('--approval-mode','default','-i',$prompt)
   Invoke-Python -ArgList @('scripts/backlog.py','validate',$p)
 }
 'Valider' { $p=Get-BacklogPath; Invoke-Python -ArgList @('scripts/backlog.py','validate',$p) }
 'Approuver' { $p=Get-BacklogPath; Invoke-Python -ArgList @('scripts/backlog.py','validate',$p); Invoke-Python -ArgList @('scripts/backlog.py','approve',$p) }
 'Publier' {
   $p=Get-BacklogPath; Invoke-Python -ArgList @('scripts/backlog.py','check',$p)
   if ((Read-Host 'Ouvrir une session de publication Jira (taper PUBLIER)') -cne 'PUBLIER') { return }
   $relative=Resolve-Path -Relative -LiteralPath $p
   $prompt="Mode PUBLICATION. Lis GEMINI.md et .gemini/skills/jira-publisher/SKILL.md. Backlog approuve: $relative. Verifie le hash via scripts/backlog.py check, puis les metadonnees et doublons en lecture seule. Montre le plan et demande une confirmation explicite avant chaque mutation. Ne modifie pas le backlog ni les tickets existants, ne cree pas de sprint et ne renseigne aucun champ d estimation. Si obligatoire, arrete. Arrete au premier echec ou doute et journalise chaque resultat reel."
   Invoke-Gemini -ArgList @('--approval-mode','default','-i',$prompt)
 }
}
