import copy, json, sys, unittest, tempfile, subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from backlog import validate
class Checks(unittest.TestCase):
    def setUp(self): self.data=json.loads((ROOT/'examples/backlog.json').read_text(encoding='utf8'))
    def test_good(self): self.assertFalse(validate(self.data)[0])
    def test_no_estimates(self):
        for value in [0,1,5,'3']:
            with self.subTest(value=value):
                d=copy.deepcopy(self.data); d['stories'][0]['points']=value
                self.assertTrue(any('estimation interdite' in e for e in validate(d)[0]))
    def test_no_estimate_extra_fields(self):
        self.data['stories'][0]['estimate_reason']='test'
        self.assertTrue(validate(self.data)[0])
    def test_cycle(self):
        self.data['stories'][0]['dependencies']=[{'id':'REC-001','kind':'blocks'}]
        self.assertTrue(any('Cycle' in x for x in validate(self.data)[0]))
    def test_doc_ba(self):
        self.data['stories'][2]['roles']=['BA']; self.assertTrue(validate(self.data)[0])
    def test_placeholder(self):
        self.data['stories'][0]['title']='faire le dev'; self.assertTrue(validate(self.data)[0])
    def test_question(self):
        self.data['questions']=[dict(id='Q-001',text='Source ?',blocking=True,requirement_ids=['R-001'])]; self.assertTrue(validate(self.data)[0])
    def test_stale_approval(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'backlog.json'; p.write_text(json.dumps(self.data),encoding='utf8'); cmd=[sys.executable,str(ROOT/'scripts/backlog.py')]
            self.assertEqual(subprocess.run(cmd+['approve',str(p)],input='APPROUVER\n',text=True,capture_output=True).returncode,0)
            self.assertEqual(subprocess.run(cmd+['check',str(p)],capture_output=True).returncode,0)
            p.write_text(p.read_text()+'\n'); self.assertNotEqual(subprocess.run(cmd+['check',str(p)],capture_output=True).returncode,0)
if __name__=='__main__': unittest.main()
