# ArchiBacklog — PowerShell / Gemini CLI
*Architecte intelligent des User Stories — De la conception au backlog.*

Aucun serveur HTTP, npm install, localhost ou IHM obligatoire. Gemini CLI et ses MCP distants sont utilisés depuis le terminal. Les rapports sont locaux (HTML statique facultatif). Python 3.10+ est utilisé uniquement pour les contrôles et exports ; aucune dépendance pip.

## Installation
1. Extraire le ZIP dans un répertoire autorisé. Ouvrir PowerShell dans le dossier archibacklog.
2. Vérifier que Gemini CLI et Python sont déjà installés et que la politique d'exécution de l'entreprise permet ce script. Si le script est bloqué, demander au support la procédure autorisée ; ne pas contourner les restrictions.
3. Réutiliser les MCP Jira et Confluence déjà configurés et autorisés dans Gemini CLI (configuration utilisateur ou projet). Le paquet n'inclut ni jeton, ni URL de serveur MCP, ni paramètres secrets. Si votre configuration est uniquement dans un autre projet, la faire adapter par le mécanisme approuvé. Vérifier les droits de lecture et, séparément, les droits de création Jira. Le VPN peut être requis. Ne pas envoyer des données internes à une instance Gemini non approuvée.

```powershell
.\Start-ArchiBacklog.ps1 -Mode Diagnostic
.\Start-ArchiBacklog.ps1 -Mode Analyse
```

Ou directement :
```powershell
.\Start-ArchiBacklog.ps1 -Mode Analyse -Source 'https://si-confluence.edf.fr/spaces/DORZSUNRISE/pages/3050977021/02+-+CAPA-1446+-+Conception'
```

La session Gemini est interactive ; accepter uniquement les appels autorisés. Quitter Gemini avec `/quit` pour déclencher la validation/export local automatique. Si aucun backlog n'a été écrit, consulter le diagnostic. Si Gemini ne délègue pas au sous-agent, lui demander de lire `.gemini/agents/archibacklog.md` et d'appliquer la procédure directement. Dans le chat, `/agents list`, `/skills list`, `/mcp` et `/commands list` permettent de vérifier les éléments disponibles selon la version. Les commandes `/archibacklog:analyser` et `/archibacklog:auditer` sont des raccourcis facultatifs.

## Revue / approbation / publication
Remplacer le chemin par celui affiché au démarrage :
```powershell
$campagne = 'output/campagne-20261124-180000-abcdef'
.\Start-ArchiBacklog.ps1 -Mode Valider -Campagne $campagne
.\Start-ArchiBacklog.ps1 -Mode Revision -Campagne $campagne -Instruction 'Scinder le ticket DEV-001 selon les livrables documentés.'
.\Start-ArchiBacklog.ps1 -Mode Approuver -Campagne $campagne
.\Start-ArchiBacklog.ps1 -Mode Publier -Campagne $campagne
```
Lire `backlog.md`, `couverture.csv`, `validation.json` et les questions avant approbation. Optionnel : `Invoke-Item (Join-Path $campagne 'rapport.html')` ouvre un fichier local, sans serveur. Toute modification des octets de backlog.json invalide son empreinte approuvée. La publication est conservatrice : aucune US bloquée, aucune exigence non couverte, aucune question bloquante, source complète. Les métadonnées Jira et doublons sont à vérifier en ligne par Gemini avant création ; la création reste soumise aux confirmations MCP. Les prompts ne constituent pas une barrière de sécurité : pour l'analyse, préférer des identifiants MCP en lecture seule et des permissions séparées. Ne jamais activer un mode d'approbation automatique pour les mutations. En cas de publication partielle, vérifier les tickets effectivement créés avant toute reprise ; `publication.json` est le journal demandé à Gemini, non une transaction Jira.

## Sorties
- backlog.json : source de vérité, exigences, US, questions, dépendances, provenance.
- backlog.md : rapport détaillé pour revue.
- validation.json : contrôle structurel + empreinte et couverture.
- couverture.csv : matrice de couverture.
- pi_planner.csv / pi_planner.json : format neutre, à adapter au contrat d'import effectif de PI Planner.
- rapport.html : rapport statique optionnel, aucune requête réseau.
- approval.json : approbation locale liée au fichier exact.
- publication.json : journal des actions Jira réelles, généré par Gemini en mode publication.

Le projet Jira et le champ PI sont configurables dans config/planner.json. Le ArchiBacklog ne place aucun sprint et ne chiffre jamais les tickets. Points toujours null en JSON et vides en CSV ; aucune estimation envoyée à Jira. Une US non estimée peut être prête et publiée. Si un champ d’estimation est obligatoire dans Jira, la publication est bloquée jusqu’à intervention humaine. Pour migrer une ancienne campagne, supprimer estimate_reason et confidence, mettre points à null, supprimer les autres champs de chiffrage et revoir le texte avant validation et nouvelle approbation. Installer cette version dans un dossier neuf pour ne pas conserver l’ancien skill story-estimator. `blocks` désigne ici un prérequis du ticket courant, à traduire dans le sens correct des liens Jira. La couverture calculée est structurelle : elle ne garantit pas la couverture sémantique. Le sous-agent et les Skills guident Gemini, qui doit vérifier les noms d'outils MCP réels. Pas de compatibilité confirmée avec les champs privés Jira ni l'import existant PI Planner.

## Test hors connexion
```powershell
python scripts/backlog.py validate examples/backlog.json
python -m unittest discover -s tests
```
Exemple entièrement fictif. Aucun appel EDF ou Gemini pendant ces tests.
