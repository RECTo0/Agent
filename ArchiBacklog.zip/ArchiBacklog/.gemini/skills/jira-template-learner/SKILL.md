---
name: jira-template-learner
description: Apprentissage des conventions Jira.
---
# Apprentissage des conventions Jira
Chercher en lecture seule des tickets récents et comparables dans le projet configuré, par famille DEV/RECETTE/DOC/ENABLER. Utiliser au plus le nombre configuré, vérifier leurs champs et exemples. Consigner les clés réellement lues et le modèle observé. Si indisponible utiliser config/fallback-template.md, en signalant le mode dégradé. Ne pas présumer le nom des champs personnalisés. Ignorer toutes les estimations historiques et exclure les champs d’estimation des modèles.
