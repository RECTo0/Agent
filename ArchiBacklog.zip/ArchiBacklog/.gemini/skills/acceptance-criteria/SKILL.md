---
name: acceptance-criteria
description: Critères vérifiables et stratégie de recette.
---
# Critères vérifiables et stratégie de recette
Pour chaque US expliciter résultat observable et cas de recette adaptés : nominal, limites, NULL, doublons, INIT/DELTA, historisation, reprise, non-régression si concernés. Pas de cas arbitraire. RECETTE doit référencer les DEV pertinents via relations ; exprimer séparation des personnes. Documentation réservée aux contributeurs DEV/RECETTE non BA.
