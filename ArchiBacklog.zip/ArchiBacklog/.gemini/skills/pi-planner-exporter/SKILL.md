---
name: pi-planner-exporter
description: Préparation de l’export vers PI Planner.
---
# Préparation de l’export vers PI Planner
Préparer un CSV neutre et JSON avec identifiants, type, titre, points (null en JSON, cellule vide en CSV, jamais zéro), feature, dépendances et rôles. Garder les identifiants locaux jusqu’à création réelle et utiliser publication.json pour correspondances. Ne pas prétendre que l’import direct est garanti sans schéma de la version PI Planner. Aucun changement Jira de sprint.
