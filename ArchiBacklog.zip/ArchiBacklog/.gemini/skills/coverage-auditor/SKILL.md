---
name: coverage-auditor
description: Audit de couverture et qualité.
---
# Audit de couverture et qualité
Chaque exigence doit pointer vers des US qui la réalisent ou valident ; une exigence couverte uniquement par une US bloquée n’est pas prête. Lister non couvert, bloqué, questions, incohérences et couverture partielle. Vérifier sources, absence de placeholders, noms d’objets, dépendances, absence d’estimation et critères. Ne pas prétendre que le validateur structurel prouve le fond.
