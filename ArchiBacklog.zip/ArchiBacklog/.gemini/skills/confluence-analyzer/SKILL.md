---
name: confluence-analyzer
description: Analyse de conception et extraction de références.
---
# Analyse de conception et extraction de références
Lire la page, ses tableaux, sections, annexes et liens strictement pertinents accessibles. Identifier source, cible, attributs, clés, jointures, filtres, RG, historisation, flux, orchestration, impacts, volumétrie, exigences non fonctionnelles et reprise si présents. Distinguer le confirmé du manquant. Conserver section et URL pour chaque exigence ; ne pas inventer les objets.
