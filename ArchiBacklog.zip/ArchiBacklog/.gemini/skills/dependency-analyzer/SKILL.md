---
name: dependency-analyzer
description: Analyse du graphe de dépendances.
---
# Analyse du graphe de dépendances
Utiliser relations blocks et relates_to ; blocks signifie que le ticket courant dépend du ticket référencé. Autoriser plusieurs DEV et RECETTE liés. Ne pas inventer de clés Jira externes ; ticket local DEPENDANCE et équipe à confirmer si inconnue. Détecter cycles sur blocks, ne pas les corriger silencieusement. Ne pas imposer de dépendance globale à un enabler.
