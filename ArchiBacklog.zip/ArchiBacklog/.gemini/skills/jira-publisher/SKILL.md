---
name: jira-publisher
description: Publication Jira contrôlée après validation locale.
---
# Publication Jira contrôlée après validation locale
Seul l’agent principal en mode PUBLICATION peut utiliser ce skill. Lire backlog.json approuvé et approval.json ; vérifier par script le hash et la validation. Refuser publication de tickets bloqués et dépendances non résolues. Lire métadonnées Jira, vérifier projet, types et champs ; ne pas inventer IDs. Chercher doublons sur identifiant de campagne et titre, ne pas écraser. Montrer plan, demander confirmation explicite avant mutations, puis conserver les approbations MCP individuelles. Créer d’abord les tickets, ensuite les liens approuvés avec clés réelles. Tenir output de campagne/publication.json à jour après chaque action (local_id, action, key, état, erreur). Arrêter si erreur ou résultat incertain, ne pas relancer aveuglément. Ne pas affecter sprint/personne ni modifier un ticket préexistant. Ne jamais envoyer les champs Story Points, estimation initiale/restante, durée ou taille. Si un tel champ est obligatoire, arrêter sans renseigner de valeur.
