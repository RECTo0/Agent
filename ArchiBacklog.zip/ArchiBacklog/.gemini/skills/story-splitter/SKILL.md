---
name: story-splitter
description: Découpage des US techniques et fonctionnelles.
---
# Découpage des US techniques et fonctionnelles
Créer uniquement des tranches utiles avec livrable identifiable : collecte ODS, transformation HDR, publication, exposition, supervision, tests et documentation quand explicitement concernés. Utiliser les noms réels. Séparer travaux autonomes et obligations transverses ; aucune US prête avec périmètre vague. Les questions bloquantes sont liées aux US concernées. Découper selon les livrables, les exigences et les dépendances, jamais selon un seuil de points ou de charge.
