"""Offline validation and export; Python 3.10+, standard library only."""
import argparse, csv, hashlib, html, json, re, sys
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT/'config/planner.json').read_text(encoding='utf-8'))

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def dump(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def validate(d):
    errors, warnings = [], []
    if not isinstance(d,dict): return ['Racine JSON non objet'],[],[]
    def require(o, keys, label):
        if not isinstance(o,dict): errors.append(label+': objet attendu'); return False
        missing=set(keys)-o.keys()
        if missing: errors.append(label+': champs absents '+', '.join(sorted(missing))); return False
        return True
    def strings(v): return isinstance(v,list) and all(isinstance(x,str) and x.strip() for x in v)
    if not require(d,['project','feature','source','template','requirements','questions','stories'],'racine'): return errors,warnings,[]
    if d['project']!=CFG['project']: errors.append('Projet différent de la configuration')
    if not isinstance(d['feature'],str) or not d['feature'].strip(): errors.append('Feature manquante')
    if require(d['source'],['url','title','version','complete'],'source'):
        if not all(isinstance(d['source'][k],str) and d['source'][k].strip() for k in ['url','title','version']): errors.append('Métadonnées source invalides')
        if d['source']['complete'] is not True: warnings.append('Conception incomplète : publication bloquée')
    if require(d['template'],['mode','examples','notes'],'template'):
        t=d['template'];
        if t['mode'] not in ['jira','fallback'] or not strings(t['examples']) or not isinstance(t['notes'],str): errors.append('Template invalide')
        elif t['mode']=='jira' and not t['examples']: errors.append('Template Jira sans exemple')
        elif t['mode']=='fallback': warnings.append('Modèle de secours non appris de Jira')
    def index(key,fields):
        out={}; arr=d[key]
        if not isinstance(arr,list): errors.append(key+': liste attendue'); return out
        for i,o in enumerate(arr):
            if not require(o,['id']+fields,f'{key}[{i}]'): continue
            k=o['id']
            if not isinstance(k,str) or not k.strip(): errors.append(key+': ID invalide'); continue
            if k in out: errors.append(key+': ID dupliqué '+k)
            out[k]=o
        return out
    req=index('requirements',['text','source','objects']); qs=index('questions',['text','blocking','requirement_ids']); ss=index('stories',['type','title','description','objects','requirement_ids','acceptance','points','status','question_ids','roles','dependencies'])
    if not req: errors.append('Aucune exigence')
    if not ss: errors.append('Aucune US')
    for k,o in req.items():
        if not strings(o['objects']) or not all(isinstance(o[x],str) and o[x].strip() for x in ['text','source']): errors.append(k+': exigence invalide')
    def refs(v, allowed, label):
        if not strings(v): errors.append(label+': liste de références invalide'); return []
        for x in v:
            if x not in allowed: errors.append(label+': référence inconnue '+x)
        return v
    for k,o in qs.items():
        refs(o['requirement_ids'],req,k)
        if not isinstance(o['blocking'],bool) or not isinstance(o['text'],str) or not o['text'].strip(): errors.append(k+': question invalide')
    graph={k:[] for k in ss}; coverage={k:[] for k in req}; titles=set()
    for k,o in ss.items():
        allowed_story_fields={'id','type','title','description','objects','requirement_ids','acceptance','points','status','question_ids','roles','dependencies'}
        if set(o)-allowed_story_fields: errors.append(k+': champs US non autorisés : '+', '.join(sorted(set(o)-allowed_story_fields)))
        for field in ['title','description']:
            if not isinstance(o[field],str) or not o[field].strip(): errors.append(k+': '+field+' vide')
        title=str(o['title']).strip().casefold()
        if title in titles: errors.append(k+': titre dupliqué')
        titles.add(title)
        if o['type'] not in CFG['types'] or o['status'] not in ['ready','blocked']: errors.append(k+': type/statut invalide')
        for f in ['objects','acceptance','roles']:
            if not strings(o[f]): errors.append(k+': '+f+' invalide')
        rr=refs(o['requirement_ids'],req,k); qq=refs(o['question_ids'],qs,k)
        for x in rr:
            if x in req: coverage[x].append(k)
        p=o['points']
        if p is not None: errors.append(k+': estimation interdite (points doit être null)')
        if o['status']=='ready':
            if not rr or not o['acceptance'] or not o['roles']: errors.append(k+': US prête incomplète')
            if any(qs[x]['blocking'] is True for x in qq if x in qs) or any(q['blocking'] is True and isinstance(q['requirement_ids'],list) and set(rr).intersection(x for x in q['requirement_ids'] if isinstance(x,str)) for q in qs.values()): errors.append(k+': question bloquante pour US prête')
            if any(req[x]['objects'] for x in rr if x in req) and not o['objects']: errors.append(k+': objets absents')
            if re.search(r'\b(TODO|TBD|à définir|faire le dev|à compléter)\b|<[^>]+>',str(o['title'])+' '+str(o['description']),re.I): errors.append(k+': placeholder potentiel')
        dep=o['dependencies']; linked=[]
        if not isinstance(dep,list): errors.append(k+': dépendances invalides'); dep=[]
        for a in dep:
            if not isinstance(a,dict) or not isinstance(a.get('id'),str) or a['id'] not in ss or a['id']==k or a.get('kind') not in ['blocks','relates_to']: errors.append(k+': dépendance invalide'); continue
            linked.append(ss[a['id']]['type'])
            if a['kind']=='blocks':
                graph[k].append(a['id'])
                if o['status']=='ready' and ss[a['id']]['status']=='blocked': errors.append(k+': prérequis bloqué')
        if o['type']=='RECETTE' and 'DEV' not in linked: warnings.append(k+': recette sans lien DEV, à justifier')
        if o['type']=='DOC':
            if not strings(o['roles']) or any(re.search(r'\bBA\b|business analyst',x,re.I) for x in o['roles']): errors.append(k+': rôle DOC non conforme')
            if not set(linked)&{'DEV','RECETTE'}: errors.append(k+': DOC sans lien DEV/RECETTE')
    active=set(); done=set()
    def visit(k):
        if k in active: errors.append('Cycle de dépendance : '+k); return
        if k in done: return
        active.add(k)
        for x in graph[k]: visit(x)
        active.remove(k); done.add(k)
    for k in graph: visit(k)
    rows=[]
    for k,ids in coverage.items():
        state='non_couverte' if not ids else ('couverte' if any(ss[x]['status']=='ready' for x in ids) else 'bloquee')
        rows.append({'requirement_id':k,'status':state,'story_ids':ids,'source':req[k]['source']})
        if state!='couverte': warnings.append(k+': '+state)
    return errors,warnings,rows

def export(p,d,rows,errors,warnings):
    folder=p.parent
    dump(folder/'validation.json',{'sha256':digest(p),'errors':errors,'warnings':warnings,'coverage':rows})
    if errors: return
    ss=d['stories']; cols=['id','type','title','points','status','feature','roles','dependencies','requirement_ids','objects']
    def csvsafe(s):
        s=str(s); return "'"+s if s.lstrip().startswith(('=','+','-','@')) else s
    with (folder/'pi_planner.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=cols,delimiter=';'); w.writeheader()
        for s in ss:
            o={k:s.get(k,'') for k in cols}; o['feature']=d['feature']; o['roles']=' | '.join(s['roles']); o['objects']=' | '.join(s['objects']); o['requirement_ids']=' | '.join(s['requirement_ids']); o['dependencies']=' | '.join(a['kind']+':'+a['id'] for a in s['dependencies']); o['points']='' if s['points'] is None else s['points']; w.writerow({k:csvsafe(v) for k,v in o.items()})
    dump(folder/'pi_planner.json',{'feature':d['feature'],'project':d['project'],'stories':ss,'note':'Format neutre à adapter au schéma PI Planner.'})
    with (folder/'couverture.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,delimiter=';'); w.writerow(['Exigence','Etat','US','Source']); w.writerows([csvsafe(a['requirement_id']),a['status'],csvsafe(' | '.join(a['story_ids'])),csvsafe(a['source'])] for a in rows)
    md=[f"# Backlog — {d['feature']}",f"Source : {d['source']['url']} · modèle : {d['template']['mode']}",f"US : {len(ss)} · couverture structurelle : {sum(x['status']=='couverte' for x in rows)}/{len(rows)}",'## Questions ouvertes / Points d’attention']
    md += [f"- {q['id']} [{'BLOQUANT' if q['blocking'] else 'À CLARIFIER'}] {q['text']}" for q in d['questions']] or ['Aucune question enregistrée.']
    md += ['## Alertes']+['- '+w for w in warnings]
    for s in ss:
        md += [f"## {s['id']} · {s['type']} · {s['title']}",f"État : {s['status']}",s['description'],'Objets : '+', '.join(s['objects']),'Exigences : '+', '.join(s['requirement_ids']),'Dépendances : '+', '.join(a['kind']+':'+a['id'] for a in s['dependencies']),'Critères :']+['- '+a for a in s['acceptance']]
    (folder/'backlog.md').write_text('\n\n'.join(md)+'\n',encoding='utf-8')
    e=lambda x:html.escape(str(x)); cards=[]
    for s in ss:
        cards.append(f'<article class="{e(s["type"])}"><small>{e(s["id"])} · {e(s["type"])} · {e(s["status"])}</small><h2>{e(s["title"])}</h2><p>{e(s["description"])}</p><p><b>Objets :</b> {e(", ".join(s["objects"]))}</p><p><b>Exigences :</b> {e(", ".join(s["requirement_ids"]))}</p><ul>'+''.join('<li>'+e(a)+'</li>' for a in s['acceptance'])+'</ul></article>')
    (folder/'rapport.html').write_text('<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ArchiBacklog</title><style>body{font:16px system-ui;background:#f3f5f8;color:#152238;max-width:1000px;margin:32px auto;padding:16px}article{background:white;border-radius:12px;padding:18px;margin:14px 0;border-left:5px solid #64748b}article.DEV{border-color:#7c3aed}article.RECETTE{border-color:#16a34a}article.DOC{border-color:#dc2626}article.DEPENDANCE{border-color:#ea580c}small{color:#475569}p{white-space:pre-wrap}h2{font-size:20px}</style><h1>ArchiBacklog — '+e(d['feature'])+'</h1><p>'+e(md[2])+'</p><h2>Questions ouvertes / Points d’attention</h2><ul>'+''.join('<li>'+e(q['id']+' — '+q['text'])+'</li>' for q in d['questions'])+'</ul><h2>Alertes</h2><ul>'+''.join('<li>'+e(w)+'</li>' for w in warnings)+'</ul>'+''.join(cards)+'</html>',encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('action',choices=['validate','approve','check']); ap.add_argument('file',type=Path); a=ap.parse_args(); p=a.file.resolve()
    try:
        d=load(p); errors,warnings,rows=validate(d)
        if a.action=='validate': export(p,d,rows,errors,warnings)
        for x in errors: print('ERREUR:',x)
        for x in warnings: print('ALERTE:',x)
        if errors: return 2
        print(f"US : {len(d['stories'])} | Couverture structurelle : {sum(x['status']=='couverte' for x in rows)}/{len(rows)}")
        for t in CFG['types']:
            st=[x for x in d['stories'] if x['type']==t]; print(f'{t}: {len(st)} US')
        if a.action in ('approve','check'):
            if not d['source']['complete'] or any(s['status']!='ready' for s in d['stories']) or any(q['blocking'] for q in d['questions']) or any(x['status']!='couverte' for x in rows): print('Publication bloquée : backlog incomplet ou questions bloquantes.'); return 3
            if a.action=='approve':
                if input('Après revue métier, taper APPROUVER pour ce fichier exact : ')!='APPROUVER': return 4
                dump(p.parent/'approval.json',{'sha256':digest(p),'at':datetime.now(timezone.utc).isoformat(),'project':d['project']}); print('Approbation locale enregistrée (aucune création Jira).')
            else:
                approval=load(p.parent/'approval.json')
                if approval.get('sha256')!=digest(p) or approval.get('project')!=d['project']: print('Approbation invalide : fichier modifié.'); return 4
                print('Approbation locale valide. Les mutations Jira restent à confirmer.')
        return 0
    except (ValueError, OSError, TypeError, KeyError) as exc: print('Échec :',exc); return 2
if __name__=='__main__': sys.exit(main())
