import argparse,json,re,hashlib,unicodedata,math
from pathlib import Path
from capacity import parse_capacity
ROOT=Path(__file__).resolve().parent

def load(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def norm(s): return ''.join(c for c in unicodedata.normalize('NFD',str(s)) if not unicodedata.combining(c)).lower()
def main():
 a=argparse.ArgumentParser(); a.add_argument('--snapshot',required=True); a.add_argument('--capacity',required=True); a.add_argument('--plan'); a.add_argument('--output',default=str(ROOT/'output')); args=a.parse_args()
 j=load(args.snapshot); cap=parse_capacity(args.capacity); cfg=load(ROOT/'templates/config_original.json'); settings=load(ROOT/'config/settings.json')
 if j['project']!=settings['projectKey'] or not j['piValue'] or j.get('partial') is not False: raise ValueError('Import incomplet ou projet/PI invalide : consulter le snapshot.')
 cfg.update(pi_name=j['piValue'],sprints=[s['name'] for s in cap['sprints']],sprint_dates={s['name']:{'start':s['start'],'end':s['end']} for s in cap['sprints']},calendar=cap['calendar'],absences=cap['absences'])
 cfg['roles']['RECETTE']=['RECETTE','DOCUMENTATION','AUTRES']; cfg['roles']['DEV/RECETTE']=cfg['roles']['DEV']; people={}
 for p in cap['people']:
  role=p['role'].upper(); role=cfg['role_aliases'].get(norm(role),role); people[p['name']]={'role':role,'capacity':[p['net'][s] for s in cfg['sprints']]}
 d={k:{} for k in ['tickets','originals','people','locks','external','priorities','feature_titles','previous','warnings','blocked']}; d.update({k:[] for k in ['dependencies','coverage','split_groups','same_owner','alerts','proposals','columns','bundles']}); d.update(config=cfg,people=people,format='jira-mcp')
 for i in j['issues']:
  k=i['key']; summary=i['summary']; text=norm(summary); kind=i.get('kind') or next((t for t,patterns in cfg['classification'].items() if any(re.search(p,text) for p in patterns)),'AUTRES'); kind={'DOC':'DOCUMENTATION'}.get(kind,kind); kind=kind if kind in ['DEV','RECETTE','DOCUMENTATION','AUTRES','ENABLER','ODC','DEPENDANCE','MIXTE'] else 'AUTRES'; feature=i.get('feature') or next(iter(re.findall(r'\bF\d+\b',summary)), 'HORS FEATURE'); points=i.get('points'); status=i.get('status') or ''; done=norm(status) in [norm(x) for x in cfg['done_statuses']]; reasons=[]
  if points is None: reasons.append('POINTS_MANQUANTS')
  elif not isinstance(points,(int,float)) or not math.isfinite(points) or points<0: raise ValueError('Points invalides '+k)
  t=dict(key=k,parent=k,summary=summary,kind=kind,confidence='à confirmer',classification_reason='Jira / classification',features=[feature],feature=feature,points=points,original_points=points,status=status,done=done,links=[],raw_links='',source_row='MCP',source_assignee=i.get('assignee') or '',contributors=i.get('contributors') or [],reasons=reasons,test_exempt=False,priority=9999,flags=i.get('flags',[]),labels=i.get('labels',[]))
  if i.get('external'): d['external'][k]=t
  else: d['tickets'][k]=t
 for l in j['links']:
  b,c=l['source'],l['target']; direction=l['direction'].lower();
  if direction in ('inward','incoming'): b,c=c,b
  if b in d['tickets']: d['tickets'][b]['links'].append(c)
  if c in d['tickets']: d['tickets'][c]['links'].append(b)
  if c not in d['tickets'] or b==c: continue
  if b not in d['tickets'] and b not in d['external']: d['external'][b]={'key':b,'done':False,'contributors':[]}
  dep=dict(before=b,after=c,lag=1 if l.get('blocking') else 0,source='Jira: '+l['type'],policy='blocking' if l.get('blocking') else 'advisory');
  if not any(x['before']==b and x['after']==c and x['policy']==dep['policy'] for x in d['dependencies']): d['dependencies'].append(dep)
 for t in d['tickets'].values(): t['raw_links']=', '.join(t['links'])
 d['originals']=json.loads(json.dumps(d['tickets'])); d['bundles']=[[k] for k in d['tickets']]; d['alerts']=[{'key':'','code':'IMPORT','detail':str(w)} for w in j.get('warnings',[])]
 plan=load(args.plan) if args.plan else {}; aa=[]; used={}; seen=set()
 for x in plan.get('assignments',[]):
  k,p,s=x['key'],x['person'],x['sprint']; t=d['tickets'][k]; pts=t['points']; role=people[p]['role'];
  if k in seen or t['done'] or pts is None or not isinstance(s,int) or not 0<=s<len(cfg['sprints']) or t['kind'] not in cfg['roles'].get(role,[]): raise ValueError('Affectation invalide '+k)
  if not any(v['personId']==p and v['sprint']==cfg['sprints'][s] and v['availability']>0 for v in cap['calendar']): raise ValueError('Absence complète '+k)
  used[p,s]=used.get((p,s),0)+pts
  if used[p,s]>people[p]['capacity'][s]+1e-8: raise ValueError('Surcharge '+p)
  seen.add(k); aa.append(dict(key=k,person=p,sprint=s,points=pts,explanation=x.get('explanation','Proposition Gemini')))
 for c in plan.get('coverage',[]):
  if c['test'] not in d['tickets'] or d['tickets'][c['test']]['kind']!='RECETTE' or any(k not in d['tickets'] or d['tickets'][k]['kind']!='DEV' for k in c['devs']): raise ValueError('Couverture invalide')
  d['coverage'].append(c)
 by={x['key']:x for x in aa}
 for c in d['coverage']:
  test=by.get(c['test']);
  if test and any(k in by and by[k]['person']==test['person'] for k in c['devs']): raise ValueError('Auto-recette '+c['test'])
 for x in plan.get('technicalDependencies',[]):
  if x['before'] not in d['tickets'] or x['after'] not in d['tickets']: raise ValueError('Dépendance technique inconnue')
  d['dependencies'].append(dict(before=x['before'],after=x['after'],lag=1,source='Technique proposée',policy='blocking'))
 d['proposals']=plan.get('proposals',[]); d['alerts'] += [{'key':'','code':'ARBITRAGE','detail':str(w)} for w in plan.get('warnings',[])]
 result=dict(scenario='business',engine='gemini-cli',solver_status='PROPOSITION',trace=[],assignments=aa,unplanned=[{'key':k,'reasons':['NON_PLANIFIE']} for k,t in d['tickets'].items() if k not in seen and not t['done']],completed_features=[],validation={})
 payload=dict(source=hashlib.sha256(json.dumps(d,sort_keys=True).encode()).hexdigest(),data=d,result=result); out=Path(args.output); out.mkdir(parents=True,exist_ok=True); raw=json.dumps(payload,ensure_ascii=False).replace('<','\\u003c'); html=(ROOT/'templates/board.html').read_text(encoding='utf-8').replace('__PIP_PAYLOAD__',raw); (out/'board_pip.html').write_text(html,encoding='utf-8'); (out/'planning.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8'); print(out/'board_pip.html')
if __name__=='__main__': main()
