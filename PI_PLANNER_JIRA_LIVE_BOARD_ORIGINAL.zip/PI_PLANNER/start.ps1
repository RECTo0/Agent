param([string]$PI)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not $PI) { $PI = Read-Host 'Valeur du PI dans Jira' }
if (-not $PI.Trim()) { throw 'PI obligatoire' }
$env:PI_PLANNER_TARGET = $PI
$prompt = 'Lance le workflow PI Planner décrit dans GEMINI.md pour le PI suivant (valeur littérale): ' + $PI + '. Utilise le MCP Jira en lecture seule. Demande les autorisations normales. Génère les outputs via build.py.'
& gemini -i $prompt
