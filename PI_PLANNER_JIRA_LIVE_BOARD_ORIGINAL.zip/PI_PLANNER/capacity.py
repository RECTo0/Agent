"""Lecture des capacités NETTES et disponibilités calendaires (stdlib, sans pip)."""
from pathlib import Path
from zipfile import ZipFile
from xml.etree import ElementTree as ET
from datetime import datetime,timedelta,date
import re
NS={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def read_book(path):
    with ZipFile(path) as z:
        wb=ET.fromstring(z.read('xl/workbook.xml'))
        names=[s.attrib['name'] for s in wb.findall('x:sheets/x:sheet',NS)]
        shared=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            st=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in si.findall('.//x:t',NS)) for si in st.findall('x:si',NS)]
        result={}
        for i,name in enumerate(names,1):
            p=f'xl/worksheets/sheet{i}.xml'
            if p not in z.namelist():continue
            root=ET.fromstring(z.read(p));rows=[]
            for row in root.findall('.//x:sheetData/x:row',NS):
                cells={}
                for c in row.findall('x:c',NS):
                    col=re.match('[A-Z]+',c.attrib['r']).group();idx=0
                    for ch in col:idx=idx*26+ord(ch)-64
                    v=c.find('x:v',NS)
                    if v is None:
                        inline=c.find('x:is',NS)
                        val=''.join(t.text or '' for t in inline.findall('.//x:t',NS)) if inline is not None else ''
                    else:
                        val=v.text or ''
                        if c.attrib.get('t')=='s':val=shared[int(val)]
                        elif c.attrib.get('t')=='n':
                            try:val=float(val)
                            except ValueError:pass
                    cells[idx-1]=val
                rows.append([cells.get(j,'') for j in range(max(cells,default=-1)+1)])
            if rows:
                headers=[str(h).strip().upper() for h in rows[0]]
                result[name]=[{h:(r[j] if j<len(r) else '') for j,h in enumerate(headers)} for r in rows[1:] if any(str(x).strip() for x in r)]
        return result
def dateval(v):
    if isinstance(v,(int,float)):return (datetime(1899,12,30)+timedelta(days=v)).date().isoformat()
    s=str(v or '').strip()
    if not s:return ''
    for fmt in ('%Y-%m-%d','%d/%m/%Y','%d-%m-%Y'):
        try:return datetime.strptime(s[:10],fmt).date().isoformat()
        except ValueError:pass
    raise ValueError('Date invalide : '+s)
def parse_capacity(path):
    path=Path(path);b=read_book(path)
    for name in ('Capacite','Sprints','Absences'):
        if name not in b:raise ValueError('Onglet manquant : '+name)
    sprints=[]
    for i,s in enumerate(b['Sprints']):
        name=str(s.get('SPRINT','')).strip().upper()
        if not name:continue
        start=dateval(s.get('DATE DEBUT'));end=dateval(s.get('DATE FIN'))
        if not start or not end or start>end:raise ValueError('Dates de sprint invalides : '+name)
        sprints.append({'code':name,'name':name.title(),'start':start,'end':end})
    if not sprints:raise ValueError('Aucun sprint')
    people=[];known=set()
    for p in b['Capacite']:
        name=str(p.get('NOM','')).strip();role=str(p.get('ROLE','')).strip()
        if not name:continue
        if name.casefold() in known:raise ValueError('Collaborateur en double : '+name)
        known.add(name.casefold());net={}
        for s in sprints:
            raw=p.get(s['code'],0)
            try:points=float(raw or 0)
            except (ValueError,TypeError):raise ValueError('Capacité invalide : '+name+' / '+s['code'])
            if points<0:raise ValueError('Capacité négative : '+name)
            net[s['name']]=points
        people.append({'id':name,'name':name,'role':role,'team':'','active':True,'net':net,'gross':dict(net)})
    absences=[]
    for a in b['Absences']:
        name=str(a.get('NOM','')).strip()
        if not name:continue
        if name.casefold() not in known:raise ValueError('Absence pour collaborateur inconnu : '+name)
        start=dateval(a.get('DATE DEBUT'));end=dateval(a.get('DATE FIN'))
        if not start or not end or start>end:raise ValueError('Dates d’absence invalides : '+name)
        pct=float(a.get('INDISPONIBILITE (%)',100) or 0)
        if pct>1:pct=pct/100
        if not 0<=pct<=1:raise ValueError('Pourcentage absence invalide : '+name)
        absences.append({'personId':name,'start':start,'end':end,'unavailability':pct,'type':str(a.get('MOTIF',''))})
    calendar=[]
    for p in people:
        for s in sprints:
            day=date.fromisoformat(s['start']);last=date.fromisoformat(s['end'])
            while day<=last:
                if day.weekday()<5:
                    ds=day.isoformat();fraction=max((a['unavailability'] for a in absences if a['personId'].casefold()==p['name'].casefold() and a['start']<=ds<=a['end']),default=0)
                    calendar.append({'personId':p['id'],'sprint':s['name'],'date':ds,'availability':round(1-fraction,3)})
                day+=timedelta(days=1)
    return {'source':path.name,'people':people,'sprints':sprints,'absences':absences,'calendar':calendar,'capacityIsNet':True}
