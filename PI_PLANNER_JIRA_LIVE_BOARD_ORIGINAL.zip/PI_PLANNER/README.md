# PI Planner Jira Live — board original
Prérequis : Python 3, Gemini CLI et MCP Jira EDF déjà configuré. Aucun serveur ni dépendance pip.
1. Remplacer les exemples du fichier input/Template_Capacite_PI_Planner.xlsx.
2. Modifier si nécessaire config/settings.json : projectKey, piFieldName (Version Cible provisoire).
3. Depuis PowerShell : `./start.ps1 -PI "PI 2606"` (ou lancer `gemini` puis demander de préparer le PI). Autoriser normalement les outils de lecture et les écritures locales nécessaires.
4. Ouvrir output/board_pip.html directement. Le board original fourni est utilisé comme template, sans ses anciennes données. Export Excel/JSON/HTML via ses boutons natifs.
5. Pour reconstruire hors ligne : `python build.py --snapshot output/jira_snapshot.json --capacity input/Template_Capacite_PI_Planner.xlsx --plan output/plan.json`.
Limites : le ZIP original contient uniquement le HTML, pas son solveur Python historique. Gemini propose le placement initial; le moteur JS original conserve ses contrôles et son mode permissif. Les nouvelles règles sont en partie des instructions Gemini, non des interdictions exhaustives du moteur JS. Calendrier conservé dans les données, pas de nouvelle vue calendrier dédiée. Arbitrages Gemini via CLI, pas de connexion permanente dans le HTML. Aucun test sur Jira EDF. Sauvegarder les modifications locales avant un nouvel import; pas de fusion automatique des sessions.
