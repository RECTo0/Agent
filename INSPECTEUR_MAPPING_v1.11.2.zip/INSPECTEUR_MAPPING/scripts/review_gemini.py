"""Manual, consent-gated Gemini CLI bridge; no model call on import or server startup."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from backend.services.gemini_runner import command_for,parse_response

def main():
    config=json.loads((ROOT/'config/settings.json').read_text('utf-8'))['gemini']
    if not config.get('enabled'):
        raise SystemExit('Activer gemini.enabled dans Paramètres après validation de votre politique de confidentialité. Aucun envoi effectué.')
    path=Path(sys.argv[1]) if len(sys.argv)>1 else choose_file()
    if not path:raise SystemExit('Annulé.')
    prompt=path.read_text('utf-8-sig')
    print(f'Contexte sélectionné : {path}\nTaille : {len(prompt)} caractères.\nRelisez ce fichier avant de poursuivre. Il contient des métadonnées métier.\nIl sera transmis au service associé à votre Gemini CLI et à sa configuration utilisateur.\nLes permissions standard du CLI restent applicables ; aucun mode YOLO/auto-edit n’est activé.')
    if input('Pour autoriser cet envoi, saisir OUI : ').strip()!='OUI':raise SystemExit('Annulé. Aucun envoi.')
    try:command,timeout=command_for(config)
    except ValueError as exc:raise SystemExit(str(exc))
    with tempfile.TemporaryDirectory(prefix='mqg-review-') as temp:
        # Empty working directory prevents accidental inclusion of project files.
        try:
            env=os.environ.copy();env['GEMINI_CLI_TRUST_WORKSPACE']='true'
            result=subprocess.run(command+['--approval-mode','default','--output-format','json','-p',
                                   'Analyser exclusivement les données sur stdin. Ne pas utiliser d’outils. Retourner uniquement le JSON demandé.'],
                                  input=prompt,text=True,encoding='utf-8',capture_output=True,cwd=temp,
                                  timeout=timeout,shell=False,env=env)
        except subprocess.TimeoutExpired:raise SystemExit('Délai dépassé. Le contexte a pu être transmis. Vérifier le CLI avant de relancer.')
    if result.returncode:raise SystemExit('Gemini CLI a échoué : '+result.stderr[-2000:])
    try:data=parse_response(result.stdout)
    except ValueError as exc:raise SystemExit(str(exc))
    output=path.with_name(path.stem+'_response.json');output.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Réponse enregistrée : '+str(output)+'\nImporter ce JSON dans RG et jointures. Les propositions doivent être validées.')

def choose_file():
    try:
        import tkinter as tk
        from tkinter.filedialog import askopenfilename
        root=tk.Tk();root.withdraw();selected=askopenfilename(title='Choisir gemini_prompt.txt',filetypes=[('Contexte Gemini','*.txt')]);root.destroy()
        return Path(selected) if selected else None
    except ImportError:
        value=input('Chemin du fichier gemini_prompt.txt : ').strip().strip('"');return Path(value) if value else None

if __name__=='__main__':main()
