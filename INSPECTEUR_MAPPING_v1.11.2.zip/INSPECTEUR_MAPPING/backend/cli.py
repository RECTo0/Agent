import argparse
import json
from pathlib import Path
from backend.parsers.excel import read_excel
from backend.analyzer import analyze
from backend.services.reports import export_json,export_html,export_excel
from backend.services.gemini import semantic_prompt

ROOT=Path(__file__).resolve().parents[1]

def main():
    p=argparse.ArgumentParser(description='Analyse locale de mapping Excel')
    p.add_argument('file');p.add_argument('--output',default='reports/latest');p.add_argument('--category');p.add_argument('--normalize',action='store_true');p.add_argument('--overrides')
    args=p.parse_args();config=json.loads((ROOT/'config/settings.json').read_text('utf-8'));schema=json.loads((ROOT/'config/mapping_schema.json').read_text('utf-8'))
    overrides=json.loads(Path(args.overrides).read_text('utf-8')) if args.overrides else None
    doc=read_excel(Path(args.file).read_bytes(),schema,config,overrides)
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if args.normalize:
        (out/'normalized.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8');return
    report=analyze(doc,config);report['filename']=Path(args.file).name
    if args.category:
        report['results']=[x for x in report['results'] if x['category']==args.category]
        report['counts']={s:sum(x['status']==s for x in report['results']) for s in report['counts']}
        report['metrics']['controls']=len(report['results'])
    for name,data in [('results.json',export_json(report)),('rapport.html',export_html(report)),('controles.xlsx',export_excel(report))]:
        (out/name).write_bytes(data)
    (out/'gemini_prompt.txt').write_text(semantic_prompt(report),encoding='utf-8')
    print(json.dumps(report['counts'],ensure_ascii=False))

if __name__=='__main__':main()
