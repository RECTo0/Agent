"""Loopback-only local HTTP application. Python 3.10+, no web framework required."""
import argparse
import copy
import re
import base64
import concurrent.futures
import hashlib
import json
import logging
import mimetypes
import secrets
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from backend.parsers.excel import read_excel
from backend.analyzer import analyze
from backend.services.storage import Store
from backend.services.compare import compare
from backend.services.reports import export_json,export_excel,export_html
from backend.services.gemini import semantic_prompt
from backend.services.gemini_runner import GeminiRunner
from backend.services.lineage import catalog, graph, compare_graph, network, neighborhood
from backend.validators.joins import text_hash
from backend.validators.evolution import validate_groups
from backend.services.coherence import overview, revision, effective_config

ROOT=Path(__file__).resolve().parents[1]

class Application:
    def __init__(self,root=ROOT,data_dir=None):
        self.root=root;self.data=data_dir or root/'data';self.data.mkdir(exist_ok=True,parents=True)
        self.store=Store(self.data/'guardian.sqlite3');self.token=secrets.token_urlsafe(32)
        self.uploads={};self.jobs={};self.lock=threading.Lock();self.pool=concurrent.futures.ThreadPoolExecutor(max_workers=2)
        self.gemini=GeminiRunner(self)
    def settings(self):return json.loads((self.root/'config/settings.json').read_text('utf-8'))
    def schema(self):return json.loads((self.root/'config/mapping_schema.json').read_text('utf-8'))
    def upload(self,payload):
        name=Path(str(payload.get('filename',''))).name
        if not name.lower().endswith('.xlsx'):raise ValueError('Format accepté : .xlsx. Convertir les fichiers .xls dans Excel.')
        try:raw=base64.b64decode(payload['data'],validate=True)
        except Exception as exc:raise ValueError('Contenu du fichier invalide.') from exc
        cfg=self.settings()
        if len(raw)>cfg['max_upload_mb']*1024**2:raise ValueError('Fichier trop volumineux.')
        schema=self.schema();doc=read_excel(raw,schema,cfg,payload.get('overrides'))
        id=uuid.uuid4().hex
        path=self.data/(id+'.xlsx');path.write_bytes(raw)
        self.uploads[id]={'path':path,'filename':name,'schema':schema}
        # Only keep small handles; workbook bytes and normalizations are not retained in RAM.
        return {'upload_id':id,'filename':name,'document':doc}
    def start(self,id,overrides=None):
        if id not in self.uploads:raise ValueError('Import expiré : recharger le fichier.')
        job=uuid.uuid4().hex;self.jobs[job]={'state':'running'}
        upload=dict(self.uploads[id]);cfg=self.settings()
        def run():
            try:
                doc=read_excel(upload['path'].read_bytes(),upload['schema'],cfg,overrides)
                if 'target_field' not in doc['columns'] and 'publication_field' not in doc['columns']:
                    raise ValueError('Affecter au moins la colonne champ cible ou champ publication.')
                report=self.store.save(analyze(doc,cfg),upload['filename'])
                self.jobs[job]={'state':'done','analysis_id':report['id']}
                logging.info('Analysis %s completed (%d controls)',report['id'],len(report['results']))
            except Exception as exc:
                logging.exception('Analysis failed');self.jobs[job]={'state':'error','error':str(exc)}
        self.pool.submit(run);return {'job_id':job}
    def api(self,path,payload=None):
        if path=='/api/session':return {'token':self.token,'version':'1.11.2'}
        if path=='/api/history':return self.store.list()
        if path=='/api/settings':
            if payload is not None:
                candidate=payload.get('settings')
                if not isinstance(candidate,dict):raise ValueError('Configuration JSON requise.')
                for k in ('max_upload_mb','max_uncompressed_mb','max_cells','port'):
                    if not isinstance(candidate.get(k),int) or isinstance(candidate[k],bool) or candidate[k]<=0:raise ValueError('Valeur entière positive requise : '+k)
                if candidate['max_upload_mb']>100 or candidate['max_uncompressed_mb']>500 or candidate['max_cells']>2000000:raise ValueError('Limites de ressources trop élevées.')
                if not 1024<=candidate['port']<=65535:raise ValueError('Port hors plage 1024–65535.')
                for k in ('aliases','source_dictionary','history_policy','gemini'):
                    if not isinstance(candidate.get(k),dict):raise ValueError('Objet requis : '+k)
                if not isinstance(candidate.get('technical_fields'),list):raise ValueError('technical_fields doit être une liste.')
                for k in ('aliases','source_dictionary'):
                    if not all(isinstance(a,str) and isinstance(b,str) for a,b in candidate[k].items()):raise ValueError(k+' doit contenir des paires de chaînes.')
                for k in ('source_keys','join_max_context'):
                    if not isinstance(candidate.get(k,{}),dict):raise ValueError('Objet requis : '+k)
                for table,key in candidate.get('source_keys',{}).items():
                    if not isinstance(key,dict) or not isinstance(key.get('columns'),list) or not all(isinstance(x,str) for x in key['columns']) or not isinstance(key.get('source',''),str):raise ValueError('Déclaration de clé invalide : '+table)
                for key,context in candidate.get('join_max_context',{}).items():
                    if not isinstance(context,dict) or not isinstance(context.get('group_by',[]),list) or not all(isinstance(x,str) for x in context.get('group_by',[])):raise ValueError('Contexte MAX invalide : '+key)
                validate_groups(candidate.get('linked_field_groups',[]))
                dest=self.root/'config/settings.json';temp=dest.with_suffix('.tmp')
                with self.lock:
                    temp.write_text(json.dumps(candidate,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(dest)
            return self.settings()
        if path=='/api/coherence' and payload is not None:
            report=self.store.get(payload['analysis_id']) if payload.get('analysis_id') else None
            action=payload.get('action','read')
            if action not in ('read','save','reanalyze'):raise ValueError('Action de cohérence inconnue.')
            with self.lock:
                settings=self.settings()
                if action=='save':
                    groups=payload.get('groups')
                    validate_groups(groups)
                    if payload.get('revision')!=revision(settings.get('linked_field_groups',[])):
                        raise ValueError('Les groupes ont changé dans une autre page. Rechargez avant de réessayer.')
                    # New/changed exceptions must bind to the server's current documentary evidence.
                    previous=settings.get('linked_field_groups',[])
                    for group in groups:
                        ex=group.get('exception')
                        if not ex:continue
                        if any(g.get('exception')==ex and sorted(g['members'])==sorted(group['members']) for g in previous):continue
                        if not report:raise ValueError('Choisir un mapping pour documenter une exception.')
                        probe=dict(settings,linked_field_groups=[group])
                        check=overview(report,probe)['checks'][0]
                        if ex['fingerprint']!=check['fingerprint'] or check['exception_state']!='Applicable':
                            raise ValueError('Exception non vérifiable pour ce mapping. Actualisez la page.')
                    settings['linked_field_groups']=groups
                    dest=self.root/'config/settings.json';temp=dest.with_suffix('.tmp')
                    temp.write_text(json.dumps(settings,ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(dest)
            if action=='reanalyze':
                if not report:raise ValueError('Choisir une analyse à actualiser.')
                return self.store.save(analyze(report['document'],effective_config(report,settings)),report['filename'])
            return overview(report,settings)
        if path=='/api/upload' and payload is not None:return self.upload(payload)
        if path=='/api/analyze' and payload is not None:return self.start(payload['upload_id'],payload.get('overrides'))
        if path.startswith('/api/job/'):return self.jobs.get(path.rsplit('/',1)[-1],{'state':'error','error':'Tâche introuvable.'})
        if path=='/api/trace' and payload is not None:
            g=network(self.store.get(payload['analysis_id']))
            if payload.get('node_id'):return {**neighborhood(g,payload['node_id']),'warnings':g['warnings']}
            return g
        if path=='/api/lineage' and payload is not None:
            report=self.store.get(payload['analysis_id']);before=self.store.get(payload['before_id']) if payload.get('before_id') else None
            targets={x['key']:x for x in catalog(report)}
            if before:targets.update({x['key']:x for x in catalog(before)})
            key=payload.get('target')
            return {'targets':sorted(targets.values(),key=lambda x:x['key']),'graph':(compare_graph(before,report,key) if before else graph(report,key)) if key else None}
        if path=='/api/compare' and payload is not None:return compare(self.store.get(payload['before']),self.store.get(payload['after']))
        pieces=path.split('/')
        if len(pieces)>=4 and pieces[2]=='analysis':
            id=pieces[3];report=self.store.get(id)
            if len(pieces)==4:return report
            if pieces[4]=='assistant':
                if payload is None:return self.gemini.history(id)
                action=payload.get('action')
                if action=='prepare':return self.gemini.prepare(id,payload.get('question',''),payload.get('focus',''))
                if action=='start':
                    preview=self.gemini.previews.get(payload.get('preview_id'),{})
                    if preview.get('purpose')!='chat':raise ValueError('Préparation de conversation requise.')
                    return self.gemini.start(id,payload)
                if action=='cancel':return self.gemini.cancel(id,payload['job_id'])
                raise ValueError('Action assistant inconnue.')
            if pieces[4]=='gemini':
                if payload is None:return self.gemini.get(id)
                action=payload.get('action')
                if action=='prepare':return self.gemini.prepare(id)
                if action=='start':return self.gemini.start(id,payload)
                if action=='cancel':return self.gemini.cancel(id,payload['job_id'])
                if action=='raw':return self.gemini.raw(id,payload['job_id'])
                raise ValueError('Action Gemini inconnue.')
            if pieces[4]=='language-review':
                if payload is not None:
                    if payload.get('action')=='start':return self.store.start_review(id)
                    if payload.get('action')=='decision':return self.store.proposal_event(id,payload)
                    raise ValueError('Action de revue inconnue.')
                return self.store.language_review(id)
            if pieces[4]=='reanalyze' and payload is not None:
                config=self.settings();config.update(copy.deepcopy(report.get('config',{})))
                return self.store.save(analyze(report['document'],config),report['filename'])
            if pieces[4]=='max-context' and payload is not None:
                rule=next((r for r in report['document']['rules'] if r['id']==payload.get('rule_id') and r['row']==payload.get('row') and r['sheet']==payload.get('sheet')),None)
                if not rule:raise ValueError('Règle inconnue.')
                table=str(payload.get('table','')).strip().upper()
                alias=str(payload.get('alias','')).strip().upper()
                date=str(payload.get('date_column','')).strip().upper()
                group=payload.get('group_by',[]);key=payload.get('key_columns',[])
                if not isinstance(group,list) or not isinstance(key,list):raise ValueError('Clés sous forme de listes requises.')
                for value in [table,alias,date]+group+key:
                    if not isinstance(value,str) or not re.fullmatch(r'[A-Z][A-Z0-9_]*',value):raise ValueError('Identifiants simples en majuscules requis.')
                if not re.search(r'\bMAX\s*\(\s*'+re.escape(alias)+r'\.'+re.escape(date)+r'\s*\)',rule['text'],re.I):raise ValueError('Le MAX déclaré ne correspond pas au texte de la règle.')
                scope=payload.get('scope')
                if scope not in ('unknown','per_key','global'):raise ValueError('Périmètre du MAX invalide.')
                if scope=='per_key' and not group:raise ValueError('Préciser les colonnes de regroupement du MAX.')
                source=payload.get('source','')
                if not isinstance(source,str) or not source.strip():raise ValueError('Indiquer la source de votre déclaration (dictionnaire, confirmation métier…).')
                if not key:raise ValueError('Préciser les colonnes de la PK.')
                config=self.settings();config.update(copy.deepcopy(report.get('config',{})))
                config.setdefault('aliases',{})[alias]=table
                config.setdefault('source_keys',{})[table]={'kind':'PK','columns':key,'confirmed':True,'source':source.strip()[:2000]}
                config.setdefault('join_max_context',{})[rule['id']]={'table':table,'date_column':date,'group_by':group,'scope':scope,'source':source.strip()[:2000],'text_sha256':text_hash(rule['text'])}
                return self.store.save(analyze(report['document'],config),report['filename'])
            if pieces[4]=='events':
                if payload is not None:self.store.event(id,payload['finding_id'],payload)
                return self.store.events(id)
            if pieces[4]=='semantic':
                if payload is not None:self.store.add_semantic(id,payload)
                return self.store.semantic(id)
        raise ValueError('Route inconnue.')


def handler(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,fmt,*args):logging.info(fmt,*args)
        def send(self,data,status=200,mime='application/json; charset=utf-8',filename=None):
            if not isinstance(data,bytes):data=json.dumps(data,ensure_ascii=False).encode()
            self.send_response(status);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('X-Frame-Options','DENY')
            self.send_header('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; frame-ancestors 'none'")
            if filename:self.send_header('Content-Disposition','attachment; filename="'+filename+'"')
            self.end_headers();self.wfile.write(data)
        def safe_host(self):
            host=self.headers.get('Host','')
            return host in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}')
        def do_GET(self):
            try:
                if not self.safe_host():return self.send({'error':'Hôte refusé.'},403)
                url=urlsplit(self.path);path=url.path
                if path.startswith('/api/export/'):
                    p=path.split('/');report=app.store.get(p[3]);fmt=p[4]
                    report['review_events']=app.store.events(p[3]);report['semantic_reviews']=app.store.semantic(p[3]);report['language_review']=app.store.language_review(p[3]);report['language_reviews']=report['language_review']['proposals']
                    if fmt=='accepted':return self.send({'input_sha256':report['input_sha256'],'proposals':[x for x in report['language_reviews'] if x['decision']=='Proposition retenue']},filename='propositions_retenues.json')
                    if fmt=='json':return self.send(export_json(report),mime='application/json',filename='results.json')
                    if fmt=='xlsx':return self.send(export_excel(report),mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',filename='controles.xlsx')
                    if fmt=='html':return self.send(export_html(report),mime='text/html; charset=utf-8',filename='rapport_inspecteur_mapping.html')
                    if fmt=='prompt':return self.send(semantic_prompt(report).encode(),mime='text/plain; charset=utf-8',filename='gemini_prompt.txt')
                    raise ValueError('Format inconnu.')
                if path.startswith('/api/'):return self.send(app.api(path))
                target=(app.root/'frontend'/('index.html' if path=='/' else path.lstrip('/'))).resolve()
                if not target.is_relative_to((app.root/'frontend').resolve()) or not target.is_file():return self.send({'error':'Introuvable'},404)
                return self.send(target.read_bytes(),mime={'.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.html':'text/html; charset=utf-8'}.get(target.suffix,mimetypes.guess_type(str(target))[0] or 'application/octet-stream'))
            except ValueError as exc:self.send({'error':str(exc)},400)
            except Exception:logging.exception('GET failed');self.send({'error':'Erreur interne. Consulter data/guardian.log.'},500)
        def do_POST(self):
            try:
                if not self.safe_host() or self.headers.get('X-MQG-Token')!=app.token:return self.send({'error':'Session invalide. Recharger la page.'},403)
                origin=self.headers.get('Origin')
                if origin and origin not in (f'http://127.0.0.1:{self.server.server_port}',f'http://localhost:{self.server.server_port}'):return self.send({'error':'Origine refusée.'},403)
                n=int(self.headers.get('Content-Length',0))
                if n>app.settings()['max_upload_mb']*1024**2*2:return self.send({'error':'Requête trop volumineuse.'},413)
                payload=json.loads(self.rfile.read(n));return self.send(app.api(urlsplit(self.path).path,payload))
            except (ValueError,KeyError,TypeError) as exc:self.send({'error':str(exc)},400)
            except Exception:logging.exception('POST failed');self.send({'error':'Erreur interne. Consulter data/guardian.log.'},500)
    return Handler


def main():
    p=argparse.ArgumentParser();p.add_argument('--no-browser',action='store_true');p.add_argument('--port',type=int);args=p.parse_args()
    app=Application();logging.basicConfig(filename=app.data/'guardian.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
    port=args.port or app.settings()['port']
    try:server=ThreadingHTTPServer(('127.0.0.1',port),handler(app))
    except OSError as exc:raise SystemExit(f'Port {port} indisponible. Fermer l’instance existante ou modifier config/settings.json. {exc}')
    url=f'http://127.0.0.1:{port}';print('Inspecteur Mapping : '+url+' — Ctrl+C pour arrêter.',flush=True)
    if not args.no_browser:webbrowser.open(url)
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:server.server_close();app.gemini.close();app.pool.shutdown(wait=True)

if __name__=='__main__':main()
