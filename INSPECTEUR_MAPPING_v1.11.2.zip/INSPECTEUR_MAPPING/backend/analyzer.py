"""Reproducible rule engine, no database and no LLM calls."""
import hashlib
import json
import re
from collections import Counter, defaultdict
from backend.parsers.excel import norm
from backend.validators.types import compatibility, parse_type
from backend.validators.joins import assess_max
from backend.validators.evolution import group_checks

VERSION='1.11.0'
STATUSES=['ANOMALIE','RISQUE','CONFORME','INFORMATION','NON VÉRIFIABLE']
CATEGORIES=['Champs','Types','Jointures','Règles de gestion','Historisation','Cohérence inter-feuilles','Structure']
REF=re.compile(r'\b(?:RG|J|F)_[A-Z0-9_]+\b',re.I)
TABLE=re.compile(r'\b(?:ORZ|MOE|V_MOE)_[A-Z0-9_]+\b',re.I)
QUALIFIED=re.compile(r'\b([A-Za-z][A-Za-z0-9_]*)\.([A-Za-z][A-Za-z0-9_]*)\b')


def logical_key(r):
    return '|'.join([r.get('target_table') or r.get('history_table') or r.get('publication_table') or r.get('publication_history',''),
                     r.get('target_field') or r.get('publication_field') or r.get('source_field','')]).upper()


def analyze(doc,config):
    results=[]; occurrences=Counter(); records=doc['records']; rules=doc['rules']
    byid=defaultdict(list)
    for rule in rules:byid[rule['id']].append(rule)
    def emit(code,category,status,row,fieldkey,description,correction='',missing=None,proof=None,confidence=None,identity=None):
        obj=row.get('target_table') or row.get('history_table') or row.get('publication_table') or row.get('publication_history') or row.get('id','Classeur')
        field=row.get('target_field') or row.get('publication_field','')
        base='|'.join([code, identity or (logical_key(row) if field else row.get('id',obj))])
        occurrences[base]+=1
        ident=hashlib.sha256((base+'|'+str(occurrences[base])).encode()).hexdigest()[:20]
        column=doc['columns'].get(fieldkey) if fieldkey and row.get('sheet')==next(iter(doc['grids'])) else row.get('column')
        evidence=proof if proof is not None else [{k:v for k,v in row.items() if k not in ('has_image',) and v!=''}]
        results.append({'id':ident,'rule':code,'category':category,'severity':{'ANOMALIE':'Élevée','RISQUE':'Modérée','NON VÉRIFIABLE':'À qualifier'}.get(status,'Faible'),
                        'status':status,'object':obj,'field':field,'sheet':row.get('sheet',next(iter(doc['grids']))),
                        'row':row.get('row',doc['header_row']),'column':column,'description':description,
                        'justification':description,'correction':correction or 'Conserver la documentation et faire valider le périmètre du contrôle.',
                        'confidence':confidence if confidence is not None else (1.0 if status in ('ANOMALIE','CONFORME','INFORMATION') else .75),
                        'evidence':evidence,'missing_information':missing or [],'origin':'Déterministe',
                        'consequence':{'ANOMALIE':'Spécification incohérente pour ce contrôle.', 'RISQUE':'Résultat ou implémentation susceptible de différer de l’intention métier.',
                                       'NON VÉRIFIABLE':'Ce point ne peut pas être validé avant clarification.'}.get(status,'Aucune conséquence négative démontrée.')})
    if not records:
        emit('STRUCT_EMPTY','Structure','NON VÉRIFIABLE',{},None,'Aucune ligne de mapping reconnue.','Corriger la ligne d’en-tête et les correspondances.')
    for missing in doc['missing_columns']:
        emit('STRUCT_COLUMN','Structure','NON VÉRIFIABLE',{},None,'Colonne non identifiée : '+missing,'Affecter la colonne dans Import du mapping.',identity=missing)
    for formula in doc['formulas']:
        emit('STRUCT_FORMULA','Structure','NON VÉRIFIABLE',formula,None,'Formule Excel non évaluée par le moteur.','Recalculer dans Excel puis fournir les valeurs métier explicites.',proof=[formula],identity=formula['sheet']+str(formula['row'])+formula['column'])
    for i in doc['images']:
        emit('STRUCT_IMAGE','Structure','NON VÉRIFIABLE',i,None,'Une image est intégrée à la feuille : son contenu n’est pas interprété par les contrôles déterministes.',
             'Consulter l’image et transcrire la règle en texte validé par le BA.',proof=[{k:v for k,v in i.items() if k!='data'}],identity=i['sheet']+str(i['row'])+i['column'])
    duplicates=Counter(logical_key(r) for r in records)
    declarations={(r.get('source_table','').upper(),r.get('source_field','').upper()) for r in records if r.get('source_field')}
    known_tables={r.get('source_table','').upper() for r in records if r.get('source_table')}
    for rule in rules:known_tables.update(t.upper() for t in TABLE.findall(rule['text']))
    aliases={k.upper():v.upper() for k,v in config.get('aliases',{}).items()}
    referenced=Counter(ref.upper() for r in records for k in ('filter','join','expression','publication_expression') for ref in REF.findall(r.get(k,'')))
    publication_views=Counter(r.get('publication_history') for r in records if r.get('publication_history'))
    dominant=publication_views.most_common(1)[0][0] if publication_views else ''
    for r in records:
        field=r.get('target_field',''); pub=r.get('publication_field',''); source=r.get('source_field','')
        expression=r.get('expression',''); description=r.get('description','')
        key=logical_key(r)
        if duplicates[key]>1:
            emit('FIELD_DUPLICATE','Champs','RISQUE',r,'target_field','Plusieurs lignes décrivent la même cible logique.','Documenter les branches/conditions ou supprimer la duplication.',proof=[{'key':key,'count':duplicates[key]}])
        for k in ('source_table','source_field','target_field','target_table','history_table'):
            if r.get(k) and not re.fullmatch(r'[A-Za-z][A-Za-z0-9_$#]*',r[k]):
                emit('FIELD_NAMING','Champs','RISQUE',r,k,'Identifiant non standard : '+r[k],'Vérifier s’il s’agit d’un identifiant Oracle délimité ou d’une expression.',identity=key+k)
        if field:
            if norm(r.get('populated'))=='non':
                emit('FIELD_FEED','Champs','INFORMATION',r,'populated','Champ explicitement non valorisé dans ce mapping.','Confirmer ce choix lors de la validation BA.')
            elif source or expression:
                emit('FIELD_FEED','Champs','CONFORME',r,'source_field' if source else 'expression','Source ou expression déclarée ; ce contrôle ne valide pas son contenu.')
            elif field in config.get('technical_fields',[]):
                emit('FIELD_FEED','Champs','INFORMATION',r,'target_field','Alimentation technique déclarée dans la configuration métier.','Vérifier le mécanisme technique configuré.')
            else:
                technical=bool(re.search(r'technique|substitution|session|intégration|anomalie|qualité|erreurs|validité|séquence|rgpd',description,re.I))
                emit('FIELD_FEED','Champs','NON VÉRIFIABLE' if technical else 'RISQUE',r,'expression',
                     'Aucune source ni expression explicite ; mécanisme technique possible.' if technical else 'Alimentation non décrite pour le champ cible.',
                     'Documenter le calcul, la constante ou le mécanisme technique sans supposer une source manquante.',missing=['Règle d’alimentation'])
            if norm(r.get('required')) in ('oui','true','1') and not (source or expression) and norm(r.get('populated'))=='non':
                emit('FIELD_REQUIRED','Champs','ANOMALIE',r,'required','Le champ est explicitement obligatoire et explicitement non valorisé.','Réconcilier ces deux déclarations.')
            # Only a complete quoted constant proves an overflow without data.
            literal=re.fullmatch(r"(?:toujours\s+)?['\"](.*?)['\"]",expression,flags=re.I)
            target=parse_type(r.get('target_type',''))
            if literal and target and target['family'] in ('VARCHAR2','NVARCHAR2','CHAR') and target['size'] and len(literal.group(1))>target['size']:
                emit('TYPE_LITERAL_OVERFLOW','Types','ANOMALIE',r,'expression','La constante déclarée dépasse la longueur maximale du type cible.','Agrandir le type cible ou corriger la constante.',proof=[{'literal':literal.group(1),'target_type':r.get('target_type')}])
            st=r.get('source_type') or config.get('source_dictionary',{}).get(r.get('source_table','')+'.'+source,'')
            if source:
                status,reason=compatibility(st,r.get('target_type',''))
                if expression and status=='CONFORME':status,reason='NON VÉRIFIABLE','Une transformation est présente ; son type de sortie doit être confirmé.'
                emit('TYPE_SOURCE_TARGET','Types',status,r,'target_type',reason,'Documenter le type source et les conversions explicites.',missing=['Type source'] if not st else [])
            if pub and r.get('target_type') and r.get('publication_type'):
                status,reason=compatibility(r['target_type'],r['publication_type'])
                emit('TYPE_PUBLICATION','Types',status,r,'publication_type',reason,'Vérifier le type exposé et les conversions de la vue.')
            if r.get('history_type') in ('1','2'):
                emit('HIST_TYPE','Historisation','CONFORME',r,'history_type','Attribut déclaré Type '+r['history_type']+'. Ce contrôle porte sur la déclaration uniquement.')
                if r['history_type']=='2' and not r.get('history_table'):
                    emit('HIST_TABLE','Historisation','RISQUE',r,'history_table','Attribut Type 2 sans table historisée documentée.','Préciser où sont conservées les versions.')
            elif r.get('history_type') and norm(r['history_type']) not in ('n a cle','n a','cle'):
                emit('HIST_TYPE_UNKNOWN','Historisation','NON VÉRIFIABLE',r,'history_type','Type d’historisation non reconnu.','Expliciter Type 1, Type 2 ou le mécanisme spécifique.')
            if r.get('scd') and r.get('history_type') in ('1','2') and re.fullmatch('[12]',r['scd']) and r['scd']!=r['history_type']:
                emit('HIST_CONTRADICTION','Historisation','ANOMALIE',r,'scd','Type histo et SCD Behavior déclarent deux types différents.','Harmoniser les deux colonnes.')
        if r.get('publication_history') and r['publication_history']!=dominant and publication_views[dominant]>=3:
            emit('CROSS_PUBLICATION','Cohérence inter-feuilles','RISQUE',r,'publication_history',
                 'Vue historisée différente de la vue majoritaire : '+r['publication_history']+' (majoritaire : '+dominant+').',
                 'Vérifier une éventuelle reprise de nom depuis un autre mapping.',confidence=.9)
        for k in ('filter','join','expression','publication_expression'):
            for ref in REF.findall(r.get(k,'')):
                ref=ref.upper()
                if ref not in byid:
                    emit('CROSS_REFERENCE','Cohérence inter-feuilles','ANOMALIE',r,k,'Référence '+ref+' absente de la feuille des règles.','Ajouter la définition ou corriger la référence.',identity=key+k+ref)
                elif not any(x['text'] or x['has_image'] for x in byid[ref]):
                    emit('CROSS_EMPTY_RULE','Cohérence inter-feuilles','NON VÉRIFIABLE',r,k,'La règle référencée '+ref+' est vide.','Renseigner la règle utilisée.',identity=key+k+ref)
                else:
                    emit('CROSS_REFERENCE','Cohérence inter-feuilles','CONFORME',r,k,'Référence '+ref+' trouvée ; son contenu reste à contrôler.',identity=key+k+ref)
        # Multiple sources are allowed; only require documented traversal for non-primary objects.
        if r.get('source_table') and r['source_table']!=next((x.get('source_table') for x in records if x.get('source_table')),'') and not r.get('join'):
            emit('CROSS_JOIN_LINK','Cohérence inter-feuilles','RISQUE',r,'join','Source secondaire sans référence de jointure sur cette ligne.','Associer la jointure métier adéquate ou documenter une alimentation indépendante.')
        for k in ('expression','publication_expression'):
            for table in TABLE.findall(r.get(k,'')):
                if table.upper() not in known_tables and table not in (r.get('target_table'),r.get('history_table')):
                    emit('CROSS_EXPRESSION_TABLE','Cohérence inter-feuilles','RISQUE',r,k,'Table de transformation non documentée parmi les sources/jointures : '+table,'Déclarer cette dépendance.',identity=key+k+table)
    for rule in rules:
        body=rule['text']; rid=rule['id']; category='Jointures' if rule['kind']=='Jointure' else 'Règles de gestion'
        if len(byid[rid])>1:
            emit('RULE_DUPLICATE','Règles de gestion','RISQUE',rule,None,'Identifiant de règle déclaré plusieurs fois.','Distinguer les variantes ou regrouper la définition.')
        if not body:
            emit('RULE_EMPTY',category,'NON VÉRIFIABLE' if referenced[rid] or rule['has_image'] else 'INFORMATION',rule,None,
                 'Définition textuelle vide'+(' mais une image est présente.' if rule['has_image'] else '.'),
                 'Compléter si la règle est utilisée ; sinon conserver comme emplacement réservé.',missing=['Définition textuelle'])
            continue
        if rule['has_image']:
            emit('RULE_IMAGE',category,'NON VÉRIFIABLE',rule,None,'La règle comprend une image. Validation sémantique humaine nécessaire.','Transcrire la table de décision et préciser les cas limites.')
        if rule['kind']=='Jointure' or re.search(r'\bMAX\s*\(',body,re.I):
            pairs=QUALIFIED.findall(body)
            if not pairs or '=' not in body:
                emit('JOIN_KEYS',category,'NON VÉRIFIABLE',rule,None,'Condition de jointure non reconnue.','Documenter les tables, alias et clés de jointure.')
            else:emit('JOIN_KEYS',category,'CONFORME',rule,None,'Des références qualifiées et une égalité sont documentées ; la cardinalité réelle n’est pas prouvée.')
            if re.search(r'plusieurs|1\s*[-:]\s*[nN]|MAX\s*\(',body,re.I):
                status,description,action,missing,proof=assess_max(rule,config)
                emit('JOIN_MULTIPLICITY',category,status,rule,None,description,action,missing=missing,proof=proof)
            else:emit('JOIN_CARDINALITY',category,'NON VÉRIFIABLE',rule,None,'Cardinalité non démontrable avec ce seul mapping.','Documenter unicité, grain et cardinalité attendue.')
            for alias,field in sorted(set(pairs)):
                table=aliases.get(alias.upper(),alias.upper())
                if table not in known_tables:
                    emit('JOIN_ALIAS',category,'NON VÉRIFIABLE',rule,None,'Alias non déclaré explicitement : '+alias,'Déclarer la correspondance alias/table dans Paramètres.',identity=rid+alias,missing=['Déclaration de l’alias'])
                elif (table,field.upper()) not in declarations and table+'.'+field not in config.get('source_dictionary',{}):
                    emit('CROSS_FIELD','Cohérence inter-feuilles','NON VÉRIFIABLE',rule,None,'Champ de jointure absent des champs projetés : '+alias+'.'+field,
                         'Confirmer le champ dans le dictionnaire source ; un champ non projeté peut être valide.',identity=rid+alias+'.'+field)
        elif rule['kind']=='RG' and not rule['has_image']:
            emit('RULE_SEMANTIC',category,'NON VÉRIFIABLE',rule,None,'La règle en langage naturel nécessite une revue sémantique.','Faire valider conditions, priorités et cas NULL par le BA ou Gemini après autorisation.')
        if re.search(r'\b(?:etc|a definir|a confirmer|selon le cas)\b',norm(body)):
            emit('RULE_AMBIGUITY',category,'RISQUE',rule,None,'La formulation contient une réserve ou une condition non définie.','Remplacer les réserves par des critères testables.')
        # Strict contradiction only for a complete simple conjunction, never prose or OR.
        atom=r"\s*([A-Za-z][A-Za-z0-9_.]*)\s*=\s*'([^']*)'\s*"
        if re.fullmatch(atom+r'(?:AND'+atom+r')+',body,flags=re.I):
            values=defaultdict(set)
            for k,v in re.findall(atom,body):values[k.upper()].add(v)
            if any(len(v)>1 for v in values.values()):
                emit('RULE_CONTRADICTION',category,'ANOMALIE',rule,None,'Une conjonction exige deux constantes distinctes pour le même champ.','Corriger les valeurs ou l’opérateur logique.')
    for table in sorted({r.get('history_table') for r in records if r.get('history_table')}):
        r=next(r for r in records if r.get('history_table')==table)
        policy=config.get('history_policy',{}).get(table,{})
        emit('HIST_POLICY','Historisation','INFORMATION' if policy else 'NON VÉRIFIABLE',r,'history_table',
             'Une politique explicite est disponible dans la configuration, à confronter au traitement.' if policy else 'INIT/DELTA, bornes temporelles, suppressions et égalités de date ne sont pas définis dans une politique structurée.',
             'Documenter la clé métier, les bornes inclusives/exclusives, INIT/DELTA et le départage.',missing=[] if policy else ['Politique temporelle explicite'],identity=table)
        emit('HIST_DATA','Historisation','NON VÉRIFIABLE',r,'history_table','Absence de données : aucun contrôle effectif des chevauchements temporels ou doublons de versions.','Tester ces contraintes sur des jeux de données représentatifs.',identity=table)
    for check in group_checks(records,config,rules):
        emit(check['code'],'Cohérence inter-feuilles',check['status'],check['record'],'source_field',
             check['description'],'Vérifier les alimentations des membres du groupe et la justification métier.',
             proof=check['proof'],identity=json.dumps(check['proof'],sort_keys=True))
    counts={s:sum(x['status']==s for x in results) for s in STATUSES}
    graph=build_graph(doc)
    effective_config={'business':config,'parser_schema_sha256':doc.get('schema_sha256'),'columns':doc['columns'],'header_row':doc['header_row'],'rules_columns':doc.get('rules_columns')}
    config_hash=hashlib.sha256(json.dumps(effective_config,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
    return {'engine_version':VERSION,'input_sha256':doc['sha256'],'config_sha256':config_hash,'results':results,'counts':counts,
            'metrics':{'controls':len(results),'rules':sum(r['kind']=='RG' for r in rules),
                       'joins':sum(r['kind']=='Jointure' and bool(r['text']) for r in rules),
                       'objects':len({logical_key(r).split('|')[0] for r in records}), 'fields':len(records)},
            'document':doc,'graph':graph,'config':config,'effective_config':effective_config}


def build_graph(doc):
    nodes={}; edges=set()
    def node(id,kind,label):nodes[id]={'id':id,'kind':kind,'label':label};return id
    for r in doc['records']:
        sources=[]
        if r.get('source_table'):sources.append(node('source:'+r['source_table'],'Source',r['source_table']))
        previous=sources
        for key,kind in [('join','Jointure'),('expression','Transformation'),('publication_expression','Transformation')]:
            if r.get(key):
                label=r[key]; nid=node(kind+':'+label,kind,label)
                for s in previous:edges.add((s,nid))
                previous=[nid]
        for key in ('target_table','history_table','publication_table','publication_history'):
            if r.get(key):
                target=node('target:'+r[key],'Cible',r[key])
                for s in previous:edges.add((s,target))
    for r in doc['rules']:
        if not r['text']:continue
        rid=node(('Jointure' if r['kind']=='Jointure' else 'Règle')+':'+r['id'],r['kind'],r['id'])
        for table in TABLE.findall(r['text']):edges.add((node('source:'+table.upper(),'Source',table.upper()),rid))
        for ref in REF.findall(r['text']):
            if ref.upper()!=r['id']:edges.add((node('Règle:'+ref.upper(),'Règle',ref.upper()),rid))
    return {'nodes':list(nodes.values()),'edges':[{'from':a,'to':b} for a,b in sorted(edges)]}
