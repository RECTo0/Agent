"""Inspecteur Mapping — local, deterministic mapping review."""
