"""Excel reader: grouped headers, source locations, embedded pictures, no execution."""
import base64
import hashlib
import io
import json
import re
import unicodedata
import zipfile
from collections import Counter
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string


def norm(value):
    text = unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]+', ' ', text.split('\n')[0]).strip()


def text(value):
    return '' if value is None else str(value).strip()


def read_excel(raw, schema, settings, overrides=None):
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            if sum(i.file_size for i in archive.infolist()) > settings['max_uncompressed_mb'] * 1024**2:
                raise ValueError('Classeur décompressé trop volumineux.')
            if any('vbaProject' in i.filename for i in archive.infolist()):
                raise ValueError('Les macros ne sont pas acceptées. Enregistrer une copie .xlsx.')
        wb = load_workbook(io.BytesIO(raw), data_only=False, keep_links=False)
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError('Fichier .xlsx invalide, chiffré ou endommagé.') from exc
    names = [schema['mapping_sheet'], schema['rules_sheet']]
    missing = [n for n in names if n not in wb.sheetnames]
    if missing:
        raise ValueError('Feuille(s) manquante(s) : ' + ', '.join(missing))
    if sum(wb[n].max_row * wb[n].max_column for n in names) > settings['max_cells']:
        raise ValueError('Limite de cellules dépassée. Réduire les lignes/colonnes formatées inutiles.')
    grids, images, formulas = {}, [], []
    for name in names:
        ws = wb[name]
        grid = [[text(c.value) for c in row] for row in ws]
        # Propagate only physically merged cells, never arbitrary blanks.
        for merge in ws.merged_cells.ranges:
            value = grid[merge.min_row-1][merge.min_col-1]
            for r in range(merge.min_row-1, merge.max_row):
                for c in range(merge.min_col-1, merge.max_col):
                    grid[r][c] = value
        grids[name] = grid
        for row in ws:
            for c in row:
                if c.data_type == 'f':
                    formulas.append({'sheet': name, 'row': c.row, 'column': c.column_letter, 'formula': text(c.value)})
        for picture in ws._images:
            anchor = picture.anchor._from
            payload = picture._data()
            images.append({'sheet': name, 'row': anchor.row+1, 'column': get_column_letter(anchor.col+1),
                           'data': 'data:image/' + picture.format + ';base64,' + base64.b64encode(payload).decode()})
    grid = grids[names[0]]
    aliases = schema['fields']
    def label(r, c):
        leaf = norm(grid[r][c]); group = norm(grid[r-1][c]) if r else ''
        return group + '|' + leaf, leaf
    def detect(r):
        detected = {}
        for key, variants in aliases.items():
            scored = []
            for c in range(len(grid[r])):
                full, leaf = label(r, c)
                score = max([3 if '|' in v and full == v else 1 if '|' not in v and leaf == v else 0 for v in variants] or [0])
                if score: scored.append((score, c))
            if scored:
                best = max(s for s,c in scored)
                winners = [c for s,c in scored if s==best]
                if len(winners)==1: detected[key] = get_column_letter(winners[0]+1)
        return detected
    candidates = [(len(detect(r)), r, detect(r)) for r in range(min(30,len(grid)))]
    _, header, columns = max(candidates, key=lambda x:(x[0],-x[1]))
    ov = overrides or schema.get('overrides', {})
    if 'header_row' in ov:
        header = int(ov['header_row'])-1
        if not 0 <= header < len(grid): raise ValueError('Ligne d’en-tête hors feuille.')
        columns = detect(header)
    for key, col in ov.get('columns', {}).items():
        if key not in aliases: raise ValueError('Correspondance inconnue : '+key)
        if col:
            if not re.fullmatch('[A-Z]{1,3}',col) or column_index_from_string(col)>len(grid[header]):
                raise ValueError('Colonne invalide : '+col)
            columns[key]=col
        else: columns.pop(key, None)
    if len(set(columns.values())) != len(columns):
        raise ValueError('Une colonne est affectée à plusieurs rôles. Corriger les correspondances.')
    records = []
    for r in range(header+1,len(grid)):
        row = {k:grid[r][column_index_from_string(v)-1] for k,v in columns.items()}
        if not any(row.get(k) for k in ('target_field','publication_field','source_field')): continue
        row.update(row=r+1, sheet=names[0])
        records.append(row)
    rules = []
    rc = ov.get('rules_columns', schema['rules_columns'])
    rg = grids[names[1]]
    for k in ('id','text'):
        if not re.fullmatch('[A-Z]{1,3}',rc[k]) or column_index_from_string(rc[k])>len(rg[0]):
            raise ValueError('Colonne RG invalide : '+rc[k])
    for r, values in enumerate(rg,1):
        tag = values[column_index_from_string(rc['id'])-1]
        body = values[column_index_from_string(rc['text'])-1]
        match = re.search(r'\b((?:RG|J|F)_[A-Z0-9_]+)\b', tag.upper())
        if match:
            rid=match.group(1)
            rules.append({'id':rid,'kind':{'RG':'RG','J':'Jointure','F':'Filtre'}[rid.split('_')[0]],
                          'text':body,'sheet':names[1],'row':r,'column':rc['text'],
                          'has_image':any(i['sheet']==names[1] and i['row']==r for i in images)})
    return {'schema_sha256':hashlib.sha256(json.dumps(schema,sort_keys=True,ensure_ascii=False).encode()).hexdigest(), 'sha256':hashlib.sha256(raw).hexdigest(), 'records':records,'rules':rules,'grids':grids,
            'images':images,'formulas':formulas, 'header_row':header+1,'columns':columns,'rules_columns':rc,
            'available_columns':[{'column':get_column_letter(c+1),'label':grid[header][c],
                                  'group':grid[header-1][c] if header else ''} for c in range(len(grid[header]))],
            'missing_columns':[k for k in ('target_field','target_table','source_table','source_field','target_type') if k not in columns],
            'fields':list(aliases)}
