"""Documentary lineage checks. No inference of business equivalence from field names."""
import re
import hashlib
import json
from collections import defaultdict

IDENT = re.compile(r'^[A-Z][A-Z0-9_$#]*$')

def upper(value):
    return str(value or '').strip().upper()

def lineage(row, config):
    table, field = upper(row.get('source_table')), upper(row.get('source_field'))
    aliases = {upper(k): upper(v) for k, v in config.get('aliases', {}).items()}
    table = aliases.get(table, table)
    if not IDENT.fullmatch(table) or not IDENT.fullmatch(field):
        return None
    # An RG or expression is not equivalent to a direct projection.
    expr = upper(row.get('expression'))
    if expr and expr not in (field, table+'.'+field, upper(row.get('source_table'))+'.'+field):
        return None
    return table+'.'+field

def index(records, config):
    items = defaultdict(list)
    for row in records:
        field = upper(row.get('target_field'))
        if not field:
            continue
        for table in dict.fromkeys(filter(None, (upper(row.get('target_table')), upper(row.get('history_table'))))):
            items[(table, field)].append({'target':table+'.'+field, 'source':lineage(row, config),
                'sheet':row.get('sheet',''), 'row':row.get('row'), 'record':row})
    return items

def validate_groups(groups):
    if not isinstance(groups, list):
        raise ValueError('linked_field_groups doit être une liste.')
    if len(groups)>200:raise ValueError('Maximum 200 groupes métier.')
    seen=set()
    for group in groups:
        if not isinstance(group, dict) or not isinstance(group.get('reason'),str) or not group['reason'].strip():
            raise ValueError('Chaque groupe doit avoir une justification (reason).')
        members = group.get('members')
        if not isinstance(members, list) or not 2<=len(members)<=200:
            raise ValueError('Un groupe doit contenir au moins deux cibles TABLE.CHAMP.')
        if any(not isinstance(m,str) or len(m.split('.'))!=2 or not all(IDENT.fullmatch(upper(p)) for p in m.split('.')) for m in members):
            raise ValueError('Utiliser des cibles TABLE.CHAMP simples dans members.')
        if len(set(map(upper,members))) != len(members):
            raise ValueError('Les membres du groupe doivent être distincts.')

        if not isinstance(group.get('enabled',True),bool):raise ValueError('enabled doit être un booléen.')
        if not isinstance(group.get('name',''),str) or len(group.get('name',''))>200 or len(group['reason'])>4000:raise ValueError('Nom ou justification trop longs.')
        key=tuple(sorted(map(upper,members)))
        if key in seen:raise ValueError('Ce groupe de cibles existe déjà.')
        seen.add(key)
        exception=group.get('exception')
        if exception is not None:
            if (not isinstance(exception,dict) or not isinstance(exception.get('reason'),str)
                or not exception['reason'].strip() or len(exception['reason'])>4000
                or not isinstance(exception.get('fingerprint'),str)
                or not re.fullmatch('[a-f0-9]{64}',exception['fingerprint'])):
                raise ValueError('Exception : justification et empreinte du mapping requises.')

def group_fingerprint(group, rows, rules=None):
    # Locations can move. Any change to sources, joins, filters or transformations
    # must invalidate the documented exception, including referenced rule changes.
    data=[]
    for member in sorted(map(upper,group['members'])):
        values=[]
        for entry in rows.get(tuple(member.split('.')),[]):
            record=entry['record']
            values.append({'resolved_source':entry['source'],**{k:record.get(k,'') for k in ('source_schema','source_table','source_field','expression','join','filter')}})
        data.append([member,sorted(values,key=lambda v:json.dumps(v,sort_keys=True))])
    return hashlib.sha256(json.dumps([data,sorted([(r.get("id",""),r.get("text","")) for r in (rules or [])])],sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def group_checks(records, config, rules=None):
    rows = index(records,config)
    groups = config.get('linked_field_groups',[])
    try:
        validate_groups(groups)
    except ValueError as exc:
        return [{'code':'LINKED_GROUP_CONFIG','status':'NON VÉRIFIABLE','description':str(exc),'proof':[],'record':records[0] if records else {}}]
    checks=[]
    for group in groups:
        members=[upper(m) for m in group['members']]
        found=[rows.get(tuple(m.split('.')),[]) for m in members]
        complete=all(len(v)==1 and v[0]['source'] for v in found)
        sources={v[0]['source'] for v in found if len(v)==1 and v[0]['source']}
        status='NON VÉRIFIABLE' if not complete else 'RISQUE' if len(sources)>1 else 'CONFORME'
        description={'NON VÉRIFIABLE':'Groupe déclaré non vérifiable : cible absente, multiple ou alimentation indirecte.',
                     'RISQUE':'Sources différentes dans un groupe déclaré devant utiliser la même source.',
                     'CONFORME':'Les champs du groupe déclaré utilisent la même source directe.'}[status]
        fingerprint=group_fingerprint(group,rows,rules)
        exception=group.get('exception')
        exception_state='Aucune'
        if exception:
            exception_state='Applicable' if complete and exception['fingerprint']==fingerprint else 'À revalider'
            if exception_state=='Applicable' and status=='RISQUE':
                status='INFORMATION'
                description='Sources différentes : exception métier documentée. '+exception['reason']
            elif exception_state=='À revalider':description+=' Exception à revalider : le contexte a changé ou ne peut plus être vérifié.'
        if not group.get('enabled',True):
            status='INFORMATION';description='Groupe désactivé : contrôle non appliqué.'
        checks.append({'fingerprint':fingerprint,'exception_state':exception_state,'code':'LINKED_SOURCE_GROUP','status':status,'description':description+' Justification : '+group['reason'],
            'record':next((v[0]['record'] for v in found if v),records[0] if records else {}),
            'proof':[{'target':m,'source':v[0]['source'] if len(v)==1 else None,'locations':[{'sheet':x['sheet'],'row':x['row']} for x in v]} for m,v in zip(members,found)]})
    return checks

def evolution(old, new):
    before=index(old['document']['records'],old.get('config',{}))
    after=index(new['document']['records'],new.get('config',{}))
    usable={k for k in before.keys() & after.keys() if len(before[k])==len(after[k])==1 and before[k][0]['source'] and after[k][0]['source']}
    grouped=defaultdict(list)
    for k in sorted(usable):
        grouped[(k[0],before[k][0]['source'])].append(k)
    warnings=[]
    def add(code,title,keys,why):
        warnings.append({'code':code,'title':title,'level':'Changement partiel constaté','why':why,
            'action':'Vérifier si les sources doivent évoluer ensemble. Si la différence est volontaire, documenter la règle métier ; ne pas remplacer automatiquement la source.',
            'rows':[{'target':before[k][0]['target'],'before':before[k][0]['source'],'after':after[k][0]['source'],
                     'changed':before[k][0]['source']!=after[k][0]['source'],
                     'before_location':{'sheet':before[k][0]['sheet'],'row':before[k][0]['row']},
                     'after_location':{'sheet':after[k][0]['sheet'],'row':after[k][0]['row']}} for k in keys]})
    for (table,source),keys in grouped.items():
        changed=[k for k in keys if before[k][0]['source']!=after[k][0]['source']]
        kept=[k for k in keys if before[k][0]['source']==after[k][0]['source']]
        if changed and kept:
            add('PARTIAL_SOURCE_CHANGE','Changement de source partiel · '+table,keys,
                'Ces champs utilisaient tous '+source+'. Seule une partie utilise maintenant une autre source ; un oubli est possible.')
    for k in sorted(usable):
        h=(k[0]+'_HIST',k[1])
        if h in usable and before[k][0]['source']==before[h][0]['source'] and after[k][0]['source']!=after[h][0]['source']:
            add('CURRENT_HISTORY_DRIFT','Écart courant / historique · '+k[1],[k,h],
                'Les alimentations courant et historique étaient alignées et divergent désormais. Confirmer l’intention métier.')
    skipped=len((before.keys() & after.keys())-usable)
    return {'warnings':warnings,'compared_targets':len(usable),'unverified_targets':skipped,
            'scope':'Sources directes, cibles communes et uniques. Les expressions/RG, cibles ajoutées ou supprimées et renommages ne sont pas assimilés à une migration. Absence d’alerte ne signifie pas conformité globale.'}
