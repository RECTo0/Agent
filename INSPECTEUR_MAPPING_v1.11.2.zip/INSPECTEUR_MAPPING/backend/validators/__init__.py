"""Conservative checks. CONFORME describes only the individual checked property."""
