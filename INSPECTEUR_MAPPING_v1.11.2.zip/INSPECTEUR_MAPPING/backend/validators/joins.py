"""Documentary MAX checks. Never infer database constraints from field names."""
import hashlib
import re


def text_hash(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def assess_max(rule, config):
    text=rule['text']; upper=text.upper()
    matches=re.findall(r'\bMAX\s*\(\s*([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\s*\)',upper)
    context=config.get('join_max_context',{}).get(rule['id'],{})
    if context.get('text_sha256')!=text_hash(text):context={}
    aliases={k.upper():v.upper() for k,v in config.get('aliases',{}).items()}
    evidence=[{'texte':text,'localisation':f"{rule['sheet']}!{rule.get('column','')}{rule['row']}"}]
    def result(status,description,action,missing):
        return status,description,action,missing,evidence
    if len(matches)!=1:
        return result('NON VÉRIFIABLE','La sélection des versions demande un contexte explicite ; plusieurs correspondances ne prouvent pas une erreur.','Préciser le grain attendu et, si nécessaire, le MAX et ses clés de regroupement.',['Expression MAX qualifiée unique et clés de regroupement'])
    alias,date=matches[0];table=aliases.get(alias,alias)
    key=config.get('source_keys',{}).get(table,{})
    cols={x.upper() for x in key.get('columns',[])} if isinstance(key,dict) else set()
    confirmed=key.get('confirmed') is True and key.get('kind')=='PK' and bool(key.get('source','').strip()) if isinstance(key,dict) else False
    group=[x.upper() for x in context.get('group_by',[])]
    scope=context.get('scope','unknown')
    valid_context=(context.get('table','').upper()==table and context.get('date_column','').upper()==date)
    if not valid_context:group=[];scope='unknown'
    evidence.append({'table_MAX':table,'colonne_MAX':date,'cle_declaree':key,'contexte_MAX':context if valid_context else {}})
    if scope=='global':
        return result('INFORMATION','Le MAX est déclaré global. Ce choix doit correspondre à l’intention métier.','Confirmer que la dernière date de toute la table est bien voulue ; aucun doublon n’est démontré.',[])
    if confirmed and scope=='per_key' and group and cols.issubset(set(group)|{date}):
        return result('CONFORME','Selon la PK déclarée et le MAX par clé confirmé, au plus une version est sélectionnée par groupe.','Conserver la PK et le périmètre du MAX documentés. Cette conclusion porte sur la spécification, pas sur l’exécution SQL.',[])
    missing=[]
    if not confirmed:missing.append('PK confirmée avec sa source documentaire')
    if scope!='per_key' or not group:missing.append('Regroupement du MAX confirmé pour la clé correspondante')
    if confirmed and scope=='per_key' and group and not cols.issubset(set(group)|{date}):missing.append('Colonnes de la PK non couvertes par le regroupement et la date')
    return result('NON VÉRIFIABLE','Le MAX ne constitue pas un risque en soi. Les informations disponibles ne suffisent pas à conclure sur l’unicité.','Compléter le contexte du MAX dans « RG et jointures ». Avec une PK (USERID, SYSTEMMODSTAMP) et un MAX par USERID, aucun départage supplémentaire n’est nécessaire.',missing)
