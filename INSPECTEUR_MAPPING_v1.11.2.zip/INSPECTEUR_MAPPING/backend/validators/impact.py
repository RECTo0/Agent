"""Explainable impact review: documentary facts and explicitly labelled heuristics."""
import re
import unicodedata
from collections import defaultdict
from backend.validators.evolution import index, upper, lineage
from backend.validators.types import compatibility

OPTIONS = [
 ('TABLE_MIGRATION','Migration partielle de table'),('OLD_REFERENCE','Anciennes références'),
 ('SOURCE_JOIN','Raccordement de la nouvelle source'),('BUSINESS_MEANING','Sens métier'),
 ('JOIN_LOSS','Jointures et perte de lignes'),('NULL_REQUIRED','NULL et champs obligatoires'),
 ('RULE_IMPACT','Impact des RG modifiées'),('TYPE_CHANGE','Types et capacités'),
 ('DESCRIPTION_MEANING','Description et alimentation'),('MANUAL_REVIEW','Couverture et revue manuelle')]
REF = re.compile(r'\b(?:RG|J|F)_[A-Z0-9_]+\b', re.I)
QUAL = re.compile(r'\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b', re.I)

def plain(s):
 return ''.join(c for c in unicodedata.normalize('NFD',str(s)) if unicodedata.category(c)!='Mn').upper()

def concepts(s):
 s=plain(s); found=set()
 for name,pattern in [('création',r'CREAT|CREATION'),('modification',r'MODIF|LASTMODIFIED|UPDATED'),
                      ('facturation',r'BILLING|FACTURATION'),('client',r'CLIENT|CONSUMER')]:
  if re.search(pattern,s):found.add(name)
 return found

def review_impact(old,new):
 a=index(old['document']['records'],old.get('config',{}));b=index(new['document']['records'],new.get('config',{}))
 rules=defaultdict(list);previous=defaultdict(list)
 for r in new['document']['rules']:rules[upper(r['id'])].append(r)
 for r in old['document']['rules']:previous[upper(r['id'])].append(r)
 cards=[];manual=[]
 aliases={upper(k):upper(v) for k,v in new.get('config',{}).get('aliases',{}).items()}
 def table(t):return aliases.get(upper(t),upper(t))
 def rowview(k):
  def side(idx):
   if len(idx.get(k,[]))!=1:return ('Absent ou plusieurs lignes',None)
   x=idx[k][0];r=x['record'];return (x['source'] or (str(r.get('source_table',''))+'.'+str(r.get('source_field',''))+' · '+str(r.get('expression',''))),{'sheet':x['sheet'],'row':x['row']})
  av,al=side(a);bv,bl=side(b)
  return {'target':'.'.join(k),'before':av,'after':bv,'changed':av!=bv,'before_location':al,'after_location':bl}
 def add(code,title,why,keys=(),evidence=(),level='Risque possible',action='Vérifier et documenter l’intention métier avant de modifier le mapping.'):
  cards.append({'code':code,'title':title,'level':level,'why':why,'action':action,'rows':[rowview(k) for k in sorted(set(keys))], 'evidence':list(evidence)})
 def linked(r):
  ids=set(REF.findall(upper(' '.join(str(r.get(k,'')) for k in ('expression','join','filter')))))
  return [x for rid in sorted(ids) for x in rules.get(rid,[])],ids
 def texts(r,kind):
  rs,_=linked(r)
  return '\n'.join([str(r.get(kind,''))]+[x.get('text','') for x in rs if (kind=='join' and x.get('kind')=='Jointure') or (kind=='filter' and x.get('kind')=='Filtre') or kind=='expression'])
 def evidence(r):return {'rule':r.get('id'),'sheet':r.get('sheet'),'row':r.get('row'),'text':r.get('text','')}
 # 1: table-level migration; sources need not share the same field.
 groups=defaultdict(list)
 for k in sorted(a.keys() & b.keys()):
  if len(a[k])==len(b[k])==1 and a[k][0]['source'] and b[k][0]['source']:
   groups[(k[0],a[k][0]['source'].split('.')[0])].append(k)
 for (target,src),keys in groups.items():
  moved=[k for k in keys if b[k][0]['source'].split('.')[0]!=src];kept=[k for k in keys if b[k][0]['source'].split('.')[0]==src]
  if moved and kept:
   add('TABLE_MIGRATION','Migration partielle · '+target,'Des alimentations quittent '+src+' tandis que d’autres y restent. Cela peut être volontaire ; les champs source ne sont pas nécessairement identiques.',keys)
 # 5/7: rule-level changes and complete dependency list (including transitive RG references).
 for rid in sorted(rules.keys() & previous.keys()):
  if len(rules[rid])!=1 or len(previous[rid])!=1:continue
  now,was=rules[rid][0],previous[rid][0]
  if now.get('text')==was.get('text'):continue
  dependent={rid};changed=True
  while changed:
   changed=False
   for other,rs in rules.items():
    if other not in dependent and any(set(REF.findall(upper(x.get('text','')))) & dependent for x in rs):dependent.add(other);changed=True
  keys=[k for k,v in b.items() if any(linked(x['record'])[1] & dependent for x in v)]
  if now.get('kind')=='RG':
   add('RULE_IMPACT','RG modifiée · '+rid,'Cette RG a changé. Voici toutes les cibles dont les références documentées la rendent dépendante, directement ou via une autre règle.',keys,[{'before':evidence(was),'after':evidence(now)}],'Écart constaté','Revoir chaque alimentation listée, même si sa ligne n’a pas changé. Les références implicites en prose ne sont pas certifiées.')
  if re.search(r'\bLEFT\s+(?:OUTER\s+)?JOIN\b',upper(was.get('text'))) and re.search(r'\bINNER\s+JOIN\b',upper(now.get('text'))):
   add('JOIN_LOSS','Jointure modifiée · '+rid,'Une règle contenant LEFT JOIN contient maintenant INNER JOIN. Vérifier le périmètre exact et les lignes sans correspondance ; aucune perte effective n’est démontrée.',keys,[{'before':evidence(was),'after':evidence(now)}])
 # Per-target review, including new targets and opaque transformations.
 for k,items in sorted(b.items()):
  if len(items)!=1:
   manual.append({'target':'.'.join(k),'reason':'Plusieurs lignes : branches non rapprochables automatiquement.','locations':[{'sheet':x['sheet'],'row':x['row']} for x in items]});continue
  r=items[0]['record'];prior=a.get(k,[]);oldr=prior[0]['record'] if len(prior)==1 else {}
  src=table(r.get('source_table'));oldsrc=table(oldr.get('source_table'))
  rs,ids=linked(r);jt=texts(r,'join');ft=texts(r,'filter');body=texts(r,'expression')
  changed=not oldr or any(r.get(f,'')!=oldr.get(f,'') for f in ('source_table','source_field','expression','source_type','target_type','description','join','filter','required'))
  changed = changed or any(len(rules.get(rid,[]))==len(previous.get(rid,[]))==1 and rules[rid][0].get('text')!=previous[rid][0].get('text') for rid in ids)
  if not items[0]['source']:
   manual.append({'target':'.'.join(k),'reason':'Source indirecte, expression ou RG : équivalence d’alimentation non déterminée.','locations':[{'sheet':r.get('sheet'),'row':r.get('row')}]})
  missing=[rid for rid in ids if len(rules.get(rid,[]))!=1]
  if missing:manual.append({'target':'.'.join(k),'reason':'Références absentes ou ambiguës : '+', '.join(sorted(missing)),'locations':[{'sheet':r.get('sheet'),'row':r.get('row')}]})
  if not changed:continue
  # 2: only associated rules / row text, exact qualified references (not A vs AA).
  if oldsrc and src and oldsrc!=src:
   hits=[evidence(x) for x in rs if any(table(t)==oldsrc for t,f in QUAL.findall(x.get('text','')))]
   inline=' '.join(str(r.get(f,'')) for f in ('expression','join','filter'))
   if any(table(t)==oldsrc for t,f in QUAL.findall(inline)):hits.append({'sheet':r.get('sheet'),'row':r.get('row'),'text':inline})
   if hits:add('OLD_REFERENCE','Ancienne source encore référencée · '+'.'.join(k),'La source passe de '+oldsrc+' à '+src+', mais des règles associées citent encore '+oldsrc+'.',[k],hits)
  # 3: explicit equality establishes a documented connection, not execution validity.
  if src and src!=oldsrc:
   joins='\n'.join(x.get('text','') for vals in rules.values() for x in vals if x.get('kind')=='Jointure')+'\n'+jt
   edges=[(table(t1),table(t2)) for t1,_,t2,_ in re.findall(r'\b([\w]+)\.([\w]+)\s*=\s*([\w]+)\.([\w]+)',joins)]
   other={table(x['record'].get('source_table')) for vals in b.values() for x in vals if x['record'].get('source_table')} - {src}
   connected=any(src in edge and any(t in other for t in edge if t!=src) for edge in edges)
   if other and not connected:add('SOURCE_JOIN','Raccordement à préciser · '+src,'Aucune égalité de jointure explicite reconnue ne relie cette nouvelle source aux autres sources projetées. Une jointure en prose, une source indépendante ou un alias manquant restent possibles.',[k],level='Information manquante',action='Documenter la jointure, déclarer les alias ou confirmer que la source est indépendante.')
  if re.search(r'\bLEFT\s+(?:OUTER\s+)?JOIN\b',upper(oldr.get('join',''))) and re.search(r'\bINNER\s+JOIN\b',upper(r.get('join',''))):
   add('JOIN_LOSS','Jointure de ligne modifiée · '+'.'.join(k),'La ligne passe d’une mention LEFT JOIN à INNER JOIN. Les lignes sans correspondance pourraient être exclues.',[k],[{'before':oldr.get('join'),'after':r.get('join')}])
  # 4/9: lexical clues only, never an automatic semantic contradiction.
  before_mean=concepts(oldr.get('source_field',''));after_mean=concepts(r.get('source_field',''))
  if oldr and before_mean and after_mean and before_mean.isdisjoint(after_mean):
   add('BUSINESS_MEANING','Sens métier à confirmer · '+'.'.join(k),'Les termes reconnus changent de '+', '.join(sorted(before_mean))+' vers '+', '.join(sorted(after_mean))+'. Indice lexical seulement, même si les types sont compatibles.',[k],level='Risque possible',action='Faire confirmer le sens métier dans la revue RG et jointures ; ne pas conclure sur les noms seuls.')
  desc=concepts(r.get('description',''));source=concepts(str(r.get('source_table',''))+' '+str(r.get('source_field','')))
  if desc and source and desc.isdisjoint(source):add('DESCRIPTION_MEANING','Description et source à rapprocher · '+'.'.join(k),'Des termes métier différents sont repérés dans la description et la source. Ce n’est pas une contradiction démontrée.',[k],[{'description':r.get('description'),'source':str(r.get('source_table',''))+'.'+str(r.get('source_field',''))}],action='Relire la description et la RG ; confirmer la cohérence métier ou corriger la documentation.')
  elif r.get('description') and not (desc and source):
   manual.append({'target':'.'.join(k),'reason':'Sens de la description non couvert par le vocabulaire local ; revue sémantique nécessaire.','locations':[{'sheet':r.get('sheet'),'row':r.get('row')}]})
  # 5/6: restricted to explicit LEFT JOIN syntax with the source on the right.
  optional={table(t) for t in re.findall(r'\bLEFT\s+(?:OUTER\s+)?JOIN\s+([A-Z][A-Z0-9_]*)\b',upper(jt))}
  if src in optional:
   rejected=any(table(t)==src for t in re.findall(r'\b([A-Z][A-Z0-9_]*)\.[A-Z0-9_]+\s*(?:IS\s+NOT\s+NULL|=|<>|>=|<=|>|<)',upper(ft)))
   if rejected:add('JOIN_LOSS','Filtre sur source facultative · '+'.'.join(k),'Un filtre associé contient un prédicat susceptible d’écarter les NULL de la source à droite du LEFT JOIN. Les OR et conditions globales nécessitent une revue.',[k],[{'join':jt,'filter':ft}])
   if plain(r.get('required','')) in ('OUI','YES','Y','TRUE','1','O','OBLIGATOIRE'):
    fallback=bool(re.search(r'\b(?:NVL|COALESCE)\s*\(',upper(body)))
    add('NULL_REQUIRED','Champ obligatoire et source facultative · '+'.'.join(k),'La source est à droite d’un LEFT JOIN et la cible est déclarée obligatoire. '+('Une fonction de remplacement existe ; sa couverture et sa valeur restent à valider.' if fallback else 'Aucun NVL/COALESCE explicite n’est reconnu ; une règle en prose peut définir le remplacement.'),[k],[{'join':jt,'required':r.get('required'),'expression':r.get('expression')}],level='Information manquante' if fallback else 'Risque possible',action='Préciser le traitement sans correspondance et démontrer que la cible obligatoire reçoit une valeur valide.')
  # 8: use source dictionary only as a documented type, never live metadata.
  source_type=r.get('source_type') or new.get('config',{}).get('source_dictionary',{}).get(src+'.'+upper(r.get('source_field')),'')
  status,why=compatibility(str(source_type),str(r.get('target_type','')))
  if status!='CONFORME':add('TYPE_CHANGE','Type de l’alimentation à vérifier · '+'.'.join(k),why,[k],[{'source_type':source_type,'target_type':r.get('target_type'),'expression':r.get('expression')}],level='Information manquante' if status=='NON VÉRIFIABLE' else 'Risque possible',action='Confirmer les tailles, unités, formats et conversions, puis tester les valeurs limites. Une transformation peut rendre la projection compatible.')
 for k in sorted(a.keys()-b.keys()):
  manual.append({'target':'.'.join(k),'reason':'Cible supprimée ou renommée : rapprochement automatique impossible.','locations':[{'sheet':x['sheet'],'row':x['row']} for x in a[k]]})
 if manual:add('MANUAL_REVIEW','Alimentations à vérifier manuellement',str(len(manual))+' point(s) ne sont pas couverts automatiquement. Aucun succès de contrôle ne peut en être déduit.',evidence=manual,level='Information manquante',action='Compléter les informations ou effectuer la revue sémantique. Les points restent visibles tant qu’ils ne sont pas vérifiables.')
 return {'cards':cards,'coverage':[{'code':code,'label':label,'count':sum(c['code']==code for c in cards)} for code,label in OPTIONS],
         'limits':'Analyse documentaire et indices lexicaux limités (création, modification, facturation, client). Pas de parseur SQL complet ni de preuve sur les données. Zéro signalement ne signifie pas que le contrôle métier est entièrement vérifié.'}
