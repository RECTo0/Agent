import re


def parse_type(value):
    match=re.search(r'\b(VARCHAR2|NVARCHAR2|CHAR|NUMBER|DATE|TIMESTAMP)\s*(?:\(([^)]*)\))?',value.upper())
    if not match:return None
    family,args=match.groups(); args=args or ''
    nums=re.findall(r'-?\d+|\*',args)
    return {'family':family,'size':int(nums[0]) if nums and nums[0]!='*' else None,
            'scale':int(nums[1]) if len(nums)>1 else 0,
            'unit':'CHAR' if 'CHAR' in args else 'BYTE' if 'BYTE' in args else 'UNSPECIFIED'}


def compatibility(source,target):
    a,b=parse_type(source),parse_type(target)
    if not a or not b:return 'NON VÉRIFIABLE','Type source ou cible absent/non pris en charge.'
    chars={'CHAR','VARCHAR2','NVARCHAR2'}
    if a['family'] in chars and b['family'] in chars:
        if a['unit']!=b['unit']:return 'RISQUE','Sémantiques CHAR/BYTE différentes : capacité à vérifier.'
        if a['size'] and b['size'] and a['size']>b['size']:return 'RISQUE','Capacité cible inférieure à la capacité source (troncature potentielle).'
    elif a['family']==b['family']=='NUMBER':
        if a['size'] is None and b['size'] is not None:return 'RISQUE','NUMBER source non contraint vers une précision cible limitée.'
        if a['size'] and b['size'] and (a['size']-a['scale']>b['size']-b['scale'] or a['scale']>b['scale']):
            return 'RISQUE','Précision ou échelle cible plus restrictive.'
    elif a['family']==b['family']=='TIMESTAMP' and (a['size'] if a['size'] is not None else 6)>(b['size'] if b['size'] is not None else 6):return 'RISQUE','Précision fractionnaire TIMESTAMP réduite.'
    elif a['family']=='TIMESTAMP' and b['family']=='DATE':return 'RISQUE','Perte possible de fractions de seconde et/ou de fuseau.'
    elif a['family']!=b['family']:return 'RISQUE','Conversion entre familles de types : format, NLS et valeurs à vérifier.'
    return 'CONFORME','Compatibilité structurelle des types déclarés ; les valeurs ne sont pas contrôlées.'
