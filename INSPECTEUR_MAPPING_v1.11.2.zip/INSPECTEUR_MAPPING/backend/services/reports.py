import html
import io
import json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

COLUMNS=['id','status','severity','category','object','field','sheet','row','column','rule','description','justification','correction','confidence','evidence','missing_information','origin','consequence']

def export_json(report):
    return json.dumps(report,ensure_ascii=False,indent=2).encode('utf-8')


def export_excel(report):
    wb=Workbook(); ws=wb.active; ws.title='Synthèse'
    ws.append(['Inspecteur Mapping',report.get('filename','')]);ws.append(['Moteur',report['engine_version']])
    for k,v in report['counts'].items():ws.append([k,v])
    ws.append(['Périmètre','Contrôles documentaires du mapping. CONFORME porte sur un contrôle, pas sur le mapping entier.'])
    detail=wb.create_sheet('Contrôles');detail.append(COLUMNS)
    for item in report['results']:
        vals=[]
        for k in COLUMNS:
            v=item.get(k,'')
            if isinstance(v,(list,dict)):v=json.dumps(v,ensure_ascii=False)
            if isinstance(v,str) and v.startswith(('=','+','-','@')):v="'"+v
            vals.append(v)
        detail.append(vals)
    if report.get('language_reviews'):
        review=wb.create_sheet('Reformulations')
        review.append(['Règle','Feuille','Ligne','Texte actuel','Reformulation proposée','Motif','Ambiguïtés à valider','Confiance','Décision','Commentaire'])
        for item in report['language_reviews']:
            review.append([item.get(k,'') for k in ('rule_id','sheet','row','original_text','proposed_text','why')]+['\n'.join(item.get('ambiguities',[])),item.get('confidence',''),item.get('decision','À examiner'),item.get('comment','')])
    for s in wb:
        for row in s:
            for c in row:
                if isinstance(c.value,str) and c.value.startswith(('=','+','-','@')):c.value="'"+c.value
        s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
        for cell in s[1]:cell.font=Font(color='FFFFFF',bold=True);cell.fill=PatternFill('solid',fgColor='122A4C')
        for col in s.columns:
            s.column_dimensions[col[0].column_letter].width=min(55,max(15,len(str(col[0].value or ''))+3))
        for row in s.iter_rows(min_row=2):
            for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
    data=io.BytesIO();wb.save(data);return data.getvalue()


def export_html(report):
    esc=lambda x:html.escape(str(x))
    cards=''.join(f'<div><b>{v}</b><br>{esc(k)}</div>' for k,v in report['counts'].items())
    details=''.join('<article><h3>'+esc(x['status']+' · '+x['object']+' · '+x['field'])+'</h3><p>'+esc(x['description'])+'</p><p><strong>Action :</strong> '+esc(x['correction'])+'</p><small>'+esc(f"{x['sheet']} → Ligne {x['row']} → Colonne {x['column'] or 'non identifiée'} · {x['rule']}")+'</small><details><summary>Preuves</summary><pre>'+esc(json.dumps(x,ensure_ascii=False,indent=2))+'</pre></details></article>' for x in report['results'])
    reviews=''.join('<article><h3>'+esc(x.get('rule_id',''))+' · '+esc(x.get('sheet',''))+' · Ligne '+esc(x.get('row',''))+'</h3><p><strong>Décision :</strong> '+esc(x.get('decision','À examiner'))+' · '+esc(x.get('comment',''))+'</p><p><strong>Texte actuel :</strong> '+esc(x.get('original_text',''))+'</p><p><strong>Reformulation proposée :</strong> '+esc(x.get('proposed_text',''))+'</p><p>'+esc(x.get('why',''))+'</p><p><strong>Questions à clarifier :</strong> '+esc(' · '.join(x.get('ambiguities',[])) or 'Aucune')+'</p></article>' for x in report.get('language_reviews',[]))
    return ('<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Rapport Inspecteur Mapping</title><style>body{font:15px system-ui;background:#f3f6fb;color:#172e50;margin:40px auto;max-width:1200px;padding:20px}h1{color:#1857db}.kpi{display:flex;gap:12px;flex-wrap:wrap}.kpi div,article{background:white;border:1px solid #dde5f0;padding:22px;border-radius:12px;margin-bottom:14px}.kpi b{font-size:28px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}small{color:#536582}@media print{article{break-inside:avoid}}</style><h1>Inspecteur Mapping</h1><p>Rapport complet · '+esc(report.get('filename',''))+'</p><p>Analyse statique — aucune validation des données réelles. Les interprétations et reformulations restent à valider.</p><section class="kpi">'+cards+'</section>'+details+('<h2>Reformulations françaises et suivi</h2>'+reviews if reviews else '')+'</html>').encode('utf-8')
