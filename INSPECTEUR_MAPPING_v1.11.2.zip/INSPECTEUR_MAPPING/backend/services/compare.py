from collections import defaultdict
from backend.analyzer import logical_key
from backend.validators.evolution import evolution
from backend.validators.impact import review_impact


def compare(old,new):
    def changes(a,b,key):
        aa,bb=defaultdict(list),defaultdict(list)
        def clean(r):return {k:v for k,v in r.items() if k not in ('row','sheet','column')}
        for r in a:aa[key(r)].append(clean(r))
        for r in b:bb[key(r)].append(clean(r))
        result=[]
        for k in sorted(set(aa)|set(bb)):
            before,after=aa.get(k,[]),bb.get(k,[])
            if before!=after:result.append({'key':k,'change':'Ajouté' if not before else 'Supprimé' if not after else 'Modifié','before':before,'after':after,
                                            'ambiguous':len(before)>1 or len(after)>1})
        return result
    issue=lambda r:{x['id']:x for x in r['results'] if x['status'] in ('ANOMALIE','RISQUE')}
    a,b=issue(old),issue(new)
    return {'impact':review_impact(old,new),'evolution':evolution(old,new),'fields':changes(old['document']['records'],new['document']['records'],logical_key),
            'rules':changes(old['document']['rules'],new['document']['rules'],lambda r:r['id']),
            'issues':{'new':[b[k] for k in sorted(b.keys()-a.keys())],'resolved':[a[k] for k in sorted(a.keys()-b.keys())],
                      'persistent':[b[k] for k in sorted(a.keys()&b.keys())]},
            'same_engine_config':old['engine_version']==new['engine_version'] and old['config_sha256']==new['config_sha256']}
