"""Graph of documented dependencies; edges do not assert SQL execution order."""
import hashlib
import json
import re
from collections import defaultdict

REF=re.compile(r'\b(?:RG|J|F)_[A-Z0-9_]+\b',re.I)
QUAL=re.compile(r'\b([A-Z][A-Z0-9_]*)\.([A-Z][A-Z0-9_]*)\b',re.I)
def up(s):return str(s or '').strip().upper()
def destinations(r):
    return sorted(set((up(r.get(t)),up(r.get(f))) for t,f in [('target_table','target_field'),('history_table','target_field'),('publication_table','publication_field'),('publication_history','publication_field')] if r.get(t) and r.get(f)))
def catalog(report):
    return [{'key':t+'|'+f,'label':t+'.'+f} for t,f in sorted({v for r in report['document']['records'] for v in destinations(r)})]
def graph(report,key):
    pair=tuple(key.split('|'));rows=[r for r in report['document']['records'] if pair in destinations(r)]
    if not rows:return {'nodes':[],'edges':[],'warnings':['Cible absente dans cette version.']}
    nodes={};edges=set();warnings=[];rules=defaultdict(list);aliases={up(k):up(v) for k,v in report.get('config',{}).get('aliases',{}).items()}
    for r in report['document']['rules']:rules[up(r['id'])].append(r)
    def node(id,kind,label,text='',loc=None,detail=None):
        if id not in nodes:nodes[id]={'id':id,'kind':kind,'label':label,'text':str(text),'locations':[],'detail':detail or {}}
        if loc and loc not in nodes[id]['locations']:nodes[id]['locations'].append(loc)
        return id
    def loc(r):return {'sheet':r.get('sheet',''),'row':r.get('row'),'column':r.get('column','')}
    target=node('target:'+key,'target','.'.join(pair))
    def source(t,f,owner,explicit=False):
        t=aliases.get(up(t),up(t));id=node('source:'+t+'.'+up(f),'source',t+'.'+up(f))
        edges.add((id,owner,'Source déclarée' if explicit else 'Référence textuelle'))
    visited=set()
    def expand(rid,owner):
        id='rule:'+rid
        entries=rules.get(rid,[])
        node(id,'rule',rid,'\n\n'.join(x.get('text','') for x in entries) if entries else 'Référence non trouvée.',detail={'kind':entries[0].get('kind') if len(entries)==1 else 'Ambiguë ou absente'})
        edges.add((id,owner,'Règle référencée'))
        if rid in visited:return
        if len(visited)>=150:
            warnings.append('Exploration limitée à 150 règles. Les dépendances restantes nécessitent une revue manuelle.');return
        visited.add(rid)
        if len(entries)!=1:warnings.append(rid+' : référence '+('absente' if not entries else 'multiple')+'.')
        for r in entries:
            node(id,'rule',rid,loc=loc(r))
            for t,f in QUAL.findall(r.get('text','')):source(t,f,id)
            for ref in sorted(set(REF.findall(up(r.get('text',''))))):
                if ref!=rid:expand(ref,id)
                else:warnings.append('Autoréférence : '+rid)
    for i,r in enumerate(rows):
        # Branch identity independent of row positions; duplicates remain explicitly separate.
        branch=node('branch:'+str(i),'branch','Alimentation '+str(i+1),'Source : '+str(r.get('source_table',''))+'.'+str(r.get('source_field','')),loc(r),{k:r.get(k,'') for k in ('source_table','source_field','source_type','target_type','description','required','expression','filter','join','publication_expression')})
        edges.add((branch,target,'Alimentation décrite'))
        if r.get('source_table') and r.get('source_field'):source(r['source_table'],r['source_field'],branch,True)
        else:warnings.append('Alimentation '+str(i+1)+' : source directe non renseignée.')
        for field,label in [('filter','Filtre'),('join','Jointure'),('expression','Transformation / RG'),('publication_expression','RG publication')]:
            value=str(r.get(field,'')).strip()
            if not value:continue
            if field=='publication_expression' and pair not in [(up(r.get('publication_table')),up(r.get('publication_field'))),(up(r.get('publication_history')),up(r.get('publication_field')))]:continue
            inline=node('inline:'+str(i)+':'+field,'rule',label,value,loc(r))
            edges.add((inline,branch,'Condition documentée'))
            for t,f in QUAL.findall(value):source(t,f,inline)
            for rid in sorted(set(REF.findall(up(value)))):expand(rid,inline)
    if len(rows)>1:warnings.append('Plusieurs lignes décrivent cette cible : les branches ne sont pas fusionnées ni interprétées comme un ordre de priorité.')
    return {'nodes':list(nodes.values()),'edges':[{'from':a,'to':b,'label':c} for a,b,c in sorted(edges)],'warnings':sorted(set(warnings))}
def compare_graph(old,new,key):
    a,b=graph(old,key),graph(new,key);aa={x['id']:x for x in a['nodes']};bb={x['id']:x for x in b['nodes']}
    def signature(x):return (x['kind'],x['label'],x['text'],json.dumps(x['detail'],sort_keys=True))
    nodes=[]
    for id in sorted(aa.keys()|bb.keys()):
        x=dict(bb.get(id,aa.get(id)));x['change']='Ajouté' if id not in aa else 'Supprimé' if id not in bb else 'Modifié' if signature(aa[id])!=signature(bb[id]) else 'Conservé'
        x['before']=aa.get(id);x['after']=bb.get(id);nodes.append(x)
    ae={(e['from'],e['to'],e['label']) for e in a['edges']};be={(e['from'],e['to'],e['label']) for e in b['edges']}
    edges=[{'from':x,'to':y,'label':label,'change':'Ajouté' if (x,y,label) not in ae else 'Supprimé' if (x,y,label) not in be else 'Conservé'} for x,y,label in sorted(ae|be)]
    return {'nodes':nodes,'edges':edges,'warnings':sorted(set(a['warnings']+b['warnings']))+['Les alimentations multiples sont rapprochées par leur position au sein de la cible ; vérifier les permutations de branches.'] if any(n['id']=='branch:1' for n in nodes) else sorted(set(a['warnings']+b['warnings']))}


def network(report):
    """Merge per-target documentary paths with target-scoped branch identities."""
    nodes={};edges=set();warnings=set();targets=catalog(report)
    for entry in targets[:1000]:
        key=entry['key'];g=graph(report,key)
        def identity(id):return key+'::'+id if id.startswith(('branch:','inline:')) else id
        for n in g['nodes']:
            id=identity(n['id'])
            if id not in nodes:nodes[id]={**n,'id':id,'locations':list(n['locations'])}
            else:
                for loc in n['locations']:
                    if loc not in nodes[id]['locations']:nodes[id]['locations'].append(loc)
        for e in g['edges']:edges.add((identity(e['from']),identity(e['to']),e['label']))
        warnings.update(g['warnings'])
    if len(targets)>1000:warnings.add('Vue limitée aux 1000 premières cibles. Les impacts affichés sont partiels.')
    # Include unreferenced rules so the assistant can explain every declared RG.
    for r in report['document']['rules']:
        id='rule:'+up(r['id'])
        if id not in nodes:
            entries=[x for x in report['document']['rules'] if up(x['id'])==up(r['id'])]
            nodes[id]={'id':id,'kind':'rule','label':up(r['id']),'text':'\n\n'.join(x.get('text','') for x in entries),'locations':[{'sheet':x.get('sheet',''),'row':x.get('row'),'column':x.get('column','')} for x in entries],'detail':{'kind':r.get('kind','')}}
    aliases={up(k):up(v) for k,v in report.get('config',{}).get('aliases',{}).items()}
    for n in list(nodes.values()):
        if not n['id'].startswith('rule:'):continue
        for t,f in QUAL.findall(n['text']):
            label=aliases.get(up(t),up(t))+'.'+up(f);id='source:'+label
            if id not in nodes:nodes[id]={'id':id,'kind':'source','label':label,'text':'','locations':[],'detail':{}}
            edges.add((id,n['id'],'Référence textuelle'))
        for ref in sorted(set(REF.findall(up(n['text'])))):
            id='rule:'+ref
            if id==n['id']:continue
            if id not in nodes:
                nodes[id]={'id':id,'kind':'rule','label':ref,'text':'Référence non trouvée.','locations':[],'detail':{}}
                warnings.add(ref+' : référence absente.')
            edges.add((id,n['id'],'Règle référencée'))
    for n in nodes.values():
        n['issues']=[r['id'] for r in report.get('results',[]) if r.get('status') in ('RISQUE','ANOMALIE') and any(r.get('sheet')==loc['sheet'] and r.get('row')==loc['row'] for loc in n['locations'])]
        if n['kind'] in ('source','target'):
            n['table']=n['label'].rsplit('.',1)[0]
    return {'nodes':list(nodes.values()),'edges':[{'from':a,'to':b,'label':c} for a,b,c in sorted(edges)],'warnings':sorted(warnings),'total_targets':len(targets)}


def neighborhood(g,node_id):
    if node_id not in {n['id'] for n in g['nodes']}:raise ValueError('Élément absent du graphe.')
    def walk(reverse=False):
        links=defaultdict(set)
        for e in g['edges']:links[e['to'] if reverse else e['from']].add(e['from'] if reverse else e['to'])
        seen={node_id};pending=[node_id]
        while pending:
            for other in links[pending.pop()]-seen:seen.add(other);pending.append(other)
        return seen
    upstream,downstream=walk(True),walk();visible=upstream|downstream
    return {'upstream':sorted(upstream-{node_id}),'downstream':sorted(downstream-{node_id}),
            'targets':[n for n in g['nodes'] if n['kind']=='target' and n['id'] in downstream],
            'nodes':[n for n in g['nodes'] if n['id'] in visible],
            'edges':[e for e in g['edges'] if e['from'] in visible and e['to'] in visible]}
