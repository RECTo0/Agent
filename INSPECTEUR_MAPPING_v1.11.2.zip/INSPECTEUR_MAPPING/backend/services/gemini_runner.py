"""Explicitly authorized local CLI jobs; previews never start a process."""
import contextlib
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path
from backend.services.gemini import semantic_prompt
from backend.services.storage import now
from backend.services.assistant import context,validate_answer

ACTIVE={'queued','running','validating','cancelling'}
LIMIT=8*1024*1024

def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

def parse_response(raw):
    try:
        obj=json.loads(raw)
        if not isinstance(obj,dict):raise ValueError('Objet JSON attendu.')
        if obj.get('error'):raise ValueError('Le CLI a retourné une erreur : '+str(obj['error'])[:1500])
        if 'response' in obj:
            answer=obj['response']
            if not isinstance(answer,str):raise ValueError('Réponse CLI textuelle attendue.')
            answer=answer.strip()
            if answer.startswith('```'):
                lines=answer.splitlines()
                if len(lines)<3 or lines[-1].strip()!='```':raise ValueError('Bloc JSON incomplet.')
                answer='\n'.join(lines[1:-1])
            obj=json.loads(answer)
        if not isinstance(obj,dict):raise ValueError('Objet de revue attendu.')
        if not isinstance(obj.get('language_reviews'),list):raise ValueError('Le tableau language_reviews est requis pour cette revue.')
        return obj
    except (ValueError,TypeError) as exc:
        raise ValueError('Réponse non exploitable : '+str(exc)+'. La sortie brute reste téléchargeable.') from exc

def command_for(config):
    if config.get('enabled') is not True:raise ValueError('Activez Gemini dans la configuration ci-dessous avant l’envoi.')
    command=config.get('command','gemini');args=config.get('command_args',[])
    if not isinstance(command,str) or not command.strip():raise ValueError('Commande Gemini requise.')
    if not isinstance(args,list) or any(not isinstance(x,str) or '\x00' in x for x in args):raise ValueError('command_args doit être une liste de textes.')
    resolved=shutil.which(command)
    if not resolved:raise ValueError('Commande introuvable : '+command+'. Utilisez npx avec @google/gemini-cli en argument, ou le chemin complet de gemini_local.cmd.')
    timeout=config.get('timeout_seconds',180)
    if not isinstance(timeout,int) or isinstance(timeout,bool) or not 10<=timeout<=1800:raise ValueError('Délai Gemini : entier entre 10 et 1800 secondes.')
    return [resolved,*args],timeout

def terminate_tree(proc):
    if proc.poll() is not None:return
    if os.name=='nt':
        subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],capture_output=True,timeout=10,check=False)
    else:
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
    try:proc.wait(timeout=10)
    except subprocess.TimeoutExpired:proc.kill()

class GeminiRunner:
    def __init__(self,app):
        self.app=app;self.lock=threading.RLock();self.previews={};self.cancelled=set();self.threads=[]
        with app.store.db() as c:
            c.execute('CREATE TABLE IF NOT EXISTS gemini_jobs(id TEXT PRIMARY KEY, analysis_id TEXT, created TEXT, payload TEXT, raw TEXT)')
            for id,payload in c.execute('SELECT id,payload FROM gemini_jobs').fetchall():
                job=json.loads(payload)
                if job['state'] in ACTIVE:
                    job.update(state='interrupted',message='Application redémarrée : résultat non confirmé. Aucun renvoi automatique. Vérifiez avant de relancer.',finished=now())
                    c.execute('UPDATE gemini_jobs SET payload=? WHERE id=?',(json.dumps(job,ensure_ascii=False),id))
    def save(self,job,raw=None):
        with self.app.store.db() as c:
            if raw is None:c.execute('UPDATE gemini_jobs SET payload=? WHERE id=?',(json.dumps(job,ensure_ascii=False),job['id']))
            else:c.execute('UPDATE gemini_jobs SET payload=?,raw=? WHERE id=?',(json.dumps(job,ensure_ascii=False),raw,job['id']))
    def get(self,analysis,id=None):
        jobs=self.history(analysis,include_all=True)
        job=next((j for j in reversed(jobs) if j['id']==id),None) if id else next((j for j in reversed(jobs) if j.get('purpose','review')=='review'),None)
        if not job:return None
        job['elapsed_seconds']=max(0,int(time.time()-job['started_epoch'])) if job['state'] in ACTIVE else job.get('elapsed_seconds',0)
        return job
    def history(self,analysis,include_all=False):
        with self.app.store.db() as c:rows=c.execute('SELECT payload FROM gemini_jobs WHERE analysis_id=? ORDER BY created,id',(analysis,)).fetchall()
        jobs=[json.loads(r[0]) for r in rows]
        return jobs if include_all else [j for j in jobs if j.get('purpose')=='chat']
    def raw(self,analysis,id):
        with self.app.store.db() as c:row=c.execute('SELECT raw FROM gemini_jobs WHERE analysis_id=? AND id=?',(analysis,id)).fetchone()
        if not row:raise ValueError('Tâche inconnue.')
        return {'raw':row[0] or ''}
    def prepare(self,analysis,question=None,focus=""):
        report=self.app.store.get(analysis);cfg=self.app.settings()['gemini'];purpose='chat' if question is not None else 'review';evidence=[]
        if purpose=='chat':
            history=[{'question':j['question'],'answer':j['response']['answer'],'sql_queries':[{k:q[k] for k in ('title','sql','explanation','status')} for q in j['response'].get('sql_queries',[])]} for j in self.history(analysis) if j['state']=='done'][-4:]
            prompt,evidence=context(report,question,focus,history)
        else:prompt=semantic_prompt(report)
        if len(prompt.encode())>LIMIT:raise ValueError('Contexte supérieur à 8 Mo. Réduisez le périmètre du mapping.')
        problem=None
        try:cmd,timeout=command_for(cfg)
        except ValueError as exc:problem=str(exc);cmd=[];timeout=cfg.get('timeout_seconds',180)
        key=uuid.uuid4().hex
        with self.lock:
            self.previews={k:v for k,v in self.previews.items() if time.time()-v['time']<1800}
            if len(self.previews)>=20:self.previews.pop(next(iter(self.previews)))
            self.previews[key]={'analysis':analysis,'prompt':prompt,'config':fingerprint(cfg),'time':time.time(),'purpose':purpose,'question':question,'focus':focus,'evidence':evidence}
        return {'preview_id':key,'prompt':prompt,'characters':len(prompt),'input_sha256':report['input_sha256'],
                'command':cmd,'timeout_seconds':timeout,'problem':problem,'destination':'Service et compte associés à votre configuration Gemini CLI locale.'}
    def start(self,analysis,payload):
        if payload.get('consent') is not True:raise ValueError('Autorisation explicite de cet envoi requise.')
        with self.lock:
            preview=self.previews.get(payload.get('preview_id'))
            if not preview or preview['analysis']!=analysis or time.time()-preview['time']>1800:raise ValueError('Contexte expiré ou absent. Préparez et relisez un nouveau contexte.')
            cfg=self.app.settings()['gemini']
            if fingerprint(cfg)!=preview['config']:raise ValueError('Configuration modifiée. Préparez à nouveau le contexte avant autorisation.')
            cmd,timeout=command_for(cfg)
            with self.app.store.db() as c:
                if any(json.loads(row[0])['state'] in ACTIVE for row in c.execute('SELECT payload FROM gemini_jobs')):raise ValueError('Une revue Gemini est déjà active. Attendez sa fin ou annulez-la.')
                id=uuid.uuid4().hex;job={'id':id,'analysis_id':analysis,'created':now(),'started_epoch':time.time(),'state':'queued','message':'Envoi autorisé, préparation du lancement.','prompt_sha256':hashlib.sha256(preview['prompt'].encode()).hexdigest(),'timeout_seconds':timeout,'has_raw':False,'purpose':preview['purpose'],'question':preview['question'],'focus':preview['focus'],'evidence':preview['evidence']}
                c.execute('INSERT INTO gemini_jobs VALUES(?,?,?,?,?)',(id,analysis,job['created'],json.dumps(job,ensure_ascii=False),''))
            self.previews.pop(payload['preview_id'])
            thread=threading.Thread(target=self.run,args=(job,cmd,timeout,preview['prompt']),daemon=True);self.threads.append(thread);thread.start()
            return dict(job)
    def cancel(self,analysis,id):
        with self.lock:
            job=self.get(analysis,id)
            if not job:raise ValueError('Tâche inconnue.')
            if job['state'] in ACTIVE:
                self.cancelled.add(id);job.update(state='cancelling',message='Arrêt demandé. Le contexte a pu être transmis ; l’annulation ne retire pas un envoi.');self.save(job)
            return job
    def run(self,job,cmd,timeout,prompt):
        proc=None;raw='';directory=tempfile.mkdtemp(prefix='inspecteur-review-')
        try:
            with contextlib.nullcontext(directory):
                folder=Path(directory);(folder/'input.txt').write_text(prompt,encoding='utf-8')
                env=os.environ.copy();env['GEMINI_CLI_TRUST_WORKSPACE']='true'
                args=cmd+['--approval-mode','default','--output-format','json','-p','Analyser exclusivement les donnees sur stdin. Ne pas utiliser d outils. Retourner uniquement le JSON demande.']
                with (folder/'input.txt').open('rb') as source,(folder/'output.txt').open('wb') as out,(folder/'error.txt').open('wb') as err:
                    with self.lock:
                        if job['id'] in self.cancelled:raise InterruptedError('Revue annulée avant lancement.')
                        proc=subprocess.Popen(args,stdin=source,stdout=out,stderr=err,cwd=directory,env=env,shell=False,
                                              start_new_session=os.name!='nt',creationflags=subprocess.CREATE_NEW_PROCESS_GROUP if os.name=='nt' else 0)
                        job.update(state='running',message='Gemini en cours. Attente de sa réponse ; aucun pourcentage fiable disponible.');self.save(job)
                    began=time.monotonic()
                    while proc.poll() is None:
                        if job['id'] in self.cancelled:raise InterruptedError('Revue annulée. Le contexte a pu être transmis.')
                        if time.monotonic()-began>timeout:raise TimeoutError('Délai dépassé. Le contexte a pu être transmis. Vérifiez le CLI, la connexion et le délai avant une nouvelle tentative.')
                        if (folder/'output.txt').stat().st_size+(folder/'error.txt').stat().st_size>LIMIT:raise ValueError('Sortie CLI trop volumineuse (limite 8 Mo).')
                        time.sleep(.15)
                raw=(folder/'output.txt').read_bytes()[:LIMIT].decode('utf-8-sig',errors='replace')
                error=(folder/'error.txt').read_bytes()[-4000:].decode('utf-8',errors='replace');error=re.sub(r'\x1b\[[0-9;]*m','',error)
                job['has_raw']=bool(raw)
                if proc.returncode:raise ValueError('Gemini CLI a échoué (code '+str(proc.returncode)+') : '+error)
                with self.lock:
                    if job['id'] in self.cancelled:raise InterruptedError('Revue annulée ; réponse non importée.')
                    job.update(state='validating',message='Réponse reçue : validation du JSON, du fichier et des textes d’origine.');self.save(job,raw)
                    if job.get('purpose')=='chat':
                        response=validate_answer(raw,self.app.store.get(job['analysis_id']),job['evidence'])
                        job.update(state='done',message='Réponse disponible avec ses preuves.',response=response)
                    else:
                        data=parse_response(raw)
                        self.app.store.add_semantic(job['analysis_id'],data)
                        job.update(state='done',message='Réponse importée. Les propositions restent à examiner.',proposals=len(data['language_reviews']),recommendations=len(data['recommendations']))
        except Exception as exc:
            job.update(state='cancelled' if isinstance(exc,InterruptedError) else 'timeout' if isinstance(exc,TimeoutError) else 'error',message=str(exc)[:5000])
        finally:
            if proc is not None and proc.poll() is None:
                try:terminate_tree(proc)
                except Exception as exc:job['message']+=' Arrêt du processus à vérifier : '+str(exc)
            shutil.rmtree(directory,ignore_errors=True)
            job.update(finished=now(),elapsed_seconds=max(0,int(time.time()-job['started_epoch'])),has_raw=bool(raw))
            with self.lock:self.save(job,raw);self.cancelled.discard(job['id'])
    def close(self):
        with self.lock:
            with self.app.store.db() as c:
                for id,payload in c.execute('SELECT id,payload FROM gemini_jobs'):
                    if json.loads(payload)['state'] in ACTIVE:self.cancelled.add(id)
        for thread in self.threads:thread.join(timeout=12)
