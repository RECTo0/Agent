import json
import hashlib
import sqlite3
import uuid
from datetime import datetime,timezone


def now():return datetime.now(timezone.utc).isoformat()

class Store:
    def __init__(self,path):
        self.path=path;path.parent.mkdir(parents=True,exist_ok=True)
        with self.db() as c:
            c.executescript('''CREATE TABLE IF NOT EXISTS analyses(id TEXT PRIMARY KEY,created TEXT,filename TEXT,payload TEXT);
            CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,analysis_id TEXT,finding_id TEXT,created TEXT,payload TEXT);
            CREATE TABLE IF NOT EXISTS semantic(id INTEGER PRIMARY KEY,analysis_id TEXT,created TEXT,payload TEXT);
            CREATE TABLE IF NOT EXISTS language_state(analysis_id TEXT PRIMARY KEY,phase TEXT,started TEXT,completed TEXT);
            CREATE TABLE IF NOT EXISTS proposal_events(id INTEGER PRIMARY KEY,analysis_id TEXT,proposal_id TEXT,created TEXT,payload TEXT);''')
    def db(self):return sqlite3.connect(str(self.path),timeout=30)
    def save(self,report,filename):
        report=dict(report,id=uuid.uuid4().hex,created=now(),filename=filename)
        with self.db() as c:c.execute('INSERT INTO analyses VALUES(?,?,?,?)',(report['id'],report['created'],filename,json.dumps(report,ensure_ascii=False)))
        return report
    def get(self,id):
        with self.db() as c:row=c.execute('SELECT payload FROM analyses WHERE id=?',(id,)).fetchone()
        if not row:raise ValueError('Analyse introuvable.')
        return json.loads(row[0])
    def list(self):
        with self.db() as c:rows=c.execute('SELECT payload FROM analyses ORDER BY created DESC').fetchall()
        return [{k:v for k,v in json.loads(r[0]).items() if k in ('id','created','filename','counts','metrics','input_sha256','engine_version')} for r in rows]
    def event(self,analysis,id,payload):
        if id not in {r['id'] for r in self.get(analysis)['results']}:raise ValueError('Contrôle inconnu.')
        if payload.get('state') not in ('Non traité','Analysé','Risque accepté','Faux positif'):raise ValueError('État invalide.')
        if payload['state'] in ('Risque accepté','Faux positif') and not payload.get('justification','').strip():raise ValueError('Une justification est requise.')
        payload={k:str(payload.get(k,''))[:10000] for k in ('state','comment','justification')}
        with self.db() as c:c.execute('INSERT INTO events(analysis_id,finding_id,created,payload) VALUES(?,?,?,?)',(analysis,id,now(),json.dumps(payload,ensure_ascii=False)))
    def events(self,analysis):
        with self.db() as c:rows=c.execute('SELECT id,finding_id,created,payload FROM events WHERE analysis_id=? ORDER BY id',(analysis,)).fetchall()
        return [dict(id=r[0],finding_id=r[1],created=r[2],**json.loads(r[3])) for r in rows]
    def add_semantic(self,analysis,data):
        report=self.get(analysis)
        if not isinstance(data,dict) or data.get('input_sha256')!=report['input_sha256'] or not isinstance(data.get('recommendations'),list):
            raise ValueError('Réponse Gemini : input_sha256 exact et tableau recommendations requis.')
        reviews=data.get('language_reviews',[])
        if not isinstance(reviews,list):raise ValueError('language_reviews doit être une liste.')
        rules={(r['id'],r['sheet'],r['row'],r['text']) for r in report['document']['rules']}
        seen=set()
        for item in reviews:
            required=('rule_id','sheet','row','original_text','proposed_text','why','ambiguities')
            if not isinstance(item,dict) or not all(k in item for k in required):raise ValueError('Chaque reformulation requiert règle, cellule, texte d’origine, proposition et ambiguïtés.')
            if not all(isinstance(item[k],str) for k in ('rule_id','sheet','original_text','proposed_text','why')) or not isinstance(item['row'],int) or isinstance(item['row'],bool) or not isinstance(item['ambiguities'],list) or not all(isinstance(x,str) for x in item['ambiguities']):raise ValueError('Format invalide pour une reformulation française.')
            if (item['rule_id'],item['sheet'],item['row'],item['original_text']) not in rules:raise ValueError('La reformulation ne correspond pas au texte exact d’une règle de cette analyse.')
            key=(item['rule_id'],item['sheet'],item['row'])
            if key in seen:raise ValueError('Une seule proposition par règle et cellule est acceptée dans une revue.')
            seen.add(key)
            if not item['proposed_text'].strip() or not item['why'].strip():raise ValueError('La reformulation et sa justification ne peuvent pas être vides.')
            if 'confidence' in item and (not isinstance(item['confidence'],(int,float)) or isinstance(item['confidence'],bool) or not 0<=item['confidence']<=1):raise ValueError('Confiance hors plage 0–1.')
        for item in data['recommendations']:
            if not isinstance(item,dict) or not all(k in item for k in ('description','evidence','correction')):raise ValueError('Chaque recommandation requiert description, evidence, correction.')
            if not isinstance(item['description'],str) or not isinstance(item['correction'],str) or not isinstance(item['evidence'],list) or not all(isinstance(x,str) for x in item['evidence']):raise ValueError('description/correction doivent être du texte et evidence une liste de textes.')
            if item.get('status','RISQUE') not in ('RISQUE','NON VÉRIFIABLE','INFORMATION'):raise ValueError('Statut sémantique invalide : conserver une interprétation à valider.')
            if 'confidence' in item and (not isinstance(item['confidence'],(int,float)) or isinstance(item['confidence'],bool) or not 0<=item['confidence']<=1):raise ValueError('Confiance hors plage 0–1.')
            if 'missing_information' in item and (not isinstance(item['missing_information'],list) or not all(isinstance(x,str) for x in item['missing_information'])):raise ValueError('missing_information doit être une liste de textes.')
        with self.db() as c:
            c.execute('INSERT INTO semantic(analysis_id,created,payload) VALUES(?,?,?)',(analysis,now(),json.dumps(data,ensure_ascii=False)))
            if 'language_reviews' in data:
                c.execute("INSERT INTO language_state VALUES(?,?,?,?) ON CONFLICT(analysis_id) DO UPDATE SET phase='completed',completed=excluded.completed",(analysis,'completed',None,now()))
    def semantic(self,analysis):
        with self.db() as c:rows=c.execute('SELECT created,payload FROM semantic WHERE analysis_id=? ORDER BY id',(analysis,)).fetchall()
        return [{'created':r[0],'data':json.loads(r[1]),'origin':'Gemini — interprétation à valider'} for r in rows]

    def start_review(self,analysis):
        self.get(analysis)
        with self.db() as c:
            c.execute('INSERT OR REPLACE INTO language_state VALUES(?,?,?,?)',(analysis,'in_progress',now(),None))
        return self.language_review(analysis)

    def language_review(self,analysis):
        self.get(analysis)
        snapshots=[s for s in self.semantic(analysis) if 'language_reviews' in s['data']]
        latest=snapshots[-1] if snapshots else None
        with self.db() as c:
            status=c.execute('SELECT phase,started,completed FROM language_state WHERE analysis_id=?',(analysis,)).fetchone()
            rows=c.execute('SELECT id,proposal_id,created,payload FROM proposal_events WHERE analysis_id=? ORDER BY id',(analysis,)).fetchall()
        events=[dict(id=r[0],proposal_id=r[1],created=r[2],**json.loads(r[3])) for r in rows]
        byid={r['proposal_id']:r for r in events}
        proposals=[]
        for item in latest['data']['language_reviews'] if latest else []:
            identity={k:item[k] for k in ('rule_id','sheet','row','original_text','proposed_text','why','ambiguities')}
            ident=hashlib.sha256(json.dumps(identity,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
            ev=byid.get(ident,{})
            proposals.append(dict(item,proposal_id=ident,decision=ev.get('decision','À examiner'),comment=ev.get('comment','')))
        return {'phase':status[0] if status else ('completed' if latest else 'not_started'),
                'started':status[1] if status else None,'completed':status[2] if status else (latest['created'] if latest else None),
                'proposals':proposals,'events':events}

    def proposal_event(self,analysis,payload):
        proposals=self.language_review(analysis)['proposals']
        if payload.get('proposal_id') not in {p['proposal_id'] for p in proposals}:raise ValueError('Proposition absente ou remplacée par une nouvelle revue.')
        if payload.get('decision') not in ('À examiner','Proposition retenue','À modifier','Écartée'):raise ValueError('Décision inconnue.')
        if not isinstance(payload.get('comment',''),str):raise ValueError('Commentaire textuel requis.')
        record={'decision':payload['decision'],'comment':payload.get('comment','')[:10000]}
        with self.db() as c:c.execute('INSERT INTO proposal_events(analysis_id,proposal_id,created,payload) VALUES(?,?,?,?)',(analysis,payload['proposal_id'],now(),json.dumps(record,ensure_ascii=False)))
        return self.language_review(analysis)
