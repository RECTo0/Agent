"""Explicit business groups and documentary suggestions; no AI calls."""
import copy
import hashlib
import json
from collections import defaultdict
from backend.validators.evolution import index, group_checks


def revision(groups):
    return hashlib.sha256(json.dumps(groups,sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def effective_config(report, settings):
    config=copy.deepcopy(settings)
    config.update(copy.deepcopy(report.get('config',{})))
    # Updating business groups must not silently replace the original analysis' aliases.
    config['linked_field_groups']=copy.deepcopy(settings.get('linked_field_groups',[]))
    return config


def overview(report, settings):
    groups=settings.get('linked_field_groups',[])
    out={'groups':groups,'revision':revision(groups),'checks':[],'suggestions':[],
         'suggestions_total':0,'targets':[],'analysis_groups_match':True}
    if not report:return out
    cfg=effective_config(report,settings)
    records=report['document']['records']
    rows=index(records,cfg)
    out['targets']=sorted('.'.join(k) for k in rows)
    out['checks']=group_checks(records,cfg,report['document']['rules'])
    out['analysis_groups_match']=revision(report.get('config',{}).get('linked_field_groups',[]))==out['revision']
    declared={tuple(sorted(m.upper().strip() for m in g['members'])) for g in groups}
    candidates=defaultdict(list)
    for (table,field),values in sorted(rows.items()):
        if len(values)==1 and values[0]['source']:
            candidates[(table,values[0]['source'])].append(table+'.'+field)
    suggestions=[]
    for (table,source),members in sorted(candidates.items()):
        if 2<=len(members)<=200 and tuple(sorted(members)) not in declared:
            suggestions.append({'name':'Champs liés · '+table,'members':members,'source':source,
                'reason':'','evidence':'Ces champs ont la même source directe dans le mapping. Confirmer leur lien métier avant de créer le groupe.'})
    out['suggestions_total']=len(suggestions)
    out['suggestions']=suggestions[:50]
    return out
