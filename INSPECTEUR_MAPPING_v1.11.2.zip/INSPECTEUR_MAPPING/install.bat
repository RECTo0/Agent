@echo off
setlocal
cd /d "%~dp0"

rem Accept the Python launcher, the usual python command, or python3.
where py >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=py -3"
  goto check_python
)
where python >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=python"
  goto check_python
)
where python3 >nul 2>nul
if not errorlevel 1 (
  set "PYTHON_CMD=python3"
  goto check_python
)
echo Python 3.10 ou plus est introuvable.
echo Installer Python depuis https://www.python.org/downloads/windows/
echo Pendant l'installation, cocher "Add python.exe to PATH", puis relancer ce fichier.
pause
exit /b 1

:check_python
%PYTHON_CMD% -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)"
if errorlevel 1 (
  echo Python 3.10 minimum requis. Installer une version recente depuis python.org.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" %PYTHON_CMD% -m venv .venv
if errorlevel 1 goto error
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error
echo Installation terminee. Double-cliquer sur start.bat.
pause
exit /b 0

:error
echo Installation impossible. Verifier la connexion ou le proxy et les droits du dossier.
pause
exit /b 1
