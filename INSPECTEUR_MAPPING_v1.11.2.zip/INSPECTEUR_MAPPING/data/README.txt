Ce dossier contiendra les imports, guardian.sqlite3 et guardian.log après démarrage.
Aucune donnée de test ni analyse factice n’est préchargée dans le ZIP.
Sauvegarder ce dossier après arrêt du serveur pour conserver les analyses et le suivi.
