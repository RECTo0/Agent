"""Reusable skill adapter to the versioned deterministic engine."""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT))
from backend.cli import main
sys.argv.extend(['--category', 'Types'])
if __name__=='__main__':main()
