import copy
import unittest
from backend.validators.evolution import evolution, group_checks, validate_groups
from backend.services.compare import compare
from backend.analyzer import analyze
from test_engine import doc, CFG

def row(field, source='A', table='MOE_COMPTE', n=3, **kw):
    return dict(source_table=source, source_field='ID', target_table=table, target_field=field, sheet='Mapping HDR',row=n,**kw)
def report(rows, config=None):
    return analyze(doc(rows),copy.deepcopy(config if config is not None else CFG))

class EvolutionTests(unittest.TestCase):
    def setUp(self):
        self.old=report([row('IDMOE'),row('IDMOEORIGINE',n=4)])
        self.new=report([row('IDMOE','B'),row('IDMOEORIGINE',n=4)])
    def test_incident_and_location(self):
        e=compare(self.old,self.new)['evolution'];self.assertEqual(len(e['warnings']),1)
        rows=e['warnings'][0]['rows'];self.assertEqual(rows[0]['after'],'B.ID');self.assertFalse(rows[1]['changed']);self.assertEqual(rows[1]['after_location']['row'],4)
    def test_complete_migration(self):
        self.assertEqual(evolution(self.old,report([row('IDMOE','B'),row('IDMOEORIGINE','B')]))['warnings'],[])
    def test_unchanged(self):self.assertFalse(evolution(self.old,self.old)['warnings'])
    def test_move_rows(self):
        new=report([row('IDMOE',n=20),row('IDMOEORIGINE',n=30)])
        self.assertFalse(evolution(self.old,new)['warnings'])
    def test_unrelated_objects_not_grouped(self):
        old=report([row('IDMOE'),row('IDMOEORIGINE',table='MOE_AUTRE')])
        new=report([row('IDMOE','B'),row('IDMOEORIGINE',table='MOE_AUTRE')])
        self.assertFalse(evolution(old,new)['warnings'])
    def test_new_or_deleted_not_assumed_same(self):
        self.assertFalse(evolution(self.old,report([row('IDMOE','B'),row('NOUVEAU')]))['warnings'])
    def test_ambiguous_branch_excluded(self):
        new=report([row('IDMOE','B'),row('IDMOE','C'),row('IDMOEORIGINE')])
        e=evolution(self.old,new);self.assertEqual(e['unverified_targets'],1);self.assertFalse(e['warnings'])
    def test_rg_not_treated_as_direct(self):
        new=report([row('IDMOE','B',expression='RG_1'),row('IDMOEORIGINE')])
        self.assertEqual(evolution(self.old,new)['unverified_targets'],1);self.assertFalse(evolution(self.old,new)['warnings'])
    def test_case_and_alias(self):
        cfg=copy.deepcopy(CFG);cfg['aliases']={'ALIAS':'A'}
        new=report([row('IDMOE','alias'),row('IDMOEORIGINE','a')],cfg)
        self.assertFalse(evolution(self.old,new)['warnings'])
    def test_history_separate_rows(self):
        old=report([row('IDMOE'),row('IDMOE',table='MOE_COMPTE_HIST')]);new=report([row('IDMOE','B'),row('IDMOE',table='MOE_COMPTE_HIST')])
        self.assertEqual(evolution(old,new)['warnings'][0]['code'],'CURRENT_HISTORY_DRIFT')
    def test_history_shared_row_no_false_drift(self):
        old=report([row('IDMOE',history_table='MOE_COMPTE_HIST')]);new=report([row('IDMOE','B',history_table='MOE_COMPTE_HIST')])
        self.assertFalse(evolution(old,new)['warnings'])
    def test_declared_group(self):
        cfg=copy.deepcopy(CFG);cfg['linked_field_groups']=[{'members':['MOE_COMPTE.IDMOE','MOE_COMPTE.IDMOEORIGINE'],'reason':'Même identifiant métier'}]
        r=report(self.new['document']['records'],cfg)
        found=[x for x in r['results'] if x['rule']=='LINKED_SOURCE_GROUP'];self.assertEqual(found[0]['status'],'RISQUE');self.assertEqual(len(found[0]['evidence']),2)
        self.assertEqual(group_checks(self.old['document']['records'],cfg)[0]['status'],'CONFORME')
        self.assertEqual(group_checks([row('IDMOE')],cfg)[0]['status'],'NON VÉRIFIABLE')
    def test_group_validation(self):
        for groups in ({},[{}],[{'members':['A.ID','a.id'],'reason':'x'}],[{'members':['A.ID','B.ID']} ]):
            with self.assertRaises(ValueError):validate_groups(groups)
    def test_no_implicit_group(self):
        self.assertFalse([x for x in self.new['results'] if x['rule']=='LINKED_SOURCE_GROUP'])
