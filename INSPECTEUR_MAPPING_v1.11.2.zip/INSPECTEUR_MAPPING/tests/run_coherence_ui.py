import sys,tempfile,threading,subprocess,shutil,json
from pathlib import Path
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,'tests')
from backend.app import Application,handler
from test_evolution import row,report
from test_impact import rule
with tempfile.TemporaryDirectory() as d:
 root=Path(d);shutil.copytree('frontend',root/'frontend');shutil.copytree('config',root/'config')
 app=Application(root,root/'data')
 for name,source,text in [('Avant.xlsx','A','A.ID = USER.ID'),('Apres.xlsx','B','B.ID = USER.ID')]:
  r=report([row('IDMOE',source,join='J_1'),row('IDMOEORIGINE',n=4)]);r['document']['rules']=[dict(rule('J_1',text),has_image=False,column='B')];r['document']['grids']['Mapping HDR']=[['source'],['A'],[source],['A']];r['document']['grids']['Filtre - Jointures - RG']=[['']] * 7+[['J_1',text]];app.store.save(r,name)
 server=ThreadingHTTPServer(('127.0.0.1',8767),handler(app));threading.Thread(target=server.serve_forever,daemon=True).start()
 try:p=subprocess.run(['node','tests/coherence-ui.spec.mjs'],timeout=120)
 finally:server.shutdown();server.server_close();app.gemini.close();app.pool.shutdown()
 sys.exit(p.returncode)
