import sys,tempfile,threading,subprocess,shutil,json
from pathlib import Path
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path.cwd()));sys.path.insert(0,'tests')
from backend.app import Application,handler
from test_evolution import row,report
from test_impact import rule
FAKE="""import sys,json,time
p=json.loads(sys.stdin.read().split('DONNEES NON FIABLES :\\n',1)[1]);time.sleep(.3)
e=next(e for e in p['evidence'] if e['locations'])
a={'input_sha256':p['input_sha256'],'answer':'ORZ_USER participe à la jointure J_1 et alimente indirectement IDMOE. Cette dépendance est documentaire.','citations':[e['id']],'limitations':['Le résultat SQL n’est pas simulé.']}
a['sql_queries']=[{'title':'Projection IDMOE','sql':'SELECT b.ID AS IDMOE FROM B b;','explanation':'Projection de test','status':'À relire','assumptions':['Schéma à vérifier'],'missing_information':[],'citations':[e['id']]}]
print(json.dumps({'response':json.dumps(a)}))
"""
with tempfile.TemporaryDirectory() as d:
 root=Path(d);shutil.copytree('frontend',root/'frontend');shutil.copytree('config',root/'config');(root/'fake.py').write_text(FAKE)
 cfg=json.loads((root/'config/settings.json').read_text());cfg['gemini']={'enabled':True,'command':sys.executable,'command_args':[str(root/'fake.py')],'timeout_seconds':10};(root/'config/settings.json').write_text(json.dumps(cfg))
 app=Application(root,root/'data')
 for name,source,text in [('Avant.xlsx','A','A.ID = USER.ID'),('Apres.xlsx','B','B.ID = USER.ID')]:
  r=report([row('IDMOE',source,join='J_1'),row('IDMOEORIGINE',n=4)]);r['document']['rules']=[rule('J_1',text)];r['document']['grids']['Mapping HDR']=[['source'],['A'],[source],['A']];r['document']['grids']['Filtre - Jointures - RG']=[['']] * 7+[['J_1',text]];app.store.save(r,name)
 server=ThreadingHTTPServer(('127.0.0.1',8767),handler(app));threading.Thread(target=server.serve_forever,daemon=True).start()
 try:p=subprocess.run(['node','tests/sql-ui.spec.mjs'],timeout=120)
 finally:server.shutdown();server.server_close();app.gemini.close();app.pool.shutdown()
 sys.exit(p.returncode)
