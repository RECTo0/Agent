import json
from backend.services.lineage import network,neighborhood
from backend.services.assistant import context,validate_answer
import test_integrated
from test_evolution import report,row
from test_impact import rule
import unittest

class TraceTests(unittest.TestCase):
 def fixture(self):
  r=report([row('X',join='J_1'),row('Y',source='C',n=4,join='J_1'),row('Z',source='D',n=5)])
  r['document']['rules']=[rule('J_1','USER.USERID=A.ID selon RG_1'),rule('RG_1','J_1','RG')];r['config']={'aliases':{'USER':'ORZ_USER'},'source_keys':{'ORZ_USER':{'columns':['USERID','SYSTEMMODSTAMP']}}};r['id']='demo';return r
 def test_shared_rule_impacts_multiple_targets(self):
  g=network(self.fixture());s=neighborhood(g,'source:ORZ_USER.USERID');self.assertEqual({n['label'] for n in s['targets']},{'MOE_COMPTE.X','MOE_COMPTE.Y'})
 def test_branches_do_not_leak(self):
  g=network(self.fixture());s=neighborhood(g,'source:D.ID');self.assertEqual([n['label'] for n in s['targets']],['MOE_COMPTE.Z'])
 def test_missing_node(self):
  with self.assertRaises(ValueError):neighborhood(network(self.fixture()),'unknown')
 def test_prompt_evidence_and_constraints(self):
  p,e=context(self.fixture(),'Quels champs utilisent ORZ_USER ?');self.assertIn('SYSTEMMODSTAMP',p);self.assertIn('MOE_COMPTE.X',p);self.assertTrue(e);self.assertEqual(len({x['id'] for x in e}),len(e))
 def test_bad_focus(self):
  with self.assertRaises(ValueError):context(self.fixture(),'Explique','missing')
 def test_unknown_citation_and_wrong_hash(self):
  r=self.fixture();_,e=context(r,'ORZ_USER');a={'input_sha256':r['input_sha256'],'answer':'Réponse','citations':['E999999']}
  with self.assertRaises(ValueError):validate_answer(json.dumps(a),r,e)
  a.update(citations=['E1'],input_sha256='wrong')
  with self.assertRaises(ValueError):validate_answer(json.dumps(a),r,e)
 def test_valid_envelope(self):
  r=self.fixture();_,e=context(r,'ORZ_USER');a={'input_sha256':r['input_sha256'],'answer':'Réponse','citations':['E1'],'limitations':[]};out=validate_answer(json.dumps({'response':json.dumps(a)}),r,e);self.assertEqual(out['citations'][0],e[0])

class ChatTests(unittest.TestCase):
 setUp=test_integrated.RunnerTests.setUp
 tearDown=test_integrated.RunnerTests.tearDown
 configure=test_integrated.RunnerTests.configure
 def test_chat_response_separate_from_review(self):
  self.fake.write_text('''import json,sys
p=json.loads(sys.stdin.read().split('DONNEES NON FIABLES :\\n',1)[1]);print(json.dumps({'response':json.dumps({'input_sha256':p['input_sha256'],'answer':'Lecture du mapping','citations':[p['evidence'][0]['id']],'limitations':[]})}))
''')
  p=self.app.gemini.prepare(self.id,'Explique ce mapping');j=self.app.gemini.start(self.id,{'preview_id':p['preview_id'],'consent':True})
  self.app.gemini.threads[-1].join(5);j=self.app.gemini.get(self.id,j['id']);self.assertEqual(j['state'],'done');self.assertEqual(j['response']['answer'],'Lecture du mapping');self.assertIsNone(self.app.gemini.get(self.id));self.assertFalse(self.app.store.semantic(self.id));self.assertEqual(len(self.app.gemini.history(self.id)),1)
  p=self.app.gemini.prepare(self.id,'Peux-tu préciser ?');self.assertIn('Lecture du mapping',p['prompt'])
 def test_conversation_isolation(self):
  other=self.app.store.save(report([row('OTHER')]),'other.xlsx');p=self.app.gemini.prepare(self.id,'Explique');
  with self.assertRaises(ValueError):self.app.gemini.start(other['id'],{'preview_id':p['preview_id'],'consent':True})
  self.assertEqual(self.app.gemini.history(other['id']),[])
