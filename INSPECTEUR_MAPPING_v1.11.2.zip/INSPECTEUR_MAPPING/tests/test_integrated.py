import copy
import json
import shutil
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from backend.app import Application
from backend.services.gemini_runner import GeminiRunner,parse_response
from backend.services.lineage import graph,catalog,compare_graph
from test_evolution import row,report
from test_impact import rule

FAKE='''import json,sys,time
mode=sys.argv[1]
prompt=sys.stdin.read()
if mode=='sleep':time.sleep(30)
if mode=='fail':print('Authentication required',file=sys.stderr);sys.exit(1)
if mode=='bad':print('not json');sys.exit(0)
data=json.loads(prompt.split('DONNEES NON FIABLES :\\n',1)[1])
answer={'input_sha256':data['input_sha256'] if mode!='hash' else 'wrong','recommendations':[],'language_reviews':[]}
print(json.dumps({'response':json.dumps(answer)}))
'''
class RunnerTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);shutil.copytree(Path(__file__).resolve().parents[1]/'config',self.root/'config')
  self.fake=self.root/'fake.py';self.fake.write_text(FAKE)
  self.app=Application(self.root,self.root/'data');self.r=self.app.store.save(report([row('X')]),'test.xlsx');self.id=self.r['id'];self.configure('ok')
 def tearDown(self):self.app.gemini.close();self.app.pool.shutdown();self.tmp.cleanup()
 def configure(self,mode,enabled=True):
  cfg=self.app.settings();cfg['gemini']={'enabled':enabled,'command':sys.executable,'command_args':[str(self.fake),mode],'timeout_seconds':10};(self.root/'config/settings.json').write_text(json.dumps(cfg))
 def prepare(self):return self.app.api('/api/analysis/'+self.id+'/gemini',{'action':'prepare'})
 def start(self,p):return self.app.api('/api/analysis/'+self.id+'/gemini',{'action':'start','preview_id':p['preview_id'],'consent':True})
 def finish(self):
  for _ in range(150):
   job=self.app.gemini.get(self.id)
   if job['state'] not in ('queued','running','validating','cancelling'):return job
   time.sleep(.03)
  self.fail('job did not finish')
 def test_prepare_never_launches_and_consent_required(self):
  p=self.prepare();self.assertIn('DONNEES',p['prompt']);self.assertIsNone(self.app.gemini.get(self.id))
  with self.assertRaises(ValueError):self.app.gemini.start(self.id,{'preview_id':p['preview_id']})
 def test_disabled_and_missing_command(self):
  self.configure('ok',False);p=self.prepare();self.assertTrue(p['problem'])
  with self.assertRaises(ValueError):self.start(p)
 def test_success_auto_import_and_no_duplicate_retry(self):
  p=self.prepare();self.start(p);self.assertEqual(self.finish()['state'],'done');self.assertEqual(len(self.app.store.semantic(self.id)),1)
  self.assertEqual(self.app.store.language_review(self.id)['phase'],'completed')
  with self.assertRaises(ValueError):self.start(p)
 def test_changed_config_invalidates_consent(self):
  p=self.prepare();self.configure('bad')
  with self.assertRaises(ValueError):self.start(p)
 def test_preview_is_bound_to_analysis(self):
  p=self.prepare();r=self.app.store.save(report([row('Y')]),'other.xlsx')
  with self.assertRaises(ValueError):self.app.gemini.start(r['id'],{'consent':True,'preview_id':p['preview_id']})
 def test_invalid_json_preserved_not_imported(self):
  self.configure('bad');self.start(self.prepare());j=self.finish();self.assertEqual(j['state'],'error');self.assertTrue(j['has_raw']);self.assertFalse(self.app.store.semantic(self.id));self.assertIn('not json',self.app.gemini.raw(self.id,j['id'])['raw'])
 def test_wrong_hash_not_imported(self):
  self.configure('hash');self.start(self.prepare());self.assertEqual(self.finish()['state'],'error');self.assertFalse(self.app.store.semantic(self.id))
 def test_cli_error_explained(self):
  self.configure('fail');self.start(self.prepare());self.assertIn('Authentication',self.finish()['message'])
 def test_cancel_and_single_active(self):
  self.configure('sleep');j=self.start(self.prepare())
  with self.assertRaises(ValueError):self.start(self.prepare())
  self.app.gemini.cancel(self.id,j['id']);self.assertEqual(self.finish()['state'],'cancelled');self.assertFalse(self.app.store.semantic(self.id))
 def test_timeout(self):
  self.configure('sleep');p=self.prepare()
  with patch('backend.services.gemini_runner.command_for',return_value=([sys.executable,str(self.fake),'sleep'],.2)):self.start(p)
  self.assertEqual(self.finish()['state'],'timeout')
 def test_recovery_never_relaunches(self):
  with self.app.store.db() as c:c.execute('INSERT INTO gemini_jobs VALUES(?,?,?,?,?)',('x',self.id,'2027',json.dumps({'id':'x','state':'running','started_epoch':time.time()}),''))
  runner=GeminiRunner(self.app);self.assertEqual(runner.get(self.id)['state'],'interrupted')
 def test_fenced_envelope_and_array_rejected(self):
  self.assertEqual(parse_response(json.dumps({'response':'```json\n{"language_reviews":[]}\n```'}))['language_reviews'],[])
  with self.assertRaises(ValueError):parse_response('[]')

class LineageTests(unittest.TestCase):
 def fixture(self):
  r=report([row('X',join='J_1',expression='RG_1',history_table='MOE_COMPTE_HIST')]);r['document']['rules']=[rule('J_1','A.ID=B.ID'),rule('RG_1','Utiliser B.VALUE selon RG_2','RG'),rule('RG_2','Consulter RG_1','RG')];return r
 def test_target_catalog_history(self):self.assertEqual(len(catalog(self.fixture())),2)
 def test_transitive_cycle_terminates(self):
  g=graph(self.fixture(),'MOE_COMPTE|X');self.assertTrue(any(n['id']=='rule:RG_2' for n in g['nodes']));self.assertLess(len(g['nodes']),20)
 def test_sources_labels_not_execution_order(self):
  g=graph(self.fixture(),'MOE_COMPTE|X');self.assertIn('Référence textuelle',{e['label'] for e in g['edges']});self.assertIn('Source déclarée',{e['label'] for e in g['edges']})
 def test_missing_reference_and_multiple_branches(self):
  r=self.fixture();r['document']['records'].append(row('X',expression='RG_UNKNOWN'));g=graph(r,'MOE_COMPTE|X');self.assertTrue(any('absente' in x for x in g['warnings']));self.assertTrue(any('Plusieurs lignes' in x for x in g['warnings']))
 def test_diff_source_and_rule(self):
  a=self.fixture();b=copy.deepcopy(a);b['document']['records'][0]['source_table']='C';b['document']['rules'][0]['text']='C.ID=B.ID';g=compare_graph(a,b,'MOE_COMPTE|X');changes={n['id']:n['change'] for n in g['nodes']};self.assertEqual(changes['source:C.ID'],'Ajouté');self.assertEqual(changes['rule:J_1'],'Modifié');self.assertEqual(changes['source:A.ID'],'Supprimé')
 def test_row_move_not_semantic_change(self):
  a=self.fixture();b=copy.deepcopy(a);b['document']['records'][0]['row']=100;self.assertTrue(all(n['change']=='Conservé' for n in compare_graph(a,b,'MOE_COMPTE|X')['nodes']))
 def test_missing_target(self):self.assertFalse(graph(self.fixture(),'NOT|HERE')['nodes'])
 def test_publication(self):
  r=report([row('X',publication_table='V_COMPTE',publication_field='Y',publication_expression='RG_P')]);self.assertTrue(any(t['key']=='V_COMPTE|Y' for t in catalog(r)));self.assertTrue(any(n['id']=='rule:RG_P' for n in graph(r,'V_COMPTE|Y')['nodes']))
