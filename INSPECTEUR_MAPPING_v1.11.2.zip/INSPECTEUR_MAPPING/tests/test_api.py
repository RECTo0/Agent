import base64
import json
import tempfile
import threading
import time
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from http.server import ThreadingHTTPServer
from backend.app import Application,handler

ROOT=Path(__file__).resolve().parents[1]

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.app=Application(ROOT,Path(cls.temp.name));cls.server=ThreadingHTTPServer(('127.0.0.1',0),handler(cls.app));cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start();cls.url='http://127.0.0.1:'+str(cls.server.server_port)
    @classmethod
    def tearDownClass(cls):cls.server.shutdown();cls.server.server_close();cls.app.pool.shutdown();cls.temp.cleanup()
    def req(self,path,data=None,token=True):
        headers={'Content-Type':'application/json'}
        if token:headers['X-MQG-Token']=self.app.token
        request=urllib.request.Request(self.url+path,data=json.dumps(data).encode() if data is not None else None,headers=headers)
        with urllib.request.urlopen(request) as response:return response.read(),response.headers
    def test_upload_analysis_exports_and_history(self):
        path=ROOT/'examples/DEMO_OFFRE_v1.xlsx'
        if not path.exists():self.skipTest('Demo absent')
        uploaded=json.loads(self.req('/api/upload',{'filename':path.name,'data':base64.b64encode(path.read_bytes()).decode()})[0])
        job=json.loads(self.req('/api/analyze',{'upload_id':uploaded['upload_id']})[0])
        for _ in range(100):
            status=json.loads(self.req('/api/job/'+job['job_id'])[0])
            if status['state']!='running':break
            time.sleep(.02)
        self.assertEqual(status['state'],'done');id=status['analysis_id']
        report=json.loads(self.req('/api/analysis/'+id)[0]);self.assertGreater(report['counts']['ANOMALIE'],0)
        for fmt in ('json','html','xlsx','prompt','accepted'):
            raw,headers=self.req('/api/export/'+id+'/'+fmt);self.assertTrue(raw);self.assertIn('attachment',headers['Content-Disposition'])
        events=json.loads(self.req('/api/analysis/'+id+'/events',{'finding_id':report['results'][0]['id'],'state':'Analysé','owner':'DEV','comment':'test','justification':''})[0]);self.assertEqual(events[-1]['state'],'Analysé')
        self.assertEqual(json.loads(self.req('/api/analysis/'+id)[0])['results'],report['results'])
        compare=json.loads(self.req('/api/compare',{'before':id,'after':id})[0]);self.assertEqual(compare['fields'],[])
        self.assertTrue(json.loads(self.req('/api/history')[0]))
    def test_csrf_missing_token(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.req('/api/upload',{},False)
        self.assertEqual(ctx.exception.code,403)
    def test_missing_sheet(self):
        # A valid but unsupported payload gets a clear validation error.
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.req('/api/upload',{'filename':'bad.xlsx','data':base64.b64encode(b'bad').decode()})
        self.assertEqual(ctx.exception.code,400)
    def test_path_traversal(self):
        with self.assertRaises(urllib.error.HTTPError) as ctx:self.req('/../config/settings.json')
        self.assertEqual(ctx.exception.code,404)
    def test_static_ui(self):
        raw,headers=self.req('/');self.assertIn(b'Inspecteur Mapping',raw);self.assertIn('Content-Security-Policy',headers)
    def test_foreign_host(self):
        request=urllib.request.Request(self.url+'/api/session',headers={'Host':'evil.example'})
        with self.assertRaises(urllib.error.HTTPError) as ctx:urllib.request.urlopen(request)
        self.assertEqual(ctx.exception.code,403)

if __name__=='__main__':unittest.main()
