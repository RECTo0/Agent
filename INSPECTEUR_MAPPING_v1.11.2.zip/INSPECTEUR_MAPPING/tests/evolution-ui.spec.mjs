// Test sur une instance isolée préchargée avec Avant.xlsx et Apres.xlsx (fixture test_evolution.py).
import {chromium} from 'playwright';
const browser=await chromium.launch({executablePath:process.env.IM_BROWSER_PATH||undefined,args:['--no-sandbox'],headless:true});
const page=await browser.newPage({viewport:{width:1500,height:1050}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto((process.env.IM_TEST_URL||'http://127.0.0.1:8767')+'/#compare');
await page.locator('#before option').first().waitFor({state:'attached'});
const opts=await page.locator('#before option').evaluateAll(x=>x.map(e=>({v:e.value,t:e.textContent})));
await page.locator('#before').selectOption(opts.find(x=>x.t.startsWith('Avant.xlsx')).v);await page.locator('#after').selectOption(opts.find(x=>x.t.startsWith('Apres.xlsx')).v);
await page.locator('#compare-run').click();await page.locator('.evolution-warning').first().waitFor();
if(await page.locator('.source-kept').count()!==1)throw Error('retained source not shown');
await page.screenshot({path:'/tmp/evolution-desktop.png',fullPage:true});
await page.locator('summary').filter({hasText:'Champs devant utiliser'}).click();
await page.locator('#linked-members').fill('MOE_COMPTE.IDMOE\nMOE_COMPTE.IDMOEORIGINE');await page.locator('#linked-reason').fill('Même identifiant métier');
await page.locator('#save-linked-group').click();await page.locator('#linked-feedback').filter({hasText:'Groupe enregistré'}).waitFor();
const dl=page.waitForEvent('download');await page.locator('#export-evolution').click();await dl;
await page.setViewportSize({width:390,height:844});await page.screenshot({path:'/tmp/evolution-mobile.png',fullPage:true});
if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('mobile overflow');
await page.locator('[data-evolution-location="0,1,after"]').click();await page.waitForURL('**/#preview');await page.locator('.selected-row').waitFor();
if(errors.length)throw Error(errors.join('\n'));console.log('UI evolution: PASS (comparison, group, export, source location, mobile).');await browser.close();