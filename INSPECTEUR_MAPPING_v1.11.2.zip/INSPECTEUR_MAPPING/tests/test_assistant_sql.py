import unittest,json,copy
from backend.services.assistant import context,validate_answer
import test_contextual

class SQLAssistantTests(unittest.TestCase):
 def setUp(self):
  self.report=test_contextual.TraceTests().fixture();_,self.evidence=context(self.report,'Propose une requête SQL')
  self.query={'title':'Projection','sql':'SELECT a.ID AS IDMOE\nFROM A a;','explanation':'Projection documentaire','status':'À relire','assumptions':[],'missing_information':[],'citations':['E1']}
  self.answer={'input_sha256':self.report['input_sha256'],'answer':'Proposition SQL','citations':['E1'],'limitations':[],'sql_queries':[self.query]}
 def validate(self):return validate_answer(json.dumps(self.answer),self.report,self.evidence)
 def test_sql_structured_and_cited(self):
  out=self.validate();self.assertEqual(out['sql_queries'][0]['sql'],self.query['sql']);self.assertEqual(out['sql_queries'][0]['citations'][0],self.evidence[0])
 def test_missing_information_forces_incomplete(self):
  self.query['missing_information']=['Clé à préciser'];self.assertEqual(self.validate()['sql_queries'][0]['status'],'À compléter')
 def test_marker_forces_incomplete(self):
  self.query['sql']='SELECT <A_COMPLETER> FROM A';self.assertEqual(self.validate()['sql_queries'][0]['status'],'À compléter')
 def test_invalid_citation_rejected(self):
  self.query['citations']=['E99999']
  with self.assertRaises(ValueError):self.validate()
 def test_bad_shape_rejected(self):
  self.query['sql']=[]
  with self.assertRaises(ValueError):self.validate()
 def test_old_answer_still_supported(self):
  del self.answer['sql_queries'];self.assertEqual(self.validate()['sql_queries'],[])
 def test_context_includes_mapping_schema(self):
  self.report['document']['records'][0]['source_schema']='ODS';prompt,e=context(self.report,'SQL','target:MOE_COMPTE|X');self.assertIn('ODS',prompt);self.assertIn('Oracle 19c',prompt);self.assertTrue(any(x['mapping_lines'] for x in e))
