import {chromium} from 'playwright';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1440,height:1050}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.goto('http://127.0.0.1:8765');await page.waitForSelector('#file');
await page.locator('#file').setInputFiles(path.join(ROOT,'examples/Mapping_OFFRE_original.xlsx'));
await page.waitForSelector('[data-column="target_field"]');if(await page.locator('[data-column="target_field"]').inputValue()!=='L')throw Error('Header mismatch');
await page.locator('#run').click();await page.waitForURL('**/#dashboard');await page.waitForSelector('#table-content');
await page.screenshot({path:path.join(ROOT,'reports/ui-dashboard.png'),fullPage:true});
await page.locator('[data-detail]').first().click();await page.waitForSelector('#finding-state');await page.locator('#finding-state').selectOption('Analysé');await page.locator('#finding-comment').fill('Vérification du parcours automatisé');await page.locator('#save-finding').click();await page.waitForTimeout(400);await page.locator('#close').click();
for(const route of ['home','import','analysis','dashboard','details','recommendations','dependencies','compare','history','settings']){await page.locator(`nav a[href="#${route}"]`).click();await page.waitForTimeout(150);if(!await page.locator('#main').innerText())throw Error('Empty route '+route);}
await page.locator('nav a[href="#details"]').click();await page.locator('#search').fill('THEMATIQUES');await page.waitForTimeout(100);if(!((await page.locator('#table-content').innerText()).includes('THEMATIQUES')))throw Error('Search');await page.locator('#reset').click();
await page.locator('nav a[href="#dependencies"]').click();await page.locator('#graph-search').fill('ORZ');await page.waitForSelector('#graph .matched');
await page.locator('nav a[href="#dashboard"]').click();await page.locator('#theme').click();await page.screenshot({path:path.join(ROOT,'reports/ui-dark.png'),fullPage:true});await page.locator('#theme').click();await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(ROOT,'reports/ui-mobile.png'),fullPage:true});
console.log(JSON.stringify({errors,bodyOverflow:await page.evaluate(()=>document.body.scrollWidth>innerWidth)}));await browser.close();if(errors.length)process.exit(1);
