"""Structural mutations of OOXML fixtures; original examples are never changed."""
import io
import re
import unittest
import zipfile
from xml.etree import ElementTree as ET
from pathlib import Path
from test_engine import ROOT,CFG,SCHEMA,doc,codes
from backend.parsers.excel import read_excel
from backend.analyzer import analyze


def mutate(path,part,fn):
    output=io.BytesIO()
    with zipfile.ZipFile(path) as source,zipfile.ZipFile(output,'w') as dest:
        for name in source.namelist():
            data=source.read(name)
            dest.writestr(name,fn(data) if name==part else data)
    return output.getvalue()

class ParserTests(unittest.TestCase):
    def setUp(self):self.path=ROOT/'examples/DEMO_OFFRE_v1.xlsx'
    def test_reordered_columns(self):
        def move(data):
            root=ET.fromstring(data);ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
            for cell in root.findall('.//s:c',ns):
                address=cell.attrib['r']
                if re.fullmatch('[AB][0-9]+',address):cell.set('r',('B' if address[0]=='A' else 'A')+address[1:])
            return ET.tostring(root)
        d=read_excel(mutate(self.path,'xl/worksheets/sheet1.xml',move),SCHEMA,CFG)
        self.assertEqual(d['columns']['target_field'],'B');self.assertEqual(d['columns']['source_table'],'A')
        self.assertEqual(d['records'][0]['target_field'],'ID')
    def test_missing_sheet(self):
        raw=mutate(self.path,'xl/workbook.xml',lambda s:s.replace(b'Mapping HDR',b'Autre nom'))
        with self.assertRaisesRegex(ValueError,'manquante'):read_excel(raw,SCHEMA,CFG)
    def test_formula_not_executed(self):
        def formula(data):
            root=ET.fromstring(data);ns={'s':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'};cell=root.find('.//s:c[@r="G2"]',ns)
            if cell is None:
                row=root.find('.//s:row[@r="2"]',ns);cell=ET.SubElement(row,'{'+ns['s']+'}c',{'r':'G2'})
            cell.clear();cell.set('r','G2');ET.SubElement(cell,'{'+ns['s']+'}f').text='1+1'
            return ET.tostring(root)
        d=read_excel(mutate(self.path,'xl/worksheets/sheet1.xml',formula),SCHEMA,CFG)
        self.assertTrue(d['formulas']);r=codes(analyze(d,CFG),'STRUCT_FORMULA')[0]
        self.assertEqual(r['status'],'NON VÉRIFIABLE');self.assertEqual(r['column'],'G')
    def test_resource_limit(self):
        cfg=dict(CFG,max_cells=1)
        with self.assertRaisesRegex(ValueError,'cellules'):read_excel(self.path.read_bytes(),SCHEMA,cfg)
    def test_constant_overflow(self):
        d=doc();d['records'][0].update(source_field='',expression="'ABCDEFGHIJ'",target_type='VARCHAR2(3 CHAR)')
        self.assertEqual(codes(analyze(d,CFG),'TYPE_LITERAL_OVERFLOW')[0]['status'],'ANOMALIE')
    def test_parser_config_in_fingerprint(self):
        a=doc();b=doc();b['columns']['target_field']='M'
        self.assertNotEqual(analyze(a,CFG)['config_sha256'],analyze(b,CFG)['config_sha256'])

if __name__=='__main__':unittest.main()
