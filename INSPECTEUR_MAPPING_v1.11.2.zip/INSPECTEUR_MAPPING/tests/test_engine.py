import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from openpyxl import load_workbook
from backend.parsers.excel import read_excel
from backend.analyzer import analyze
from backend.validators.types import compatibility
from backend.services.compare import compare
from backend.services.storage import Store
from backend.services.reports import export_excel,export_html
from backend.app import Application

ROOT=Path(__file__).resolve().parents[1]
CFG=json.loads((ROOT/'config/settings.json').read_text('utf-8'))
SCHEMA=json.loads((ROOT/'config/mapping_schema.json').read_text('utf-8'))

def doc(records=None,rules=None):
    rows=records or [{'source_table':'ORZ_A','source_field':'ID','source_type':'VARCHAR2(50 CHAR)','target_table':'MOE_A','target_field':'ID','target_type':'VARCHAR2(50 CHAR)','row':3,'sheet':'Mapping HDR'}]
    return {'sha256':'test','records':rows,'rules':rules or [],'grids':{'Mapping HDR':[['']] ,'Filtre - Jointures - RG':[['']]},'columns':{'target_field':'L','source_field':'G','target_type':'P'},'header_row':2,'missing_columns':[],'formulas':[],'images':[]}

def codes(report,code):return [r for r in report['results'] if r['rule']==code]

class EngineTests(unittest.TestCase):
    def test_reproducible(self):self.assertEqual(analyze(doc(),CFG),analyze(doc(),CFG))
    def test_ids_survive_row_movement(self):
        a=doc();b=copy.deepcopy(a);b['records'][0]['row']=90
        self.assertEqual([r['id'] for r in analyze(a,CFG)['results']],[r['id'] for r in analyze(b,CFG)['results']])
    def test_absent_reference_is_anomaly(self):
        d=doc();d['records'][0]['join']='J_A_999'
        self.assertEqual(codes(analyze(d,CFG),'CROSS_REFERENCE')[0]['status'],'ANOMALIE')
    def test_constant_no_source(self):
        d=doc();d['records'][0].update(source_field='',expression="toujours 'ORZ'")
        self.assertEqual(codes(analyze(d,CFG),'FIELD_FEED')[0]['status'],'CONFORME')
    def test_non_populated_not_required(self):
        d=doc();d['records'][0].update(source_field='',populated='NON')
        r=analyze(d,CFG);self.assertEqual(codes(r,'FIELD_FEED')[0]['status'],'INFORMATION');self.assertFalse(codes(r,'FIELD_REQUIRED'))
    def test_required_non_populated(self):
        d=doc();d['records'][0].update(source_field='',populated='NON',required='OUI')
        self.assertEqual(codes(analyze(d,CFG),'FIELD_REQUIRED')[0]['status'],'ANOMALIE')
    def test_technical_unknown(self):
        d=doc();d['records'][0].update(source_field='',description='Clé technique de substitution')
        self.assertEqual(codes(analyze(d,CFG),'FIELD_FEED')[0]['status'],'NON VÉRIFIABLE')
    def test_unknown_source_type(self):self.assertEqual(compatibility('','DATE')[0],'NON VÉRIFIABLE')
    def test_precision(self):self.assertEqual(compatibility('NUMBER(20,4)','NUMBER(10,2)')[0],'RISQUE')
    def test_length(self):self.assertEqual(compatibility('VARCHAR2(255 CHAR)','VARCHAR2(5 CHAR)')[0],'RISQUE')
    def test_timestamp_date(self):self.assertEqual(compatibility('TIMESTAMP(6)','DATE')[0],'RISQUE')
    def test_same_types(self):self.assertEqual(compatibility('VARCHAR2(5 CHAR)','VARCHAR2(10 CHAR)')[0],'CONFORME')
    def test_unbounded_number_reduction(self):self.assertEqual(compatibility('NUMBER','NUMBER(5,0)')[0],'RISQUE')
    def test_timestamp_precision(self):self.assertEqual(compatibility('TIMESTAMP(6)','TIMESTAMP(3)')[0],'RISQUE')
    def test_number_star(self):self.assertEqual(compatibility('NUMBER(*,0) DEFAULT 1','NUMBER(*,0) DEFAULT 1')[0],'CONFORME')
    def test_duplicate_not_certain_error(self):
        d=doc();d['records'].append(dict(d['records'][0],row=4))
        r=analyze(d,CFG);self.assertTrue(all(x['status']=='RISQUE' for x in codes(r,'FIELD_DUPLICATE')))
        self.assertEqual(len({x['id'] for x in r['results']}),len(r['results']))
    def test_join_max_without_keys_needs_information(self):
        d=doc(rules=[{'id':'J_A_001','kind':'Jointure','text':'ORZ_A.ID = ORZ_B.ID. Si plusieurs lignes MAX(ORZ_B.DT)','sheet':'Filtre - Jointures - RG','row':5,'column':'B','has_image':False}])
        self.assertEqual(codes(analyze(d,CFG),'JOIN_MULTIPLICITY')[0]['status'],'NON VÉRIFIABLE')
    def test_unprojected_field_not_nonexistent(self):
        d=doc(rules=[{'id':'J_A_001','kind':'Jointure','text':'ORZ_A.X = ORZ_B.ID','sheet':'Filtre - Jointures - RG','row':5,'column':'B','has_image':False}])
        self.assertTrue(all(x['status']=='NON VÉRIFIABLE' for x in codes(analyze(d,CFG),'CROSS_FIELD')))
    def test_strict_contradiction(self):
        d=doc(rules=[{'id':'F_A_001','kind':'Filtre','text':"A.X = 'a' AND A.X = 'b'",'sheet':'Filtre - Jointures - RG','row':2,'column':'B','has_image':False}])
        self.assertEqual(codes(analyze(d,CFG),'RULE_CONTRADICTION')[0]['status'],'ANOMALIE')
        d['rules'][0]['text']="A.X = 'a' OR A.X = 'b'"
        self.assertFalse(codes(analyze(d,CFG),'RULE_CONTRADICTION'))
    def test_compare_ignores_rows(self):
        a=analyze(doc(),CFG);d=doc();d['records'][0]['row']=100;b=analyze(d,CFG)
        c=compare(a,b);self.assertFalse(c['fields']);self.assertFalse(c['issues']['new'])
    def test_compare_changes_and_removals(self):
        a=analyze(doc(),CFG);d=doc();d['records'][0]['target_type']='NUMBER(2)';b=analyze(d,CFG)
        c=compare(a,b);self.assertEqual(len(c['fields']),1);self.assertTrue(c['issues']['new'])
    def test_excel_escape_formula(self):
        r=analyze(doc(),CFG);r['results'][0]['description']='=HYPERLINK("bad")'
        w=load_workbook(io.BytesIO(export_excel(r)));self.assertEqual(w['Contrôles']['K2'].data_type,'s')
    def test_filename_formula_escape(self):
        r=analyze(doc(),CFG);r['filename']='=1+1.xlsx'
        w=load_workbook(io.BytesIO(export_excel(r)));self.assertEqual(w['Synthèse']['B1'].data_type,'s')
    def test_html_escape(self):
        r=analyze(doc(),CFG);r['results'][0]['description']='<script>alert(1)</script>'
        result=export_html(r).decode();self.assertNotIn('<script>',result);self.assertIn('&lt;script&gt;',result)
    def test_storage_keeps_raw(self):
        with tempfile.TemporaryDirectory() as t:
            s=Store(Path(t)/'test.sqlite3');r=s.save(analyze(doc(),CFG),'test.xlsx');original=s.get(r['id'])
            s.event(r['id'],r['results'][0]['id'],{'state':'Analysé','owner':'BA','comment':'vu','justification':''})
            self.assertEqual(original,s.get(r['id']));self.assertEqual(len(s.events(r['id'])),1)
            with self.assertRaises(ValueError):s.event(r['id'],r['results'][0]['id'],{'state':'Faux positif','owner':'BA','justification':''})
    def test_semantic_hash_guard(self):
        with tempfile.TemporaryDirectory() as t:
            s=Store(Path(t)/'test.sqlite3');r=s.save(analyze(doc(),CFG),'test.xlsx')
            with self.assertRaises(ValueError):s.add_semantic(r['id'],{'input_sha256':'wrong','recommendations':[]})
    def test_invalid_xlsx(self):
        with self.assertRaises(ValueError):read_excel(b'not excel',SCHEMA,CFG)

class RealWorkbookTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=ROOT/'examples/Mapping_OFFRE_original.xlsx'
        if not path.exists():raise unittest.SkipTest('Classeur OFFRE non disponible')
        cls.raw=path.read_bytes();cls.doc=read_excel(cls.raw,SCHEMA,CFG)
    def test_grouped_header_detection(self):
        self.assertEqual(self.doc['header_row'],2)
        for key,col in [('source_field','G'),('target_field','L'),('target_type','P'),('publication_field','Z'),('publication_type','AB')]:self.assertEqual(self.doc['columns'][key],col)
    def test_physical_rows(self):
        self.assertEqual(len(self.doc['records']),33)
        self.assertIn(31,[r['row'] for r in self.doc['records']]);self.assertNotIn(30,[r['row'] for r in self.doc['records']])
    def test_image_detected(self):
        self.assertEqual(len(self.doc['images']),1);self.assertEqual(self.doc['images'][0]['row'],8)
        self.assertTrue(next(r for r in self.doc['rules'] if r['id']=='RG_OFF_001')['has_image'])
    def test_publication_outliers(self):self.assertEqual(len(codes(analyze(self.doc,CFG),'CROSS_PUBLICATION')),2)
    def test_source_types_not_invented(self):
        self.assertTrue(all(r['status']=='NON VÉRIFIABLE' for r in codes(analyze(self.doc,CFG),'TYPE_SOURCE_TARGET')))
    def test_same_workbook_twice(self):self.assertEqual(analyze(read_excel(self.raw,SCHEMA,CFG),CFG),analyze(self.doc,CFG))
    def test_override_columns(self):
        d=read_excel(self.raw,SCHEMA,CFG,{'columns':{'source_field':'H','comment':'G'}});self.assertEqual(d['columns']['source_field'],'H')
    def test_duplicate_override_rejected(self):
        with self.assertRaises(ValueError):read_excel(self.raw,SCHEMA,CFG,{'columns':{'source_field':'L'}})

if __name__=='__main__':unittest.main()
