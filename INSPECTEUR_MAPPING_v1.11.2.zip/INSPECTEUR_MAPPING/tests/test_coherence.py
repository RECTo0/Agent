import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from backend.app import Application
from backend.services.coherence import overview
from backend.validators.evolution import group_checks, validate_groups
from test_evolution import row,report
from test_engine import CFG

GROUP={'name':'Identifiants','members':['MOE_COMPTE.IDMOE','MOE_COMPTE.IDMOEORIGINE'],'reason':'Même identifiant métier'}
class CoherenceTests(unittest.TestCase):
    def setUp(self):
        self.cfg=copy.deepcopy(CFG);self.cfg['linked_field_groups']=[copy.deepcopy(GROUP)]
        self.rows=[row('IDMOE','B'),row('IDMOEORIGINE',n=4)]
    def exception(self):
        c=group_checks(self.rows,self.cfg)[0]
        self.cfg['linked_field_groups'][0]['exception']={'reason':'Origine volontairement conservée','fingerprint':c['fingerprint']}
    def test_exception_keeps_evidence(self):
        self.exception();c=group_checks(self.rows,self.cfg)[0]
        self.assertEqual(c['status'],'INFORMATION');self.assertEqual(c['proof'][0]['source'],'B.ID');self.assertEqual(c['exception_state'],'Applicable')
    def test_changed_source_invalidates(self):
        self.exception();self.rows[0]['source_table']='C'
        c=group_checks(self.rows,self.cfg)[0];self.assertEqual(c['status'],'RISQUE');self.assertEqual(c['exception_state'],'À revalider')
    def test_join_and_rule_text_invalidate(self):
        self.exception();self.rows[0]['join']='J_1'
        self.assertEqual(group_checks(self.rows,self.cfg)[0]['exception_state'],'À revalider')
        self.rows[0].pop('join')
        self.assertEqual(group_checks(self.rows,self.cfg,[{'id':'J_1','text':'new'}])[0]['exception_state'],'À revalider')
    def test_row_move_does_not_invalidate(self):
        self.exception();self.rows[0]['row']=99
        self.assertEqual(group_checks(self.rows,self.cfg)[0]['exception_state'],'Applicable')
    def test_ambiguous_remains_unverifiable(self):
        self.exception();self.rows.append(copy.deepcopy(self.rows[0]));c=group_checks(self.rows,self.cfg)[0]
        self.assertEqual(c['status'],'NON VÉRIFIABLE');self.assertEqual(c['exception_state'],'À revalider')
    def test_disabled_not_conformant(self):
        self.cfg['linked_field_groups'][0]['enabled']=False
        self.assertEqual(group_checks(self.rows,self.cfg)[0]['status'],'INFORMATION')
    def test_non_id_suggestions_and_confirmation(self):
        r=report([row('STATUT'),row('STATUTORIGINE')])
        view=overview(r,dict(self.cfg,linked_field_groups=[]));self.assertEqual(len(view['suggestions']),1)
        self.assertEqual(view['suggestions'][0]['reason'],'');self.assertEqual(view['groups'],[])
    def test_similar_names_different_sources_not_suggested(self):
        self.assertEqual(overview(report(self.rows),dict(self.cfg,linked_field_groups=[]))['suggestions'],[])
    def test_duplicate_and_invalid_groups(self):
        for groups in ([GROUP,copy.deepcopy(GROUP)],[dict(GROUP,reason=3)],[dict(GROUP,enabled='false')],[dict(GROUP,exception={'reason':'ok','fingerprint':'fake'})]):
            with self.assertRaises(ValueError):validate_groups(groups)
    def test_api_save_conflict_reanalysis_and_immutable_history(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);shutil.copytree(Path(__file__).resolve().parents[1]/'config',root/'config')
            app=Application(root,root/'data')
            try:
                original=app.store.save(report(self.rows),'Mapping.xlsx')
                base={'analysis_id':original['id']}
                v=app.api('/api/coherence',base)
                v=app.api('/api/coherence',{**base,'action':'save','revision':v['revision'],'groups':[GROUP]})
                self.assertFalse(v['analysis_groups_match'])
                with self.assertRaises(ValueError):app.api('/api/coherence',{**base,'action':'save','revision':'stale','groups':[]})
                ex=dict(GROUP,exception={'reason':'Métier confirmé','fingerprint':v['checks'][0]['fingerprint']})
                v=app.api('/api/coherence',{**base,'action':'save','revision':v['revision'],'groups':[ex]})
                self.assertEqual(v['checks'][0]['status'],'INFORMATION')
                updated=app.api('/api/coherence',{**base,'action':'reanalyze'})
                self.assertNotEqual(updated['id'],original['id']);self.assertEqual(app.store.get(original['id']),original)
                self.assertEqual([c['status'] for c in updated['results'] if c['rule']=='LINKED_SOURCE_GROUP'],['INFORMATION'])
                self.assertEqual(app.settings()['linked_field_groups'],[ex])
                self.assertTrue(overview(updated,app.settings())['analysis_groups_match'])
            finally:app.gemini.close();app.pool.shutdown()
