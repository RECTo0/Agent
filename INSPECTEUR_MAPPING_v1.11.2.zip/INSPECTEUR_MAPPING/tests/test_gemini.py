import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from test_engine import ROOT,CFG,doc
from backend.analyzer import analyze
from backend.services.gemini import semantic_prompt
from backend.services.storage import Store

spec=importlib.util.spec_from_file_location('review',ROOT/'scripts/review_gemini.py');review=importlib.util.module_from_spec(spec);spec.loader.exec_module(review)

class GeminiTests(unittest.TestCase):
    def test_prompt_separate_no_image_bytes(self):
        r=analyze(doc(),CFG);prompt=semantic_prompt(r)
        self.assertIn(r['input_sha256'],prompt);self.assertNotIn('base64,',prompt)
    def test_reject_semantic_certain_error_status(self):
        with tempfile.TemporaryDirectory() as folder:
            store=Store(Path(folder)/'test.sqlite3');r=store.save(analyze(doc(),CFG),'test.xlsx')
            with self.assertRaises(ValueError):store.add_semantic(r['id'],{'input_sha256':r['input_sha256'],'recommendations':[{'description':'test','evidence':[],'correction':'test','status':'ANOMALIE'}]})
    def test_disabled_bridge_never_calls_cli(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'config').mkdir();(root/'config/settings.json').write_text(json.dumps({'gemini':{'enabled':False}}))
            with patch.object(review,'ROOT',root),patch.object(review.subprocess,'run') as run:
                with self.assertRaises(SystemExit):review.main()
                run.assert_not_called()
    def test_refused_consent_never_calls_cli(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'config').mkdir();(root/'config/settings.json').write_text(json.dumps({'gemini':{'enabled':True}}));prompt=root/'prompt.txt';prompt.write_text('test')
            with patch.object(review,'ROOT',root),patch.object(review.sys,'argv',['review',str(prompt)]),patch('builtins.input',return_value='NON'),patch('builtins.print'),patch.object(review.subprocess,'run') as run:
                with self.assertRaises(SystemExit):review.main()
                run.assert_not_called()
