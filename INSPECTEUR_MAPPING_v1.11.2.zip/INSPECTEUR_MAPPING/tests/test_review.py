import copy
import io
import json
import tempfile
import unittest
from pathlib import Path
from openpyxl import load_workbook
from backend.app import Application
from backend.analyzer import analyze
from backend.services.storage import Store
from backend.services.reports import export_excel,export_html
from backend.validators.joins import assess_max,text_hash
from test_engine import doc,CFG,ROOT

RULE={'id':'J_USER','kind':'Jointure','sheet':'Filtre - Jointures - RG','row':5,'column':'B','has_image':False,
      'text':'ORZ_PRODUCT2.LASTMODIFIEDBYID = ORZ_USER.USERID. Si plusieurs lignes, USER.SYSTEMMODSTAMP = MAX(USER.SYSTEMMODSTAMP).'}
def configured():
    c=copy.deepcopy(CFG)
    c['join_max_context']={'J_USER':{'table':'ORZ_USER','date_column':'SYSTEMMODSTAMP','group_by':['USERID'],'scope':'per_key','text_sha256':text_hash(RULE['text'])}}
    return c

class MaxTests(unittest.TestCase):
    def test_pk_per_user_no_tie_risk(self):
        status,*_=assess_max(RULE,configured());self.assertEqual(status,'CONFORME')
    def test_unknown_scope_is_not_a_risk(self):self.assertEqual(assess_max(RULE,CFG)[0],'NON VÉRIFIABLE')
    def test_unknown_pk_is_not_a_risk(self):
        c=configured();c['source_keys']={};self.assertEqual(assess_max(RULE,c)[0],'NON VÉRIFIABLE')
    def test_partial_composite_key_not_certified(self):
        c=configured();c['source_keys']['ORZ_USER']['columns'].append('SEQUENCE');self.assertEqual(assess_max(RULE,c)[0],'NON VÉRIFIABLE')
    def test_stale_scope_not_reused(self):
        r=dict(RULE,text=RULE['text']+' Texte modifié.');self.assertEqual(assess_max(r,configured())[0],'NON VÉRIFIABLE')
    def test_global_max_never_claims_per_user_uniqueness(self):
        c=configured();c['join_max_context']['J_USER']['scope']='global';self.assertEqual(assess_max(RULE,c)[0],'INFORMATION')
    def test_unique_constraint_without_null_policy_not_pk(self):
        c=configured();c['source_keys']['ORZ_USER']['kind']='UNIQUE';self.assertEqual(assess_max(RULE,c)[0],'NON VÉRIFIABLE')
    def test_rg_max_checked_too(self):
        r=dict(RULE,kind='RG');results=analyze(doc(rules=[r]),configured())['results'];self.assertEqual(next(x for x in results if x['rule']=='JOIN_MULTIPLICITY')['status'],'CONFORME')

class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.path=Path(self.temp.name);self.store=Store(self.path/'test.db')
        self.report=self.store.save(analyze(doc(rules=[RULE]),CFG),'mapping.xlsx');self.id=self.report['id']
        self.item={'rule_id':'J_USER','sheet':RULE['sheet'],'row':5,'original_text':RULE['text'],'proposed_text':'Retenir la dernière version du USER correspondant.','why':'Phrase simplifiée.','ambiguities':[]}
    def tearDown(self):self.temp.cleanup()
    def import_review(self,items=None):self.store.add_semantic(self.id,{'input_sha256':'test','recommendations':[],'language_reviews':items if items is not None else [self.item]})
    def test_workflow_persists_and_empty_completion(self):
        self.assertEqual(self.store.language_review(self.id)['phase'],'not_started');self.store.start_review(self.id)
        self.assertEqual(Store(self.path/'test.db').language_review(self.id)['phase'],'in_progress');self.import_review([])
        self.assertEqual(self.store.language_review(self.id)['phase'],'completed');self.assertEqual(self.store.language_review(self.id)['proposals'],[])
    def test_decision_persists_and_new_text_requires_review(self):
        self.import_review();p=self.store.language_review(self.id)['proposals'][0];self.store.proposal_event(self.id,{'proposal_id':p['proposal_id'],'decision':'Proposition retenue','comment':'Validé ensemble'})
        saved=Store(self.path/'test.db').language_review(self.id)['proposals'][0];self.assertEqual(saved['decision'],'Proposition retenue')
        changed=dict(self.item,proposed_text='Une autre reformulation.');self.import_review([changed]);self.assertEqual(self.store.language_review(self.id)['proposals'][0]['decision'],'À examiner')
        with self.assertRaises(ValueError):self.store.proposal_event(self.id,{'proposal_id':p['proposal_id'],'decision':'Écartée'})
    def test_wrong_original_and_duplicate_rejected(self):
        with self.assertRaises(ValueError):self.import_review([dict(self.item,original_text='Texte étranger')])
        with self.assertRaises(ValueError):self.import_review([self.item,self.item])
    def test_decision_export_and_escape(self):
        self.import_review();p=self.store.language_review(self.id)['proposals'][0];self.store.proposal_event(self.id,{'proposal_id':p['proposal_id'],'decision':'Proposition retenue','comment':'<script>bad</script>'})
        report=dict(self.report,language_reviews=self.store.language_review(self.id)['proposals'])
        raw=export_html(report).decode();self.assertNotIn('<script>',raw);self.assertIn('Proposition retenue',raw)
        wb=load_workbook(io.BytesIO(export_excel(report)));self.assertEqual(wb['Reformulations']['I2'].value,'Proposition retenue')
    def test_max_context_creates_new_immutable_analysis(self):
        app=Application(ROOT,self.path/'app');original=app.store.save(self.report,'mapping.xlsx');id=original['id']
        try:
            updated=app.api('/api/analysis/'+id+'/max-context',{'rule_id':'J_USER','sheet':RULE['sheet'],'row':5,'alias':'USER','table':'ORZ_USER','date_column':'SYSTEMMODSTAMP','group_by':['USERID'],'key_columns':['USERID','SYSTEMMODSTAMP'],'scope':'per_key','source':'Dictionnaire validé'})
            self.assertNotEqual(updated['id'],id);self.assertEqual(app.store.get(id)['results'],original['results'])
            self.assertEqual(next(x for x in updated['results'] if x['rule']=='JOIN_MULTIPLICITY')['status'],'CONFORME')
            with self.assertRaises(ValueError):app.api('/api/analysis/'+id+'/max-context',{'rule_id':'absent'})
        finally:app.pool.shutdown()

if __name__=='__main__':unittest.main()
