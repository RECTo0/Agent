import unittest
from backend.validators.impact import review_impact
from test_evolution import row,report

def rule(id,text,kind='Jointure'):
 return {'id':id,'kind':kind,'text':text,'sheet':'Filtre - Jointures - RG','row':8}
def rep(rows,rules=()):
 r=report(rows);r['document']['rules']=list(rules);return r
def checks(old,new,code):return [c for c in review_impact(old,new)['cards'] if c['code']==code]

class ImpactTests(unittest.TestCase):
 def test_all_ten_coverage(self):self.assertEqual(len(review_impact(rep([row('ID')]),rep([row('ID')]))['coverage']),10)
 def test_migration_different_fields(self):
  a=[row('LIBELLE'),row('STATUT')];a[0]['source_field']='NAME';a[1]['source_field']='STATUS'
  b=[dict(x) for x in a];b[0]['source_table']='B'
  self.assertTrue(checks(rep(a),rep(b),'TABLE_MIGRATION'))
 def test_complete_table_migration(self):self.assertFalse(checks(rep([row('X'),row('Y')]),rep([row('X','B'),row('Y','B')]),'TABLE_MIGRATION'))
 def test_old_reference_exact(self):
  a=rep([row('ID')]);b=rep([row('ID','B',join='J_1')],[rule('J_1','A.ID = B.ID')])
  self.assertTrue(checks(a,b,'OLD_REFERENCE'))
  b['document']['rules'][0]['text']='AA.ID = B.ID';self.assertFalse(checks(a,b,'OLD_REFERENCE'))
 def test_unrelated_rule_not_stale(self):
  self.assertFalse(checks(rep([row('ID')]),rep([row('ID','B')],[rule('J_X','A.ID = B.ID')]),'OLD_REFERENCE'))
 def test_missing_join_and_connected(self):
  a=rep([row('X'),row('Y')]);b=rep([row('X','B'),row('Y')])
  self.assertTrue(checks(a,b,'SOURCE_JOIN'));b['document']['rules']=[rule('J_1','A.ID = B.ID')]
  self.assertFalse(checks(a,b,'SOURCE_JOIN'))
 def test_alias_join(self):
  a=rep([row('X'),row('Y')]);b=rep([row('X','B'),row('Y')],[rule('J_1','A.ID = BB.ID')]);b['config']['aliases']={'BB':'B'}
  self.assertFalse(checks(a,b,'SOURCE_JOIN'))
 def test_new_target_join(self):
  self.assertTrue(checks(rep([row('X')]),rep([row('X'),row('Y','B')]),'SOURCE_JOIN'))
 def test_date_semantic_clue(self):
  a=row('D');a['source_field']='CREATEDDATE';b=dict(a,source_field='LASTMODIFIEDDATE')
  c=checks(rep([a]),rep([b]),'BUSINESS_MEANING');self.assertEqual(c[0]['level'],'Risque possible')
 def test_names_not_semantic_proof(self):
  a=row('D');a['source_field']='X';b=dict(a,source_field='Y');self.assertFalse(checks(rep([a]),rep([b]),'BUSINESS_MEANING'))
 def test_rule_join_loss(self):
  a=rep([row('ID',join='J_1')],[rule('J_1','A LEFT JOIN B ON A.ID=B.ID')]);b=rep([row('ID',join='J_1')],[rule('J_1','A INNER JOIN B ON A.ID=B.ID')])
  self.assertTrue(checks(a,b,'JOIN_LOSS'))
 def test_inline_join_loss(self):
  self.assertTrue(checks(rep([row('ID',join='A LEFT JOIN B')]),rep([row('ID',join='A INNER JOIN B')]),'JOIN_LOSS'))
 def test_filter_and_required(self):
  b=rep([row('ID','B',join='J_1',filter='B.ID IS NOT NULL',required='Oui')],[rule('J_1','A LEFT JOIN B ON A.ID=B.ID')])
  a=rep([row('ID')]);self.assertTrue(checks(a,b,'JOIN_LOSS'));self.assertTrue(checks(a,b,'NULL_REQUIRED'))
 def test_preserved_side_not_flagged(self):
  b=rep([row('ID','A',join='J_1',required='Oui')],[rule('J_1','A LEFT JOIN B ON A.ID=B.ID')])
  self.assertFalse(checks(rep([row('ID')]),b,'NULL_REQUIRED'))
 def test_fallback_not_certified(self):
  b=rep([row('ID','B',join='A LEFT JOIN B',required='Oui',expression='COALESCE(B.ID,A.ID)')])
  self.assertEqual(checks(rep([row('ID')]),b,'NULL_REQUIRED')[0]['level'],'Information manquante')
 def test_rg_all_dependents_and_transitive(self):
  rows=[row('X',expression='RG_1'),row('Y',expression='RG_2')]
  a=rep(rows,[rule('RG_1','avant','RG'),rule('RG_2','RG_1','RG')]);b=rep(rows,[rule('RG_1','après','RG'),rule('RG_2','RG_1','RG')])
  self.assertEqual(len(checks(a,b,'RULE_IMPACT')[0]['rows']),2)
 def test_type_narrowing(self):
  b=rep([row('X','B',source_type='VARCHAR2(100)',target_type='VARCHAR2(30)')]);self.assertEqual(checks(rep([row('X')]),b,'TYPE_CHANGE')[0]['level'],'Risque possible')
 def test_missing_type_not_pass(self):self.assertEqual(checks(rep([row('X')]),rep([row('X','B')]),'TYPE_CHANGE')[0]['level'],'Information manquante')
 def test_description_clue(self):
  b=rep([row('X','ACCOUNTBILLING',description='Identifiant du compte client')]);self.assertTrue(checks(rep([row('X')]),b,'DESCRIPTION_MEANING'))
 def test_opaque_description_visible(self):
  self.assertTrue(checks(rep([row('X')]),rep([row('X',description='Domaine métier spécifique')]),'MANUAL_REVIEW'))
 def test_complex_and_duplicate_visible(self):
  b=rep([row('X',expression='CASE WHEN ...'),row('Y'),row('Y')]);c=checks(rep([row('X')]),b,'MANUAL_REVIEW');self.assertGreaterEqual(len(c[0]['evidence']),2)
 def test_deleted_target_visible(self):self.assertTrue(checks(rep([row('X'),row('Y')]),rep([row('X')]),'MANUAL_REVIEW'))
 def test_unchanged_direct_no_false_warning(self):
  a=rep([row('X',source_type='DATE',target_type='DATE')]);self.assertFalse(review_impact(a,a)['cards'])
