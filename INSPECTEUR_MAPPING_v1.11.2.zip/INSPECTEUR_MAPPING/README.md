# Inspecteur Mapping — 1.11.2

## Réponses de l’assistant

Les réponses utilisent une mise en page lisible pour les paragraphes, les titres, le gras, les listes et les extraits de code. Les signes Markdown sont rendus comme une mise en forme au lieu de rester visibles dans le texte. Les preuves du mapping et les limites de l’analyse apparaissent dans des blocs séparés. Les propositions SQL gardent leur bloc dédié avec les actions de copie et de téléchargement.

Le prompt demande des explications directes, courtes et organisées, sans symboles décoratifs. Cette version ne change ni le moteur de contrôle ni la validation des réponses. Aucune suite de tests n’a été exécutée pour cette évolution d’affichage.

---

## Version 1.11.1

Les pictogrammes distinguent le mapping, le classeur Excel et les outils de revue. Les aperçus des trois écrans se trouvent dans `docs/apercus`.

---

# Inspecteur Mapping — 1.11.0

Ouvrez **Cohérence métier** après avoir sélectionné une analyse. Créez un groupe ou examinez une suggestion issue des champs qui partagent une source directe. Renseignez la justification métier avant de l’enregistrer. Les groupes disponibles sur ce poste s’appliquent aux nouvelles analyses.

Dans chaque groupe, comparez les sources constatées et ouvrez la ligne Excel de chaque cible. Si une différence est voulue, documentez une exception. Elle reste applicable tant que les sources, expressions, filtres, jointures et textes de règles pris en compte restent identiques. Un changement de texte, même dans une autre règle du classeur, peut donc demander une revalidation. Si une cible manque, a plusieurs alimentations ou dépend d’une expression indirecte, le résultat est « Non vérifiable ».

**Actualiser les contrôles du mapping** enregistre une nouvelle analyse. Pour mettre à jour une installation, conservez votre dossier `data`, votre `config/settings.json` et votre lanceur personnalisé.

---

# Inspecteur Mapping — 1.10.0

## Demander des requêtes SQL à l’assistant

Ouvrez **Assistant mapping** et posez votre demande, ou utilisez **SQL de contrôle** / **SQL courant / HIST**. Depuis le graphe, sélectionnez un élément avant d’interroger l’assistant pour cibler la génération.

Exemples :
- « Génère un SELECT Oracle 19c qui alimente IDMOE et IDMOEOrigine avec les jointures documentées. »
- « Propose une requête pour détecter les doublons sur la clé déclarée de ORZ_USER. »
- « Écris un contrôle des lignes sans correspondance pour cette jointure. »
- « Propose les SELECT du modèle courant et historique, en précisant les règles manquantes. »
- « Reprends la requête précédente et ajoute ce filtre… »

Préparez la question, relisez le contexte et autorisez l’envoi. Chaque requête apparaît dans un bloc SQL avec titre, objectif, preuves, hypothèses et informations manquantes. Utilisez **Copier le SQL** ou **Fichier .sql**. Le fichier téléchargé contient des commentaires de contexte et la requête. L’historique conserve les requêtes et les transmet avec les quatre derniers échanges réussis pour permettre les corrections.

Les requêtes sont proposées pour Oracle 19c, **sans exécution ni validation Oracle**. L’état **À relire** ne signifie pas exécutable ou conforme. Les informations manquantes ou le marqueur <A_COMPLETER> imposent l’état **À compléter**. Le contrôle côté application porte sur le format et les références de preuves, pas sur la syntaxe SQL ni la fidélité métier. Les noms, schémas et contraintes déclarés sont transmis ; l’assistant doit signaler ce qui manque et ne pas inventer l’historisation. Un contexte tronqué ne permet pas de certifier un modèle global complet.

137 tests Python réussis. Parcours Chromium avec CLI fictif : réponse SQL, autorisation, copie, téléchargement et contenu, conservation après rechargement, SQL précédent dans le contexte d’une question suivante, mobile 390 px. Aucun service Gemini réel ni Oracle sollicité. Conservez data, config/settings.json et votre lanceur lors de la mise à jour ; redémarrez l’application et rechargez le navigateur.

---

# Inspecteur Mapping — 1.9.0

## Nouveau graphe centré sur les tables

Ouvrez **Graphe de traçabilité**. La vue globale regroupe les champs dans des cartes de tables ; les transformations sont masquées au départ pour alléger la lecture.

- **Vue globale** : toutes les tables du périmètre affiché ; cliquer à nouveau sur ce mode efface la sélection.
- **Alimentation d’un champ** : sélectionnez une cible pour explorer ses dépendances amont.
- **Impacts** : sélectionnez une source ou une règle pour afficher ses dépendances aval et les cibles potentiellement concernées.
- **+ Déplier / − Réduire** : développer une carte (jusqu’à 80 éléments) ou revenir aux trois premiers champs. La recherche permet de sélectionner un champ au-delà de cette limite ; il devient prioritaire dans la carte.
- **+ Liens** : révéler progressivement les dépendances voisines ; la case Afficher les transformations montre l’ensemble des étapes du périmètre.
- Glisser une carte pour la déplacer, glisser le fond pour parcourir le graphe, utiliser la molette ou les boutons pour zoomer. **Réorganiser** restaure la disposition automatique ; **Tout voir** ajuste la largeur ; **Centrer la sélection** retrouve le champ choisi.
- Le panneau de détail s’ouvre au clic, avec les preuves Excel, les impacts et l’accès à Gemini. Il peut être fermé pour libérer l’espace.
- **Réduire le menu** agrandit l’espace graphique. La navigation normale est restaurée en quittant le graphe.

### Couleurs des étapes

| Rôle | Couleur |
|---|---|
| Sources | Bleu |
| Jointures | Orange |
| Filtres | Jaune |
| Règles de gestion | Violet |
| Cibles courantes | Vert |
| Historique | Cyan |
| Publication | Rose |

Les rôles des cibles proviennent des destinations du mapping. Les libellés et icônes complètent les couleurs. Le symbole △ indique un contrôle à examiner ; une couleur d’étape n’est pas un statut de conformité. Les liens en pointillés passent par des éléments masqués. Le graphe reste documentaire, sans ordre d’exécution SQL garanti ni simulation.

L’export JSON conserve le périmètre, le mode, la sélection et les intermédiaires des liens regroupés. Les limites de couverture du moteur et de 300 éléments affichés restent visibles. Le bouton Comparer deux versions ouvre la vue comparative existante. Les positions manuelles sont conservées pendant l’exploration de la page, pas après rechargement.

Validation : parcours navigateur réussi sur ordinateur, thème sombre et mobile 390 px ; modes, couleurs, dépliage, déplacement, zoom, réorganisation, menu, export et assistant avec CLI fictif. Les contrôles métier sont inchangés. Conservez data, config/settings.json et votre lanceur personnalisé lors de la mise à jour, puis relancez l’application et rechargez la page.

---

# Inspecteur Mapping — 1.8.0

## Graphe de traçabilité intelligent

Ouvrez **Graphe de traçabilité** dans le menu. Les cartes regroupent les champs par table source ou cible ; les règles et les alimentations relient les deux.

- Recherchez un nom de table, un champ ou une RG puis choisissez l’élément.
- Cliquez sur un champ, une règle ou le titre d’une table : le graphe conserve son voisinage documentaire et le panneau présente les cibles potentiellement concernées par une modification.
- Les badges orange signalent des contrôles à examiner sur les lignes associées.
- Ouvrez les preuves Excel ou cliquez sur **Interroger l’assistant** pour poser une question avec cette sélection.
- Déplacez le fond, réglez le zoom, ajustez la vue, revenez à la vue globale ou exportez le sous-graphe JSON.
- Le bouton **Comparaison avant / après** ouvre la vue par champ existante pour examiner les différences entre deux analyses.

Les liens représentent des dépendances documentées et des références textuelles explicites, pas un plan d’exécution SQL. Les impacts sont potentiels, sans simulation de données. Les références absentes et autres limites sont affichées. Le graphe regroupe au maximum 1000 cibles ; la vue affiche 300 éléments à la fois et l’indique si le périmètre dépasse cette limite. Utilisez la recherche pour explorer un périmètre plus précis.

## Assistant conversationnel contextuel

Le bouton **Assistant mapping**, en bas à droite, ouvre un panneau sur l’analyse sélectionnée. Vous pouvez également partir du graphe, d’une fiche de jointure, d’une RG ou du détail d’un contrôle.

Exemples : « Quels champs utilisent ORZ_USER ? », « Pourquoi cette jointure est-elle risquée ? », « Explique-moi cette RG en français ». Sélectionnez la règle dans le graphe ou sa fiche pour que « cette RG » ait un contexte précis.

1. Saisissez la question et cliquez sur **Préparer la question**.
2. Relisez le contexte proposé et autorisez son envoi.
3. Cliquez sur **Envoyer à Gemini**.
4. Consultez la réponse et ses preuves : un clic ouvre la ligne Excel ou le nœud du graphe.

L’assistant réutilise la configuration Gemini de **RG et jointures** : pour `npx @google/gemini-cli`, commande `npx`, argument `@google/gemini-cli`. L’accès doit déjà fonctionner et être authentifié sur votre poste. Aucune nouvelle clé API n’est ajoutée par l’application.

Les échanges sont conservés par analyse dans la base locale. Les quatre derniers échanges réussis sont inclus dans le contexte suivant ; ils ne sont pas considérés comme des preuves métier. Changer d’analyse change la conversation. Les erreurs, annulations et interruptions sont affichées ; le rechargement ne relance pas un envoi. La revue de reformulation et la conversation ont des historiques distincts, et une seule exécution Gemini est autorisée à la fois.

Le contexte sélectionne les preuves par élément explicite ou recherche lexicale, avec une limite de 100 preuves / environ 100 000 caractères de preuves. Les limites sont transmises à Gemini ; les déclarations de clés et de périmètre du MAX sont incluses. Le serveur vérifie l’empreinte du mapping et les identifiants des citations. Cela ne certifie pas la justesse métier de la réponse. Une réponse conversationnelle ne valide pas une RG et ne modifie pas l’Excel.

## Mise à jour et vérification

Conservez `data`, `config/settings.json` et votre lanceur personnalisé ; remplacez les fichiers applicatifs, redémarrez le serveur et rechargez le navigateur. Aucune dépendance Python supplémentaire. Le moteur de contrôle reste en 1.5.0, l’application passe en 1.8.0.

130 tests Python réussis. Parcours navigateur avec un faux CLI local : sélection et impacts, recherche, export, autorisation, réponse et citations, persistance après rechargement, preuve Excel, thème sombre et mobile 390 px. Aucun appel réel à Gemini pendant ces tests. Windows et votre configuration Gemini restent à vérifier sur votre poste.

---

# Inspecteur Mapping — 1.7.0

## Revue Gemini depuis l’interface (option 3)

Dans **RG et jointures**, ouvrez **Configurer le lancement Gemini**. Pour votre commande `npx @google/gemini-cli`, activez le lancement, saisissez `npx` dans Commande et `@google/gemini-cli` dans Arguments, puis enregistrez. Vous pouvez aussi utiliser le chemin de votre `gemini_local.cmd`, sans argument si ce lanceur les contient déjà.

1. Cliquez sur **Préparer et relire le contexte** : le texte exact, sa taille et la commande sont visibles, sans lancement du CLI.
2. Lisez le contexte et cochez l’autorisation d’envoi.
3. Cliquez sur **Envoyer et lancer la revue**. L’état et le temps écoulé sont affichés ; le bouton Annuler arrête le processus local, sans retirer les données déjà envoyées.
4. Après validation de la réponse, l’import est automatique. Cliquez sur **Afficher les propositions** pour comparer les textes et conserver votre décision.

Le CLI doit être installé et authentifié avec votre compte habituel. Lancez l’application depuis un environnement où votre commande fonctionne (PATH, proxy et authentification). Les contrôles locaux n’exigent pas Node ou Gemini. Le délai est configurable entre 10 et 1800 secondes. Une seule revue Gemini s’exécute à la fois.

Un contexte préparé expire après 30 minutes ; changer la configuration impose une nouvelle préparation. Une reprise après erreur exige un nouvel accord. Une réponse invalide n’écrase pas les propositions existantes et reste téléchargeable. Le statut persiste après rechargement. Après redémarrage du serveur, une tâche interrompue n’est jamais renvoyée automatiquement. La progression indique des étapes et une durée, sans pourcentage artificiel.

Le lancement utilise un répertoire temporaire de confiance limité au processus enfant (`GEMINI_CLI_TRUST_WORKSPACE=true`). Les permissions standard du CLI restent applicables, sans mode YOLO ; ce répertoire ne constitue pas un bac à sable. Un lanceur personnalisé doit attendre la fin du CLI. Le téléchargement/import manuel reste disponible en alternative.

## Vue graphique par champ (option 7)

Ouvrez **Vue par champ**, cliquez sur un champ dans les contrôles, ou utilisez **Explorer les différences par champ** dans la comparaison.

- Recherchez une table ou un champ cible pour afficher ses sources, RG, filtres, jointures et lignes de mapping.
- Cliquez sur un bloc pour lire son texte et ouvrir sa ligne Excel.
- Sélectionnez une analyse de référence : vert = ajouté, rouge = supprimé, orange = modifié ; les détails présentent Avant / Après.
- Réglez le zoom et exportez les dépendances au format JSON.

Le graphique décrit les dépendances documentées, pas l’ordre d’exécution SQL. Il distingue source déclarée et référence textuelle. Les références explicites RG_/J_/F_ sont suivies, avec avertissement en cas d’absence, de doublon ou de limite d’expansion. Les branches multiples sont rapprochées par position : un réordonnancement nécessite une revue. Le déplacement d’une ligne seule n’est pas considéré comme une modification sémantique.

## Mise à jour et validation

Conservez votre dossier `data`, votre configuration `config/settings.json` et votre lanceur personnalisé lors de la mise à jour. Relancez l’application puis rechargez le navigateur. Le moteur de contrôles reste en version 1.5.0 ; l’interface et les services sont en 1.7.0.

121 tests Python réussis. Parcours Chromium vérifié sur ordinateur, en thème sombre et à 390 px : consentement, lancement fictif, import automatique, récupération du statut, graphique, comparaison, preuves Excel et export. Aucun appel réel Gemini pendant les tests ; Windows et votre installation Gemini restent à vérifier sur votre poste.

---

# Inspecteur Mapping — 1.6.0

## Guide visuel et FAQ intégrés

Ouvrez **Guide de démarrage**, sous Accueil dans le menu.

- Choisissez un objectif : premier mapping, comparaison, lecture d’un avertissement ou reformulation d’une RG.
- Parcourez les cinq étapes Importer → Analyser → Examiner → Comparer → Décider et ouvrez les pages correspondantes.
- Lancez l’exemple fictif A.ID / B.ID : Lecture, Pause, Étape suivante et Rejouer. Aucune donnée réelle n’est utilisée ni modifiée.
- Découvrez les quatre parties d’un résultat et le sens des cinq statuts.
- Suivez le trajet local puis le parcours manuel Gemini, avec l’étape d’envoi explicitement identifiée.
- Recherchez dans les 16 questions/réponses, filtrez par catégorie et dépliez les réponses.

Les animations se lancent à la demande et s’arrêtent en quittant la page. La préférence système de réduction des mouvements est respectée ; une case permet également de passer en mode statique. Les étapes restent accessibles manuellement. La question FAQ relative aux données en base et à l’exécution ODI est exclue conformément à la demande.

Cette version améliore le guide uniquement ; le moteur de contrôle reste en version 1.5.0. Conservez `data`, votre `config/settings.json` personnalisé et votre `gemini_local.cmd` lors de la mise à jour. Relancez l’application puis rechargez la page du navigateur.

Validation : syntaxe JavaScript vérifiée ; parcours Chromium testé sur ordinateur et mobile (390 px), lecture/pause/rejeu, étapes, FAQ, filtres, recherche sans résultat, liens et préférence de mouvements réduits. Aucun appel réel Gemini pour ces tests.

---

# Inspecteur Mapping — 1.5.0

## Fiche d’impact : les dix nouveaux contrôles

Ouvrez **Comparer les versions**, sélectionnez deux analyses du même mapping (Avant / Après), puis **Comparer les analyses**. Sous les avertissements de source apparaît la **Fiche d’impact du changement**. Les contrôles 1.4 restent disponibles.

Chaque point contient un niveau de preuve, les cibles concernées, leurs alimentations avant/après, les emplacements Excel, les éléments documentaires et une action proposée. Le filtre permet de choisir **Écart constaté**, **Risque possible** ou **Information manquante**. **Exporter la fiche JSON** conserve les preuves et les identifiants des deux analyses.

| Contrôle | Détection et limite |
|---|---|
| Migration partielle de table | Une partie des sources directes d’un objet passe de A à une autre table, tandis que d’autres restent sur A, même avec des champs différents. Différence volontaire possible. |
| Anciennes références | Recherche de références qualifiées à l’ancienne table dans les expressions, filtres et jointures de la ligne et ses règles explicitement référencées. Pas de conclusion sur une référence conservée volontairement. |
| Nouvelle source sans raccordement | Recherche d’une égalité TABLE.CHAMP = TABLE.CHAMP reliant la nouvelle source à une autre source projetée. L’absence de syntaxe reconnue demande documentation, sans prouver une jointure manquante. Alias configurés pris en compte. |
| Sens métier modifié | Indices lexicaux création/modification et client/facturation dans les champs source avant/après. Risque à confirmer, jamais une contradiction démontrée sur les noms seuls. |
| Perte possible de lignes | Mentions LEFT JOIN puis INNER JOIN dans la même règle ou ligne ; prédicats comparatifs ou IS NOT NULL sur la source facultative dans un filtre associé. Les OR et contextes SQL complexes demandent une revue. |
| NULL et cible obligatoire | Source à droite d’un LEFT JOIN explicite et cible obligatoire. La présence de NVL/COALESCE ne certifie pas que tous les cas NULL sont couverts. |
| RG modifiée | Liste toutes les cibles qui référencent une RG modifiée, directement ou via une autre règle, même lorsque leur ligne est inchangée. Références RG_/J_/F_ explicites uniquement. |
| Format, type et capacité | Compare types déclarés source/cible pour une alimentation nouvelle ou modifiée (ou une règle liée modifiée). Types absents = information manquante. Les conversions peuvent rendre la projection compatible. |
| Description et alimentation | Repère des concepts lexicaux disjoints entre description et source. Vocabulaire limité ; la revue sémantique doit confirmer. Les descriptions non couvertes sont signalées pour revue manuelle. |
| Couverture visible | Liste sources indirectes, expressions/RG, cibles ambiguës, références absentes ou multiples, suppressions/renommages et descriptions hors vocabulaire. Aucun succès n’est déduit de l’absence de signalement. |

### Ce que signifient les résultats

Ces contrôles sont documentaires et locaux : aucune requête sur Oracle/ODI et aucun envoi à Gemini. Les signalements sont calculés à la comparaison ; ils ne modifient pas rétroactivement les rapports des analyses. Les groupes métier déclarés restent contrôlés lors de chaque nouvelle analyse.

Les compteurs de la fiche indiquent des **points remontés**, pas des contrôles métier réussis. Les points d’un même changement peuvent appartenir à plusieurs catégories. Le moteur ne fait pas une interprétation générale du français ou du SQL. Les contrôles de sens (4 et 9) sont des aides lexicales limitées. Pour approfondir, le prompt manuel de **RG et jointures** demande aussi de confronter description, source, événements métier et traitement NULL avec des preuves.

### Mise à jour

Conservez votre dossier `data`, votre `config/settings.json` personnalisé et votre `gemini_local.cmd` si vous en utilisez un. La version n’ajoute aucune configuration obligatoire. Relancez le serveur après remplacement des fichiers de l’application ; rechargez la page du navigateur. Les nouveaux contrôles de comparaison peuvent exploiter les analyses existantes, puisqu’ils relisent leurs documents enregistrés. Pour appliquer les autres contrôles du moteur actuel, actualisez dans une nouvelle analyse.

### Validation

101 tests Python réussis, dont 23 nouveaux scénarios consacrés à la fiche d’impact. Le fichier tests/RESULTATS.txt conserve les résultats. Windows et Gemini réel ne sont pas exécutés dans cet environnement.

---

# Inspecteur Mapping — 1.4.0

## Détecter une évolution de source incomplète

Ouvrez **Comparer les versions**, choisissez **Avant** (référence) et **Après** (nouvelle version) du même mapping, puis cliquez sur **Comparer les analyses**.

Le bloc **Vigilance sur les évolutions** présente les avertissements avec :
- les champs liés qui utilisaient la même source dans la version de référence ;
- leurs sources avant/après et une distinction « modifiée / conservée » ;
- la preuve et l’action proposée, sans correction automatique ;
- des liens vers les lignes Excel des deux analyses ;
- un export JSON des avertissements, avec les identifiants des analyses.

Exemple : A.ID alimentait IDMOE et IDMOEOrigine. Si seul IDMOE passe à B.ID, un avertissement signale le changement partiel. Aucune règle universelle n’impose que ces champs aient la même source : leur divergence doit être examinée.

Le contrôle courant/historique recherche aussi les champs précédemment alignés dont les sources divergent, pour les tables TABLE et TABLE_HIST. Lorsque le mapping décrit les deux cibles sur une même ligne, la source est partagée et ne crée pas de faux écart.

### Groupes métier explicites

Dans **Comparer les versions → Champs devant utiliser la même source**, saisissez au moins deux cibles TABLE.CHAMP et une justification métier. Les groupes sont conservés dans `linked_field_groups` des Paramètres, où ils peuvent être modifiés ou retirés. Puis lancez une nouvelle analyse, ou utilisez **Actualiser les contrôles dans une nouvelle analyse** depuis une analyse existante.

Ils apparaissent dans **Contrôles**, catégorie **Cohérence inter-feuilles** :
- CONFORME : même source directe pour tous les membres ;
- RISQUE : sources différentes, en contradiction avec la déclaration ;
- NON VÉRIFIABLE : cible absente, plusieurs lignes ou RG/expression indirecte.

Aucun groupe n’est préactivé pour tous les objets. Les analyses antérieures restent immuables.

### Périmètre et limites

Ces contrôles fonctionnent localement, sans Gemini. Ils comparent les sources directes (table et champ simples), normalisent casse/espaces et appliquent les alias déclarés. Ils ne certifient pas l’équivalence métier d’expressions ou de textes français. Les cibles communes ambiguës/indirectes sont comptabilisées comme non vérifiables. Les ajouts, suppressions et renommages restent visibles dans la comparaison classique mais ne sont pas assimilés automatiquement à une migration.

Les avertissements automatiques sont des **changements partiels constatés**, pas des erreurs certaines. Les groupes explicites ajoutent une preuve métier. Une comparaison sans avertissement ne vaut pas validation globale. Choisissez deux versions du même périmètre ; vérifiez l’avertissement si moteur/configuration diffèrent.

### Mise à jour

Conservez votre dossier `data` ainsi que vos paramètres personnalisés (notamment la commande Gemini). Le nouveau champ `linked_field_groups` est facultatif pour une ancienne configuration. Ne remplacez pas votre configuration par celle livrée sans reprendre vos réglages.

78 tests Python réussis, dont 14 tests spécifiques aux évolutions. Les anciens exemples exportés restent des instantanés : réanalysez-les pour appliquer le moteur actuel.

---

# Inspecteur Mapping — 1.3.0

Application locale de revue des mappings fonctionnels PHARE : Excel → contrôles déterministes → dashboard interactif et rapports complets. Le projet contient le moteur Python, le frontend sans CDN, un agent Gemini, huit skills, des exemples et des tests.


## Nouveautés 1.3.0

- Ouvrir **RG et jointures** pour retrouver toutes les règles extraites du classeur, y compris les lignes sans texte avec image. La revue affiche « Pas encore réalisée », « En cours — réponse attendue » ou « Terminée — N propositions ». L’état « en cours » signifie que le contexte est préparé : Gemini n’est pas lancé automatiquement.
- Comparer le texte original et la reformulation avec les retraits en rouge et les ajouts en vert. Les propositions sont importées après une revue Gemini explicitement lancée.
- Choisir **À examiner**, **Proposition retenue**, **À modifier** ou **Écartée**, saisir un commentaire et enregistrer. Les décisions persistent après rechargement. Une proposition modifiée lors d’un nouvel import repart à examiner ; la dernière réponse importée remplace la liste active.
- Exporter les seules propositions retenues en CSV ou JSON. Les exports complets Excel et HTML incluent aussi les décisions et commentaires. Aucun texte n’est réécrit automatiquement dans le classeur.
- Utiliser **Espace de revue** pour voir la liste, les quatre blocs d’explication et la cellule source au même endroit. Les boutons précédent/suivant parcourent la liste filtrée.
- Sur une règle contenant un MAX qualifié, ouvrir **Contexte du MAX — clé et périmètre**, confirmer la PK, le regroupement et la source de cette déclaration, puis recalculer. Une nouvelle analyse est créée ; la précédente reste dans l’historique.
- Le moteur ne classe plus un MAX ou plusieurs correspondances comme risque automatique. Un MAX par USERID avec la PK déclarée (USERID, SYSTEMMODSTAMP) valide l’unicité documentaire de la sélection. Si la clé ou le périmètre manque : **NON VÉRIFIABLE**. Un MAX déclaré global est présenté comme un choix à confirmer.
- Une ancienne analyse conserve ses anciens résultats. Le bouton **Actualiser les contrôles dans une nouvelle analyse** permet de bénéficier du nouveau moteur sans réimporter le fichier.

Pour mettre à jour, fermer l’application puis remplacer ses fichiers par ceux du ZIP. Conserver le dossier `data` de la version précédente pour retrouver analyses et décisions.

## Démarrer sous Windows

1. Extraire **tout** le ZIP dans un dossier accessible en écriture (pas directement dans l’archive).
2. Installer Python **3.10 ou supérieur**. Le programme accepte le lanceur `py` ou les commandes `python` et `python3`.
3. Double-cliquer sur `install.bat` la première fois. L’installation télécharge les dépendances depuis PyPI ; elle peut nécessiter le proxy de l’entreprise.
4. Double-cliquer sur `start.bat`. Le navigateur s’ouvre sur **http://127.0.0.1:8765**. Garder la console ouverte.
5. Dans **Import du mapping**, charger un `.xlsx`, vérifier les correspondances, puis **Démarrer l’analyse**.
6. Consulter le dashboard, les détails et les recommandations. Les exports sont disponibles depuis le dashboard et l’accueil.

Le moteur ne nécessite ni Oracle, ni ODI, ni Gemini, ni accès réseau après installation. Le HTML seul ne lance pas Python : `start.bat` démarre le serveur local qui traite les actions du navigateur.

Pour arrêter : fermer la console ou Ctrl+C. Pour reprendre : relancer `start.bat` ; les analyses et le suivi persistent dans `data/guardian.sqlite3`.

## Essayer les fichiers inclus

- `examples/Mapping_OFFRE_original.xlsx` : **copie inchangée** du fichier OFFRE fourni. Ce fichier et ses rapports contiennent des métadonnées métier ; ne pas diffuser le ZIP hors du périmètre autorisé.
- `examples/DEMO_OFFRE_v1.xlsx` : données **fictives**, avec références manquantes, incohérence d’obligation, types réducteurs, doublon et filtre contradictoire.
- `examples/DEMO_OFFRE_v2.xlsx` : seconde version fictive, corrigeant plusieurs signalements et ajoutant un champ. Quelques risques sont volontairement conservés.
- `reports/OFFRE/`, `reports/DEMO_v1/`, `reports/DEMO_v2/` : rapports JSON, Excel et HTML complets déjà calculés. Le dashboard démarre sans historique fictif ; importer un exemple pour y créer une analyse.
- `docs/REVUE_OFFRE.md` : lecture initiale du fichier, observations humaines et limites de la règle intégrée sous forme d’image.

## Utiliser les rubriques

| Rubrique | Fonction |
|---|---|
| Accueil | Parcours guidé, import, lancement, priorités, indicateurs et contrôles |
| Guide de démarrage | Étapes guidées d’import, de vérification et de lecture |
| Import du mapping | Détection des colonnes, correction des correspondances et export/import de la configuration |
| Lancer l’analyse | Exécution du moteur local |
| Tableau de bord | Indicateurs, anomalies par catégorie, objets, feuilles et évolution |
| Aperçu Excel | Extrait en lecture seule avec la ligne ou la cellule du contrôle mise en évidence |
| Contrôles | Recherche, filtres, tri, pagination, export CSV et détail des preuves |
| Fiches de jointure | Texte déclaré, objets/champs repérés, points à préciser et accès à la cellule source |
| Exemples de données | Scénarios de test à compléter, filtre par type et export CSV |
| RG et jointures | Texte original et reformulation côte à côte, différences mises en évidence, statut de la revue et décisions persistantes |
| Espace de revue | Liste des contrôles, quatre blocs d’explication et extrait Excel simultanés ; précédent/suivant |
| Recommandations | Actions et recommandations métier issues de la revue importée |
| Dépendances | Graphe documentaire, zoom, recherche, filtre par type et contrôles associés |
| Comparer les versions | Différences entre deux analyses et évolution des signalements |
| Historique | Analyses enregistrées et journal du suivi |
| Paramètres | Configuration JSON, alias, dictionnaire, politiques temporelles et limites |

Un clic sur une légende de statut ou une barre applique un filtre au tableau. Le mode sombre est mémorisé dans le navigateur. Le suivi des contrôles est commun à toute l’équipe et stocké localement, indépendamment du thème du navigateur.

### Lire les statuts

- **ANOMALIE** : incohérence prouvée par une règle déterministe étroite (référence absente, obligation explicitement contredite, constante trop longue, conjonction simple impossible, types SCD contradictoires).
- **RISQUE** : signalement à examiner. Aucune erreur de données n’est démontrée.
- **CONFORME** : propriété contrôlée avec succès, **pas** une validation globale du mapping.
- **INFORMATION** : observation documentaire.
- **NON VÉRIFIABLE** : informations ou données insuffisantes.

Chaque contrôle possède ID, catégorie, sévérité, statut, objet/champ, feuille, ligne et colonne disponibles, règle, description, justification, correction, confiance, preuves, conséquence et informations manquantes. Les scores de confiance sont des indications du moteur, pas des probabilités calibrées.

Le suivi « analysé », « risque accepté » ou « faux positif » ne réécrit jamais le résultat. Les acceptations et faux positifs demandent une justification. Le JSON exporté depuis l’interface inclut également le journal et les revues sémantiques.

## Adapter un autre mapping

Les feuilles attendues sont `Mapping HDR` et `Filtre - Jointures - RG`. Leurs noms sont configurables dans `config/mapping_schema.json`.

Le lecteur recherche l’en-tête dans les 30 premières lignes. Il utilise les libellés normalisés (accents/retours à la ligne) et le groupe supérieur, notamment pour distinguer les « Champ » ODS, HDR et publication. Une correspondance ambiguë n’est pas choisie au hasard. Les cellules réellement fusionnées sont propagées dans leur seule plage ; les autres cellules vides ne sont pas remplies arbitrairement.

Dans **Import**, corriger les sélecteurs et la ligne d’en-tête. Exporter les correspondances pour réutiliser le profil. On peut aussi renseigner `overrides` dans `config/mapping_schema.json` :

```json
{
  "header_row": 2,
  "columns": {"source_field":"G","target_field":"L","publication_field":"Z"},
  "rules_columns": {"id":"A","text":"B"}
}
```

Pour ajouter une variante d’en-tête, enrichir `fields` dans ce fichier : `groupe normalisé|libellé normalisé`, ou un libellé non ambigu. Le schéma exact et les correspondances effectives participent à l’empreinte de configuration.

Les formats de RG pris en charge utilisent un identifiant `F_...`, `J_...` ou `RG_...` dans une colonne, et leur texte dans une autre. Un tableau multi-colonnes d’une autre forme nécessite une adaptation du parseur ; l’outil ne prétend pas comprendre tout format Excel arbitraire.

### Configuration métier

Dans Paramètres, modifier uniquement les règles validées par votre équipe. Exemples de structure **à compléter avec vos conventions réelles** :

```json
{
  "aliases": {"ALIAS_VALIDE":"ORZ_TABLE_VALIDEE"},
  "source_dictionary": {"ORZ_TABLE_VALIDEE.CHAMP":"VARCHAR2(255 CHAR)"},
  "technical_fields": ["CHAMP_TECHNIQUE_VALIDE"],
  "history_policy": {"TABLE_HIST_VALIDEE": {"business_key":["ID_VALIDE"],"description":"Politique à documenter"}}
}
```

Ne remplacer que les clés concernées dans le fichier complet. Une politique temporelle configurée devient une pièce documentaire disponible pour la revue ; elle ne constitue pas une vérification de l’exécution ODI. La configuration contient explicitement la PK ORZ_USER (USERID, SYSTEMMODSTAMP) et l’alias USER → ORZ_USER, conformément à la déclaration utilisateur. Adapter ou retirer cette déclaration si le modèle source diffère.

## Gemini CLI et VS Code

La revue sémantique est **optionnelle et explicitement autorisée**, distincte des contrôles Python. Le dashboard ne lance pas un processus Gemini automatiquement.

### Workflow guidé sans commande à saisir

1. Installer et authentifier Gemini CLI selon sa documentation officielle : https://geminicli.com/docs/get-started/installation/ et https://geminicli.com/docs/get-started/authentication/ . Respecter les règles de confidentialité de votre organisation.
2. Dans **RG et jointures**, cliquer sur **Préparer la revue française**, puis relire le fichier `gemini_prompt.txt`. Il contient les champs, règles et signalements, sans les images binaires du classeur.
3. Dans **Paramètres**, mettre `gemini.enabled` à `true` si l’usage du fournisseur est autorisé.
4. Double-cliquer sur `revue_gemini.bat`, choisir le contexte et saisir **OUI** pour cet envoi. Le script utilise Gemini CLI avec son mode d’approbation **default**, jamais YOLO ni auto-edit.
5. Le script crée `gemini_prompt_response.json` à côté du contexte. Dans **RG et jointures**, cliquer sur **Importer la réponse** et sélectionner ce JSON.
6. Examiner les propositions et leurs preuves avant de décider. Un hash de fichier différent est refusé. Les propositions ne deviennent pas des anomalies déterministes.

La revue produit deux volets indépendants : recommandations métier et propositions de reformulation du français. Chaque reformulation cite la règle, la ligne, le texte original exact, la proposition, le motif et les ambiguïtés à valider. Si le sens dépend d’une règle absente, Gemini pose une question au BA au lieu de compléter le texte. Les reformulations apparaissent dans **RG et jointures** et les exports Excel/HTML ; elles ne modifient jamais le mapping importé.

Le script utilise un répertoire de travail temporaire vide et transmet le contexte sur stdin. Le profil utilisateur et les politiques de votre CLI restent applicables. Le prompt demande de n’utiliser aucun outil ; ce n’est pas une sandbox de sécurité. Une permission nécessaire en mode non interactif peut être refusée par le CLI : utiliser alors le workflow interactif. Aucune modification de vos autorisations ou de votre configuration Gemini globale n’est faite.

### Agent et huit skills dans VS Code

Ouvrir le dossier du projet dans VS Code puis lancer `gemini` dans son terminal. Une fois l’usage des données autorisé, demander par exemple :

```text
@mapping-quality-guardian Analyse examples/DEMO_OFFRE_v1.xlsx.
Utilise les skills spécialisés et le moteur Python. Génère les rapports
puis une revue sémantique séparée avec les preuves et informations manquantes.
```

Les skills sont dans `.gemini/skills/<nom>/SKILL.md`, avec leur script `scripts/run.py`. Vérifier leur découverte avec `/skills list`, puis `/skills reload` si nécessaire. L’agent est défini dans `.gemini/agents/mapping-quality-guardian.md`. Les conventions ont été vérifiées dans la documentation officielle le 28 octobre 2026 :

- https://geminicli.com/docs/cli/tutorials/skills-getting-started/
- https://geminicli.com/docs/core/subagents/
- https://geminicli.com/docs/cli/headless/
- https://geminicli.com/docs/cli/cli-reference/

La disponibilité des sous-agents et des outils dépend de la version installée. Si la découverte échoue, l’agent principal peut appliquer `GEMINI.md` et lire les `SKILL.md`. Ne jamais activer un mode d’approbation automatique pour contourner une incompatibilité. Les scripts de skills délèguent au même moteur Python versionné.

### Commandes utiles pour un développeur

```powershell
.venv\Scripts\python.exe -m backend.cli "examples\Mapping_OFFRE_original.xlsx" --output reports\revue
.venv\Scripts\python.exe -m backend.cli "examples\DEMO_OFFRE_v1.xlsx" --normalize --output reports\normalisation
.venv\Scripts\python.exe -m unittest discover -s tests -v
.venv\Scripts\python.exe -m backend.app --no-browser --port 8766
```

Sous Linux/macOS : `python3 -m venv .venv`, puis utiliser `.venv/bin/python` pour installer les requirements et lancer les mêmes modules. Le raccourci F5 de VS Code utilise `backend.app` après sélection de l’interpréteur du venv.

## Autres options d’amélioration possibles

Ces pistes peuvent être ajoutées dans les prochains échanges :

1. **Assistant de clarification des règles** : transformer chaque ambiguïté en question priorisée, avec réponse, décideur, date et justification dans l’historique.
2. **Modèle structuré des RG** : convertir les phrases validées en tableau SI / ET / ALORS / SINON / priorité / cas NULL / exemples, puis comparer ce tableau au texte.
3. **Contrat des jointures** : gabarit à compléter pour alias, clés complètes, type de jointure, grain attendu, cardinalité, règle sans correspondance, départage et ex æquo.
4. **Dictionnaire PHARE réutilisable** : catalogue versionné des objets ODS/HDR, champs, types sources, alias et champs techniques, partagé entre plusieurs mappings.
5. **Validation par jeux d’exemples** : cas d’entrée et résultat attendu pour tester les RG, y compris dates frontières, NULL et doublons, sans connexion Oracle/ODI.
6. **Workflow de revue** : statuts proposé / à valider / validé métier / validé technique, commentaire, responsable, échéance et export du journal.
7. **Comparaison métier enrichie** : expliquer l’impact d’une modification sur les objets, règles et anomalies affectés, au-delà de l’ajout/suppression de lignes logiques.
8. **Profils de contrôle par domaine** : activer des règles spécifiques selon le type d’objet, uniquement à partir d’un référentiel validé par l’équipe.

## Architecture et stockage

- `backend/parsers/excel.py` : validation et normalisation Excel, images, formules, coordonnées.
- `backend/analyzer.py`, `backend/validators/types.py` : règles déterministes et graphe.
- `backend/services/` : exports, comparaison, SQLite et contexte sémantique.
- `backend/app.py` : serveur HTTP lié exclusivement à `127.0.0.1`, deux workers d’analyse, jeton anti-requêtes intersites, contrôle Host/Origin.
- `frontend/` : modules JavaScript, CSS responsive et graphiques SVG sans dépendances externes.
- `data/guardian.sqlite3` : analyses immuables, événements de suivi append-only, revues sémantiques.
- `data/*.xlsx` : copies importées, sous identifiants générés ; `data/guardian.log` : journal d’erreurs.

Sauvegarder le dossier complet après arrêt de l’application pour conserver config, analyses et suivi. Les fichiers locaux ne sont pas chiffrés par l’outil : utiliser le poste et le stockage d’entreprise appropriés. Application prévue pour un utilisateur local, pas comme service réseau multiutilisateur. Les exports HTML/Excel CLI conservent les résultats déterministes ; le JSON téléchargé depuis l’application inclut le suivi.

## Limites précises

- `.xlsx` uniquement ; convertir `.xls`, fichiers chiffrés et macros au préalable.
- Formules détectées mais **non calculées** ; pas de contrôle certifié de leurs résultats mis en cache.
- Images intégrées affichables dans le contexte des contrôles, **sans OCR automatique**. La RG_OFF_001 du fichier fourni contient justement une image.
- Pas de parseur SQL Oracle exhaustif. Les expressions complexes, contradictions en prose, cardinalités réelles et logique temporelle nécessitent une revue métier ou technique, ou revue Gemini autorisée.
- Le dictionnaire source n’est pas fourni par le fichier OFFRE : les compatibilités ODS → HDR correspondantes sont **non vérifiables**, pas vertes par défaut.
- Sans données et contraintes source, l’outil ne prouve ni l’unicité, ni les chevauchements temporels, ni les doublons réels. Il repère les risques documentaires.
- Graphe de dépendances documentaire : pas une analyse complète de lignage SQL. Des alias non configurés peuvent produire des nœuds distincts.
- Comparaison par objet/champ et ID de règle. Un renommage de clé est présenté comme suppression + ajout ; les clés dupliquées sont signalées comme ambiguës. Déplacer une ligne ne crée pas à lui seul une différence.
- Recommandations déterministes : 60 premières cartes, tous les résultats restent dans le tableau filtrable et les exports.
- Fichiers limités par défaut à 20 Mio compressés, 100 Mio décompressés et 500 000 cellules sur les deux feuilles. Lecture en mémoire ; pas de traitement streaming de millions de lignes. Deux analyses peuvent s’exécuter en parallèle, les autres sont mises en file.
- Tests Python, API et parcours navigateur Chromium exécutés dans l’environnement de livraison. Les scripts Windows sur Windows et l’appel réel à Gemini restent **à exécuter sur le poste cible**. Voir `docs/VALIDATION.md`.

## Dépannage

| Symptôme | Action |
|---|---|
| Python introuvable | Installer Python 3.10+ avec le lanceur `py`, puis relancer install.bat |
| Installation bloquée | Vérifier l’accès PyPI ou demander les paquets internes/proxy à l’équipe poste |
| Port 8765 indisponible | Fermer l’autre instance, ou modifier `port` dans settings.json puis redémarrer |
| HTML ouvert mais interface vide | Lancer start.bat et ouvrir l’URL HTTP, pas le fichier index.html directement |
| Feuille manquante | Vérifier les noms exacts ou config/mapping_schema.json |
| Correspondance non identifiée | Corriger les sélecteurs, la ligne d’en-tête ou les alias de colonnes |
| Trop de cellules | Réduire les formats appliqués aux lignes/colonnes inutilisées dans Excel |
| Image non détectée | Réinstaller requirements.txt (Pillow est nécessaire), vérifier que c’est une vraie image intégrée |
| Session invalide | Recharger la page après un redémarrage du serveur |
| Gemini absent / timeout | Vérifier le CLI dans PATH, son authentification et la version ; passer au mode interactif |
| Échec d’import Gemini | Vérifier l’empreinte et le schéma docs/semantic_response.schema.json |
| Erreur interne | Consulter data/guardian.log ; les classeurs originaux n’ont pas été modifiés |
