@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Executer install.bat avant la revue Gemini.
  pause
  exit /b 1
)
.venv\Scripts\python.exe scripts\review_gemini.py
pause
