# Architecture et interfaces

## Flux

Le navigateur charge un XLSX en base64 sur POST /api/upload. Le backend valide l’archive, reconnaît les deux feuilles et renvoie la structure avec les correspondances. L’utilisateur les confirme/corrige puis POST /api/analyze crée une tâche dans le pool de deux workers. Le navigateur interroge /api/job/{id}, puis charge le rapport sauvegardé en SQLite. Aucun script n’est à relancer entre les actions.

## Endpoints

| Méthode | Route | Contrat |
|---|---|---|
| GET | /api/session | Jeton de session local pour les écritures |
| POST | /api/upload | filename, data (base64), overrides optionnel ; renvoie upload_id, document |
| POST | /api/analyze | upload_id, overrides optionnel ; renvoie job_id |
| GET | /api/job/{job_id} | running, done + analysis_id ou error |
| GET | /api/history | Métadonnées des analyses |
| GET | /api/analysis/{id} | Résultat brut immuable et document normalisé |
| GET/POST | /api/analysis/{id}/events | Événements de suivi append-only |
| GET/POST | /api/analysis/{id}/semantic | Revues Gemini séparées, hash contrôlé |
| POST | /api/compare | before, after : IDs d’analyses |
| GET | /api/export/{id}/{format} | json, xlsx, html, prompt, accepted |
| GET/POST | /api/settings | Lire / remplacer la configuration, contrôles des types et limites |

Les POST nécessitent `Content-Type: application/json` et `X-MQG-Token`. Le serveur vérifie Host et Origin, ne sert que frontend/, n’active pas CORS et ne se lie pas sur le réseau. Aucun chemin utilisateur n’est utilisé pour écrire un import : UUID généré par le serveur. Les exports HTML échappent le contenu ; les exports CSV/XLSX neutralisent les chaînes pouvant être interprétées comme formules.

## Reproductibilité

L’empreinte SHA-256 du classeur, la version de moteur et l’empreinte des paramètres métier + schéma de détection + colonnes effectives + ligne d’en-tête sont dans chaque rapport. Les résultats et IDs sont identiques pour des entrées/configurations identiques. Les timestamps et IDs d’analyse générés par la couche de stockage diffèrent volontairement.

## Extension

Ajouter une règle dans analyzer.py, avec un code stable, des preuves, des statuts prudents et des tests. Pour un autre format de RG, adapter parsers/excel.py. En cas de changement de comportement des contrôles, incrémenter VERSION et documenter les changements. La comparaison avertit lorsque le moteur ou la configuration diffèrent.

Le frontend est séparé en app.js (navigation), review.js (revue française, décisions, diff et espace de revue), charts.js (agrégations et SVG) et graph.js (navigation graphique). Il n’a pas de phase de compilation ni de dépendance CDN.

## Revue française et MAX (1.3.0)

GET /api/analysis/{id}/language-review renvoie l’état et les propositions de la dernière réponse contenant language_reviews, avec leurs décisions. POST avec action=start enregistre la préparation du contexte ; action=decision enregistre proposal_id, decision et comment. Le passage à terminé est transactionnel avec l’import de la réponse. Les identifiants de propositions incluent règle, cellule, texte original, proposition, justification et ambiguïtés pour éviter de réutiliser une validation périmée.

GET /api/export/{id}/accepted exporte uniquement les propositions retenues de la dernière réponse. Les exports complets conservent les décisions. Les événements de proposition sont conservés séparément des résultats bruts dans proposal_events ; language_state conserve le statut de la revue.

POST /api/analysis/{id}/max-context valide les déclarations de clé/périmètre, conserve le hash du texte concerné et crée une nouvelle analyse. POST /api/analysis/{id}/reanalyze actualise une ancienne analyse avec le moteur courant. Les résultats précédents ne sont pas écrasés. La configuration effective est conservée avec chaque rapport ; un contexte MAX ne s’applique pas à une règle dont le texte a changé.


## 1.5 — Impact documentaire
`review_impact(old,new)` est appelé par le service de comparaison. Il ne modifie pas les analyses ni la base de suivi. Le frontend affiche les cartes et filtre leur niveau de preuve ; les exports JSON contiennent les identifiants avant/après et les preuves. Les références de RG sont suivies transitivement avec un ensemble visité (cycles finis). Les sources indirectes ne sont jamais certifiées équivalentes.


## 1.7 — Revue intégrée et dépendances par champ

`gemini_runner.py` gère les préparations en mémoire et les tâches persistées dans `gemini_jobs`. GET `/api/analysis/{id}/gemini` retourne la dernière tâche ; POST accepte prepare, start, cancel, raw. La préparation est liée à l’analyse et à l’empreinte de configuration ; start exige un accord explicite et consomme la préparation. Le contexte UTF-8 passe par stdin, pas par la ligne de commande. La réponse directe ou enveloppée du CLI est validée via le service d’import existant (empreinte et textes originaux). Les erreurs conservent la revue précédente. Les tâches actives au redémarrage deviennent interrompues sans relance.

POST `/api/lineage` accepte analysis_id, before_id optionnel et target (TABLE|CHAMP). Le service construit les dépendances documentaires puis compare les signatures sans les positions Excel. Les cibles courantes, historiques et de publication sont incluses. L’expansion des règles gère les cycles et signale sa limite. `gemini-runner.js` et `lineage.js` assurent les deux nouveaux parcours, sans dépendance frontend supplémentaire.


## 1.8 — Traçabilité et conversation

POST `/api/trace` accepte analysis_id et node_id optionnel. `network()` fusionne les graphes par cible, partage les sources/règles et conserve des identifiants de branches propres aux cibles. `neighborhood()` parcourt les liens dans les deux sens avec un ensemble visité. Les règles non utilisées restent consultables.

GET `/api/analysis/{id}/assistant` liste les tâches de conversation ; POST accepte prepare (question, focus), start (preview_id, consent), cancel (job_id). Le même exécuteur CLI gère les délais, annulations, contexte temporaire et reprise interrompue. La propriété purpose distingue chat/review dans gemini_jobs. Une réponse chat est validée et persistée sans appel à add_semantic. Les citations doivent appartenir aux preuves transmises ; l’empreinte doit correspondre au rapport.

Le frontend trace.js affiche les cartes regroupées, le sous-graphe amont/aval et les preuves. assistant.js monte un panneau lié à l’analyse sélectionnée, détruit ses écouteurs et arrête ses interrogations périodiques à la navigation. Les réponses sont affichées comme texte échappé et leurs liens sont construits à partir des preuves conservées côté serveur.
