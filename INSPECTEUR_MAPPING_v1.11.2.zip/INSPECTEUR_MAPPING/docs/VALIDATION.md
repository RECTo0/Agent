# Validation de la version 1.3.0

## Exécuté

- 64 tests Python réussis : moteur, lecture du classeur OFFRE et des exemples, API, export, import sémantique et persistance. Sortie dans tests/RESULTATS.txt.
- Cas MAX : PK complète par USERID, PK absente ou incomplète, périmètre absent, contexte périmé après changement du texte, MAX global, règle de gestion contenant MAX.
- Suivi : préparation, réponse vide terminée, import lié au texte exact, décision persistante, nouvelle proposition sans reprise abusive de l’ancienne validation, doublons refusés, décision/commentaire exportés et échappés.
- Syntaxe des modules JavaScript et des modules Python vérifiée.
- Parcours Chromium sur DEMO_OFFRE_v1 : import/analyse, état de revue, téléchargement du contexte, import d’une réponse fictive, différences surlignées, décision conservée après rechargement, export CSV retenu avec neutralisation des formules, navigation dans l’espace de revue, suivi du contrôle, aperçu Excel et recalcul du MAX après confirmation de la PK.
- Affichage bureau 1600 px et mobile 390 px, thème sombre ; aucune erreur JavaScript et aucun débordement horizontal de page dans ce parcours. Captures des pages de revue inspectées.

## Limites

- Les scripts batch Windows et Gemini CLI réel n’ont pas été exécutés. Aucune donnée n’a été transmise à Gemini pendant les tests. La revue importée utilisée par le test UI est fictive et reste dans une base temporaire.
- Les contraintes Oracle sont documentaires : aucune connexion à la base n’est utilisée. La conformité du MAX porte sur la sélection selon les contraintes déclarées, pas sur l’implémentation SQL.
- La distribution Chromium utilisée par l’environnement de validation est distincte du navigateur Windows de l’utilisateur.

## Rejouer localement

Depuis le projet : `python -m unittest discover -s tests -v`. Pour le parcours UI, installer Playwright dans un environnement de développement, lancer une copie de l’application puis exécuter `node tests/review-ui.spec.mjs`. La variable IM_TEST_URL permet de choisir une instance de test (défaut http://127.0.0.1:8765). Le test crée des analyses et un suivi : utiliser une copie du projet.


## Version 1.4.0
78 tests Python réussis. Cas ajoutés : oubli partiel IDMOEOrigine, migration complète, absence de changement, déplacement de lignes, objets indépendants, cible ajoutée/supprimée, branches multiples, RG indirecte, alias/casse, courant/historique séparés ou sur une ligne, groupe déclaré cohérent/incohérent/incomplet, validation de configuration, absence de groupe implicite.

Test navigateur Chromium réussi : comparaison sur le scénario IDMOE/IDMOEOrigine, formulaire de groupe enregistré, téléchargement JSON, lien vers la ligne source, affichage 1500 px et 390 px sans débordement global, aucune erreur JavaScript. Windows et exécution réelle de Gemini non testés.


## Version 1.5.0
101 tests Python réussis, dont 23 nouveaux tests pour les dix contrôles de la fiche d’impact. Tests navigateur Chromium sur 1500 px et 390 px : dix rubriques, cartes, filtrage Information manquante, téléchargement de la fiche JSON, groupe déclaré, export existant, lien de la fiche vers la ligne Excel ; aucune erreur JavaScript ni débordement horizontal global. Les captures ont été inspectées. Windows et Gemini réel restent non testés.

Limites : reconnaissance documentaire par motifs explicites, pas d’évaluation SQL générale ; sens métier limité à des indices lexicaux, nécessitant une confirmation humaine ou une revue Gemini manuelle.


## Version interface 1.6.0
Guide testé sous Chromium à 1440 px et 390 px : 16 réponses, exclusion de la question demandée, recherche, aucun résultat, filtres, remise à zéro, objectifs, étapes, lecture/pause, démonstration A.ID/B.ID, preuves, parcours Gemini, navigation, rejeu et préférence reduced-motion. Aucun débordement horizontal global ni erreur JavaScript. Captures inspectées. Moteur inchangé (1.5.0, suite de 101 tests passée à la livraison précédente).


## Version 1.7.0
121 tests Python réussis, dont 20 nouveaux tests : accord obligatoire, préparation sans envoi, liaison à l’analyse/configuration, refus de rejeu, lancement désactivé, import automatique, JSON invalide, mauvaise empreinte, erreur CLI, annulation, tâche unique, délai dépassé, reprise interrompue ; catalogue de cibles, références transitives cycliques, références manquantes, branches multiples, différences, déplacement de lignes et publication.

Parcours Chromium réussi avec un CLI Python fictif dans une copie temporaire : préparation, accord, lancement, import, rechargement, affichage des reformulations, graphe et différence, export, navigation vers la preuve Excel et depuis un contrôle. Vérification à 1500 px et 390 px, thème sombre, sans débordement global ni erreur JavaScript. Captures bureau et sombre inspectées. Aucun appel au service Gemini. Windows, npx et le CLI réel n’ont pas été exécutés ici.

Rejouer : `python -m unittest discover -s tests -v`. Le test navigateur `tests/run_integrated_ui.py` crée uniquement une copie temporaire avec faux CLI et rapports fictifs ; installer Playwright et Chromium puis lancer depuis la racine du projet. IM_BROWSER_PATH permet de choisir le binaire Chromium.


## Version 1.8.0
130 tests Python réussis. Neuf nouveaux tests couvrent sources partagées, isolation des branches, références absentes, contexte et contraintes déclarées, focus invalide, citations/empreintes invalides, enveloppe valide, séparation conversation/revue et isolation des analyses.

Parcours Chromium sur une copie temporaire et faux CLI : graphe, impacts, sélection et recherche, export, consentement obligatoire, réponse avec citation, conversation après rechargement, lien vers la preuve Excel, thème sombre et largeur 390 px sans débordement global. Captures inspectées. Le test ne sollicite pas le service Gemini. L’exécution réelle Windows/Gemini n’a pas été réalisée.

Rejouer le parcours avec Playwright installé : `python tests/run_contextual_ui.py`, depuis la racine. Le serveur utilise le port local 8767 et une base temporaire ; IM_BROWSER_PATH peut indiquer le Chromium de test.


## Version 1.9.0
Refonte du graphe frontend, moteur inchangé. Parcours Chromium réussi : transformations masquées au démarrage, exploration progressive, légende à sept couleurs et symbole de risque, modes amont/aval sans cible sans rapport, dépliage des cartes, déplacement avec mise à jour des liens, zoom molette, réorganisation, menu rétractable/restauré, export, assistant avec faux CLI. Thème sombre et largeur 390 px sans débordement global ; captures inspectées. Aucun appel réel à Gemini. Rejouer avec Playwright : python tests/run_trace_ui.py ; IM_BROWSER_PATH permet de préciser le navigateur.


## Version 1.10.0
137 tests Python réussis. Sept nouveaux tests : requête structurée et citée, état incomplet pour information manquante ou marqueur, citation inconnue, format invalide, compatibilité des anciennes réponses, présence des schémas dans le contexte. Test navigateur avec faux CLI : génération, accord, copie exacte dans le presse-papiers, export SQL avec commentaires, persistance, SQL précédent dans le contexte suivant et absence de débordement mobile. Aucune validation Oracle ni appel réel Gemini. Rejouer avec Playwright : python tests/run_sql_ui.py.


## Version 1.11.0
147 tests Python réussis. Le parcours Chromium de cohérence métier vérifie la création du groupe, le risque de divergence, l’exception, la réanalyse, la persistance, la modification, la désactivation et la réactivation, l’export JSON, le lien Excel, le filtre et l’affichage à 390 px. Rejouer avec Playwright depuis la racine avec `python tests/run_coherence_ui.py`.
