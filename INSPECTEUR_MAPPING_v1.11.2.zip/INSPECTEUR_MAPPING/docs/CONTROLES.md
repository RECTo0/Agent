# Catalogue des contrôles et limites

Les identifiants ci-dessous sont les codes de règle. Chaque occurrence possède un ID stable dérivé du code et de l’identité logique de l’élément, avec un rang en cas de clé dupliquée. Les coordonnées sont des références Excel physiques, en base 1.

| Code | Vérification | Qualification possible |
|---|---|---|
| STRUCT_EMPTY / STRUCT_COLUMN | Lignes et colonnes reconnues | Non vérifiable si structure insuffisante |
| STRUCT_FORMULA | Formule Excel présente | Non vérifiable ; aucune exécution |
| STRUCT_IMAGE | Image ancrée dans une feuille | Non vérifiable ; image consultable |
| FIELD_DUPLICATE | Plusieurs lignes pour objet + champ | Risque, branches possibles |
| FIELD_NAMING | Identifiant simple Oracle non reconnu | Risque, identifiant délimité possible |
| FIELD_FEED | Source, expression, valorisation explicite ou mécanisme technique | Conforme sur déclaration / information / risque / non vérifiable |
| FIELD_REQUIRED | Obligatoire OUI et non valorisé NON, sans source/expression | Anomalie documentaire |
| TYPE_SOURCE_TARGET | Familles, longueurs, unités, précision, échelle et fractions temporelles | Conforme sur types déclarés / risque / non vérifiable |
| TYPE_PUBLICATION | Format HDR vers publication | Même périmètre limité aux types déclarés |
| TYPE_LITERAL_OVERFLOW | Constante citée complète plus longue que la taille cible | Anomalie certaine sur cette constante |
| HIST_TYPE | Type 1/2 explicitement déclaré | Conforme sur déclaration |
| HIST_TYPE_UNKNOWN / HIST_TABLE | Type non reconnu ou table Type 2 non documentée | Non vérifiable / risque |
| HIST_CONTRADICTION | Type histo et SCD Behavior numériques différents | Anomalie documentaire |
| HIST_POLICY | Politique temporelle disponible dans config | Information si présente, sinon non vérifiable |
| HIST_DATA | Données temporelles non fournies | Non vérifiable, pas de validation de chevauchements |
| CROSS_PUBLICATION | Vue historisée minoritaire dans un mapping dominé par une autre vue | Risque de nommage |
| CROSS_REFERENCE | Référence F/J/RG retrouvée ou absente de la seconde feuille | Conforme sur présence / anomalie sur absence |
| CROSS_EMPTY_RULE | Référence utilisée mais définition vide | Non vérifiable |
| CROSS_JOIN_LINK | Source secondaire sans jointure sur la ligne | Risque ; alimentation indépendante possible |
| CROSS_EXPRESSION_TABLE | Table de transformation non documentée dans sources/jointures | Risque |
| RULE_DUPLICATE | Identifiant de règle répété | Risque de variantes ambiguës |
| RULE_EMPTY | Définition vide | Information si inutilisée ; sinon non vérifiable |
| RULE_IMAGE | Règle avec image ancrée | Non vérifiable automatiquement |
| JOIN_KEYS | Références qualifiées et égalité présentes | Conforme sur présence, pas sur sémantique |
| JOIN_MULTIPLICITY | Plusieurs correspondances, 1-N ou MAX mentionné | Aucun risque automatique. CONFORME pour une sélection unique selon la PK confirmée et le regroupement déclaré ; NON VÉRIFIABLE si le contexte manque ; INFORMATION pour un MAX déclaré global. |
| JOIN_CARDINALITY | Aucune preuve exploitable d’unicité/cardinalité | Non vérifiable |
| JOIN_ALIAS | Alias non déclaré dans les sources/jointures/config | Non vérifiable |
| CROSS_FIELD | Champ de jointure absent des projections connues | Non vérifiable, pas « champ inexistant » |
| RULE_SEMANTIC | Règle textuelle métier complexe | Non vérifiable automatiquement |
| RULE_AMBIGUITY | Réserve lexicale détectée (à définir, etc.) | Risque |
| RULE_CONTRADICTION | Expression entière composée d’égalités textuelles reliées seulement par AND, même champ et constantes distinctes | Anomalie dans ce sous-langage strict |

## Interprétation

L’extraction des jointures est lexicale, sans parseur SQL ni catalogue de schéma complet. Les égalités en prose, OR, CASE, sous-requêtes, groupes de conditions, jointures temporelles et contradictions entre plusieurs paragraphes ne sont pas prouvées automatiquement. Le moteur produit des pistes documentaires ; les skills guident la revue sémantique.

Un format source manquant ne peut pas produire de contrôle de conversion conforme. Une réduction de taille sur une colonne source est un risque sans connaître les valeurs ; une constante explicite trop longue est un fait démontré. Les conversions implicites restent des risques même lorsqu’Oracle peut les exécuter dans certaines conditions NLS.

La couverture n’est pas une preuve de qualité globale. Aucun pourcentage « qualité » n’agrège artificiellement les contrôles non vérifiables dans le vert. Les graphiques présentent les volumes réels de chaque statut.


## Évolutions de source (1.4)

PARTIAL_SOURCE_CHANGE : compare les cibles communes uniques d’un même objet partageant une source directe dans la référence. Signale lorsqu’une partie seulement change. Preuve = sources et emplacements avant/après.
CURRENT_HISTORY_DRIFT : signale la divergence nouvelle d’un champ courant / TABLE_HIST précédemment aligné. Une ligne décrivant les deux tables alimente les deux de la même façon.
LINKED_SOURCE_GROUP : contrôle à chaque analyse les groupes `linked_field_groups` déclarés avec members (TABLE.CHAMP) et reason. Sources directes égales : CONFORME ; différentes : RISQUE ; cibles absentes/ambiguës ou expressions indirectes : NON VÉRIFIABLE.

Les deux premiers contrôles sont calculés dans la comparaison et exportables depuis celle-ci ; ils ne modifient pas rétroactivement les résultats des analyses. Pas de déduction d’équivalence fonctionnelle à partir des seuls noms IDMOE / IDMOEOrigine.


## Fiche d’impact 1.5
Les dix contrôles, leurs preuves et leurs limites sont décrits en tête du README. Module backend/validators/impact.py ; calcul via /api/compare ; résultats dans impact.cards et impact.coverage. Niveau distinct du statut d’une analyse : Écart constaté / Risque possible / Information manquante.
