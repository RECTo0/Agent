# Revue initiale — OFFRE_PI2606_v2.0.0

Source : copie `examples/Mapping_OFFRE_original.xlsx`. Analyse statique des deux feuilles demandées. Les autres feuilles ne constituent pas un dictionnaire source validé et ne sont pas analysées par le moteur.

## Structure observée

- `Mapping HDR` : 36 lignes physiques, 29 colonnes, groupes en ligne 1, en-têtes en ligne 2, 33 lignes métier reconnues. La ligne 30 est vide.
- ODS : schéma E, table F, champ G. Il n’existe pas de colonne décrivant les types des champs ODS.
- HDR : schéma I, table courante J, table historisée K, champ L, filtre M, jointure N, RG O, format P, valorisation Q, historisation R, type S.
- Publication : vue courante X, vue historisée Y, champ Z, RG AA, format AB.
- `Filtre - Jointures - RG` : identifiants en A, descriptions en B ; une table référente, un filtre renseigné, deux jointures renseignées, trois emplacements RG dont RG_OFF_001 comporte une image ancrée en B8.
- Des emplacements F_OFF_002/003, J_OFF_003 et RG_OFF_002/003 sont vides et non référencés : ne pas les qualifier d’erreurs actives.

## Points de revue constatés

| Localisation | Observation | Qualification |
|---|---|---|
| Mapping HDR Y17 et Y18 | `V_MOE_OPTION_HIST` figure dans le mapping d’offre, tandis que les autres lignes utilisent principalement `V_MOE_OFFRE_HIST` | Risque de reprise de nom, pas erreur prouvée sans intention métier |
| Mapping HDR F21/G21/N21 | `IDMOEOFFREPARENTE` utilise ORZ_CATALOG, sans référence de jointure sur la ligne | Risque de documentation incomplète |
| Mapping HDR N22 | J_OFF_002 est attachée à UNIVERSMARCHE, issu de ORZ_PRODUCT2.MARKETUNIVERSE__C ; la description de cette jointure vise l’offre parente | Observation humaine : vérifier un éventuel décalage de référence, sans correction automatique |
| Mapping HDR L24/O24 | THEMATIQUES est indiqué « Calculé », valorisé OUI, sans source ni calcul détaillé | Risque à clarifier |
| Filtre - Jointures - RG B5 | J_OFF_001 décrit une sélection par MAX(USER.SYSTEMMODSTAMP) | Avec la PK déclarée (USERID, SYSTEMMODSTAMP), un MAX par USERID sélectionne au plus une ligne. Confirmer le périmètre du MAX ; sa présence seule ne constitue pas un risque. |
| Filtre - Jointures - RG B6 | J_OFF_002 prévoit plusieurs étapes et départages, mais leur caractère totalement déterministe reste à démontrer | Risque ; confronter les clés et le grain attendu |
| Filtre - Jointures - RG B6, dernière étape | Le dernier départage mentionne encore CATALOGPRODUCTRELATIONSHIP.vlocity_cmt__CatalogId__c alors que l’on choisit une ligne CATALOG | Observation humaine : ce critère peut être identique pour les candidats ; vérifier le rôle exact du départage |
| Mapping HDR L3, L28:L29, L31:L36 | Plusieurs champs techniques n’ont pas d’expression explicite | Mécanismes possibles ; non vérifiables sans conventions documentées |
| Mapping HDR P et AB | Ce sont les formats HDR et publication, pas le format ODS et HDR | Ne pas inventer une validation des conversions source |

Ces observations humaines ne sont ni une sortie Gemini ni des anomalies déterministes. Elles complètent les rapports du moteur.

## RG_OFF_001 : image intégrée

L’image contient une table de décision à quatre colonnes : `isActive`, `vlocity_cmt__SellingStartDate__c`, `vlocity_cmt__SellingEndDate__c`, `Valeur`.

Transcription visuelle, à faire valider par le BA :

| isActive | Début | Fin | Valeur |
|---|---|---|---|
| false | > Today | cellule vide | OST001 |
| true | <= Today | >= Today | OST002 |
| false | <= Today | >= Today | OST003 |
| true | cellule vide | < Today | OST004 |
| false | cellule vide | < Today | OST005 |

Une cellule vide ne signifie pas automatiquement « indifférent ». À préciser : traitement des NULL, actif avant début de commercialisation, fuseau de Today, précision jour/heure, conditions se chevauchant si les dates sont incohérentes, ordre de priorité. Ne pas générer un CASE supposé exhaustif sans ces précisions.

L’application détecte et affiche l’image mais ne l’OCRise pas. Cette transcription est fournie dans cette note seulement et n’est pas injectée comme règle métier certaine dans le moteur.

## Résultats

Les nombres reproductibles figurent dans `reports/OFFRE/results.json` et le rapport complet. Une absence d’anomalie certaine ne valide pas le mapping : les risques et les points non vérifiables restent à instruire.
